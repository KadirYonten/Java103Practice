/**
   @version 1.20 2000-06-03
   @author Cay Horstmann
*/

import javax.swing.*;

public class BuggyButtonTest
{
  public static void main(String[] args)
  {
    BuggyButtonFrame frame = new BuggyButtonFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.show();
  }
}

