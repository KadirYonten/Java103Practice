/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import corejava.*;

public class SecurityManagerTest extends CloseableFrame
   implements ActionListener
{  public SecurityManagerTest()
   {  System.setSecurityManager(new SmutSecurityManager());
      MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      setMenuBar(mbar);
      add(fileText, "Center");
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open text file", FileDialog.LOAD);
         d.setFile("*.txt");
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  filename = lastDir + f;
            loadTextFile();            
         }
      }
      else if(arg.equals("Exit")) System.exit(0);
   }   

   public void loadTextFile()
   {  try
      {  fileText.setText("");
         BufferedReader in 
            = new BufferedReader(new FileReader(filename));
         String s;
         while ((s = in.readLine()) != null) 
         fileText.append(s + "\n");
         in.close();
      }
      catch (IOException e)
      {  fileText.append(e + "\n");
      }
      catch (SecurityException e)
      {  fileText.append("I am sorry, but I cannot do that.");
      }
   }

   public static void main(String[] args)
   {  Frame f = new SecurityManagerTest();
      f.show();
   }

   private TextArea fileText = new TextArea();
   private String filename = null;
   private String lastDir = "";
}

class NullSecurityManager extends SecurityManager
{   public void checkCreateClassLoader() {} 
    public void checkAccess(Thread g) {}
    public void checkAccess(ThreadGroup g) {}
    public void checkExit(int status) {}
    public void checkExec(String cmd) {}
    public void checkLink(String lib) {}
    public void checkRead(FileDescriptor fd) {}
    public void checkRead(String file) {}
    public void checkRead(String file, Object context) {}
    public void checkWrite(FileDescriptor fd) {}
    public void checkWrite(String file) {}
    public void checkDelete(String file) {}
    public void checkConnect(String host, int port) {}
    public void checkConnect(String host, int port, 
      Object context) {}
    public void checkListen(int port) {}
    public void checkAccept(String host, int port) {}
    public void checkMulticast(InetAddress maddr) {}
    public void checkMulticast(InetAddress maddr, byte ttl) {}
    public void checkPropertiesAccess() {}
    public void checkPropertyAccess(String key) {}
    public void checkPropertyAccess(String key, String def) {}
    public boolean checkTopLevelWindow(Object window) 
    { return true; }
    public void checkPrintJobAccess() {}
    public void checkSystemClipboardAccess() {}
    public void checkAwtEventQueueAccess() {}
    public void checkPackageAccess(String pkg) {}
    public void checkPackageDefinition(String pkg) {}
    public void checkSetFactory() {}
    public void checkMemberAccess(Class clazz, int which) {}
    public void checkSecurityAccess(String provider) {}
}  

class SmutSecurityManager extends NullSecurityManager
{  public void checkRead(String file) 
   {  Class[] cc = getClassContext();
      for (int i = 1; i < cc.length; i++) 
         if (getClassContext()[0] == getClassContext()[i]) 
            return;
      BufferedReader in = null;
      try
      {  in = new BufferedReader(new FileReader(file));
         String s;
         while ((s = in.readLine()) != null) 
         {  for (int i = 0; i < badWords.length; i++)
            if (s.toLowerCase().indexOf(badWords[i]) != -1)
               throw new SecurityException(file); 
         }
         in.close();
      }
      catch(IOException e)
      {  throw new SecurityException(); 
      }
      finally
      {  if (in != null) 
            try { in.close(); } catch (IOException e) {}
      }
   }

   public void checkRead(String file, Object context) 
   {  checkRead(file);
   }

   private String[] badWords = { "sex", "drugs", "C++" };
}
