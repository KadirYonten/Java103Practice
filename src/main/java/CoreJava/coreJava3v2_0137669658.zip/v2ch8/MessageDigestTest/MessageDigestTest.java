/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

import java.io.*;
import java.security.*;
import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class MessageDigestTest extends CloseableFrame
   implements ActionListener, ItemListener
{  public MessageDigestTest()
   {  Panel p = new Panel();

      CheckboxGroup g = new CheckboxGroup();
      addCheckbox(p, "SHA-1", g, true);
      addCheckbox(p, "MD5", g, false);    
      add(p, "North");
      add(message, "Center");
      add(digest, "South");
      digest.setFont(new Font("Courier", Font.PLAIN, 12));

      setAlgorithm("SHA-1");

      MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("File digest");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Text area digest");
      m2.addActionListener(this);
      m.add(m2);            
      MenuItem m3 = new MenuItem("Exit");
      m3.addActionListener(this);
      m.add(m3);            
      mbar.add(m);
      setMenuBar(mbar);
   }

   public void addCheckbox(Panel p, String name, 
      CheckboxGroup g, boolean v)
   {  Checkbox c = new Checkbox(name, g, v);
      c.addItemListener(this);
      p.add(c);
   }
   
   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED) 
         setAlgorithm((String)evt.getItem());
   }

   public void setAlgorithm(String alg)
   {  try
      {  currentAlgorithm = MessageDigest.getInstance(alg);
      }
      catch(NoSuchAlgorithmException e)
      {  digest.setText("" + e);
      }
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("File digest"))
      {  FileDialog d = new FileDialog(this,
            "Open text file", FileDialog.LOAD);
         d.setFile("*.txt");
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  filename = lastDir + f;
            computeDigest(loadBytes(filename));
         }
      }
      else if (arg.equals("Text area digest"))   
      {  String m = message.getText();
         computeDigest(m.getBytes());
      }
      else if(arg.equals("Exit")) System.exit(0);
   }

   public byte[] loadBytes(String name)
   {  FileInputStream in = null;
   
      try
      {  in = new FileInputStream(name); 
         ByteArrayOutputStream buffer 
            = new ByteArrayOutputStream();
         int ch;
         while ((ch = in.read()) != -1)
            buffer.write(ch);
         return buffer.toByteArray();
      }
      catch (IOException e)
      {  if (in != null) 
         {  try { in.close(); } catch (IOException e2) {}
         }
         return null;
      }
   }
   
   public void computeDigest(byte[] b)
   {  currentAlgorithm.reset();
      currentAlgorithm.update(b);
      byte[] hash = currentAlgorithm.digest();
      String d = "";
      for (int i = 0; i < hash.length; i++)
      {  d += new Format("%02X ").form(hash[i] & 0xFF);
      }
      digest.setText(d);
   }

   public static void main(String[] args) throws Exception
   {  Frame f = new MessageDigestTest();
      f.setSize(300, 200);
      f.show();
   }

   private TextArea message = new TextArea();
   private TextField digest = new TextField();
   private String filename = null;
   private String lastDir = "";
   private MessageDigest currentAlgorithm;
}