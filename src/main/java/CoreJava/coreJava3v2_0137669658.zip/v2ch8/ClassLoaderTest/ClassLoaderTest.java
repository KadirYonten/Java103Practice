/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

import java.util.*;
import java.io.*;
import java.lang.reflect.*;
import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class ClassLoaderTest 
   extends CloseableFrame 
   implements ActionListener
{  public ClassLoaderTest()
   {  setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(new Label("Class"), gbc, 0, 0, 1, 1);
      add(new Label("Key"), gbc, 0, 1, 1, 1);
      gbc.anchor = GridBagConstraints.WEST;
      add(nameField, gbc, 1, 0, 1, 1);
      add(keyField, gbc, 1, 1, 1, 1);
      gbc.anchor = GridBagConstraints.CENTER;
      Button loadButton = new Button("Load");
      add(loadButton, gbc, 0, 2, 2, 1);
      loadButton.addActionListener(this);
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }
 
   public void actionPerformed(ActionEvent evt)
   {  try
      {  ClassLoader loader 
            = new CryptoClassLoader(keyField.getValue());
         Class c = loader.loadClass(nameField.getText());
         String[] cargs = new String[] {};
         Method m = c.getMethod("main", 
            new Class[] { cargs.getClass() });
         m.invoke(null, new Object[] { cargs });
         setVisible(false);
      }
      catch (Exception e)
      {  System.out.println(e);
      }
   }

   public static void main(String[] args)
   {  Frame f = new ClassLoaderTest();
      f.setSize(300, 200);
      f.show();
   }

   private IntTextField keyField = new IntTextField(3, 4);
   private TextField nameField = new TextField(30);
}

class CryptoClassLoader extends ClassLoader
{  public CryptoClassLoader(int k)
   {  key = k;
   }

   protected synchronized Class loadClass(String name, 
      boolean resolve) throws ClassNotFoundException
   {  // check if class already loaded
      Class cl = (Class)classes.get(name);

      if (cl == null) // new class
      {  try
         {  // check if system class
            return findSystemClass(name);
         }
         catch (ClassNotFoundException e) {}
         catch (NoClassDefFoundError e) {}

         // load class bytes--details depend on class loader
         
         byte[] classBytes = loadClassBytes(name);
         if (classBytes == null) 
            throw new ClassNotFoundException(name);

         cl = defineClass(name, classBytes, 
            0, classBytes.length);
         if (cl == null) 
            throw new ClassNotFoundException(name);

         classes.put(name, cl); // remember class
      }

      if (resolve) resolveClass(cl);

      return cl;
   }

   private byte[] loadClassBytes(String name)
   {  String cname = name.replace('.', '/') + ".class";
      FileInputStream in = null;
      try
      {  in = new FileInputStream(cname); 
         ByteArrayOutputStream buffer 
            = new ByteArrayOutputStream();
         int ch;
         while ((ch = in.read()) != -1)
            buffer.write(ch);
         return buffer.toByteArray();
      }
      catch (IOException e)
      {  if (in != null) 
         {  try { in.close(); } catch (IOException e2) {}
         }
         return null;
      }
   }

   private Hashtable classes = new Hashtable();
   private int key;
}
