/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

import java.security.*;

public class SignatureTest
{  public static void main(String[] args) 
   {  try
      {  KeyPairGenerator keygen 
            = KeyPairGenerator.getInstance("DSA");
         SecureRandom secrand = new SecureRandom();
         keygen.initialize(512, secrand);

         KeyPair keys1 = keygen.generateKeyPair();
         PublicKey pubkey1 = keys1.getPublic();
         PrivateKey privkey1 = keys1.getPrivate();

         KeyPair keys2 = keygen.generateKeyPair();
         PublicKey pubkey2 = keys2.getPublic();
         PrivateKey privkey2 = keys2.getPrivate();

         Signature signalg = Signature.getInstance("DSA");
         signalg.initSign(privkey1);
         String message 
            = "Pay authors a bonus of $20,000.";
         signalg.update(message.getBytes());
         byte[] signature = signalg.sign();
         Signature verifyalg = Signature.getInstance("DSA");
         verifyalg.initVerify(pubkey1);
         verifyalg.update(message.getBytes());
         if (!verifyalg.verify(signature)) 
            System.out.print("not ");
         System.out.println("signed with private key 1");

         verifyalg.initVerify(pubkey2);
         verifyalg.update(message.getBytes());
         if (!verifyalg.verify(signature)) 
            System.out.print("not ");
         System.out.println("signed with private key 2");
      }
      catch(Exception e)
      {  System.out.println("Error " + e);
      }
   }
}
