/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

package java.security;

import java.io.*;

public class CipherInputStream extends FilterInputStream
{  public CipherInputStream(InputStream in, Cipher c)
   {  super(in);
      cipher = c;
      inBuffer = new byte[cipher.blockSize()];
      outBuffer = new byte[cipher.blockSize()];
   }

   public int read() throws IOException
   {  if (outBufferPosition >= outBufferLength)
      {  int inBufferLength = in.read(inBuffer);
         if (inBufferLength <= 0) return -1;
         outBufferLength = cipher.update(inBuffer, 0, 
            inBufferLength, outBuffer, 0);
         if (outBufferLength == 0) return -1;
         outBufferPosition = 0;
      }
      int ret = outBuffer[outBufferPosition];
      outBufferPosition++;
      return ret;
   }

   private Cipher cipher;
   private byte[] inBuffer;
   private byte[] outBuffer;
   private int outBufferPosition = 0;
   private int outBufferLength = 0;
}