/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * This is an implementation of a proposed JCE class. 
 * Only those features that are necessary for the Core Java
 * CAESAR example have been implemented.
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

package java.security;

abstract public class Cipher
{  public static Cipher getInstance(String alg)
      throws NoSuchAlgorithmException 
   {  try 
      {  return (Cipher)Security.getImpl(alg, "Cipher", null);
      } catch(NoSuchProviderException e) 
      {  throw new NoSuchAlgorithmException(alg);
      }
   }

   public Cipher(String alg) { algorithm = alg; }

   public static final int ENCRYPT = 1;
   public static final int DECRYPT = 2;
   public static final int UNINITIALIZED = 3;
   
   public final int getState() { return state; }
   public final String getAlgorithm() { return algorithm; }
   public final int outBufferSize(int inLen) 
   {  return engineOutBufferSize(inLen, true); 
   }
   public final int blockSize() 
   {  return engineBlockSize(); 
   }

   public final void initEncrypt(Key key)
   {  state = ENCRYPT;
      engineInitEncrypt(key);
   }
   
   public final void initDecrypt(Key key)
   {  state = DECRYPT;
      engineInitEncrypt(key);
   }

   public final byte[] crypt(byte[] in) 
   { return crypt(in, 0, in.length); 
   }

   public final byte[] crypt(byte[] in, int off, int len)
   {  if (len % blockSize() != 0) 
         throw new 
            IllegalArgumentException("Illegal block size");
      byte[] out = new byte[outBufferSize(len)];
      for (int i = 0; i < len; i += blockSize())
      {  update(in, off + i, blockSize(), out, i);
      }
      return out;
   }

   final int update(byte in[], int inOff, int inLen,
      byte out[], int outOff)
   {  engineUpdate(in, inOff, inLen, out, outOff);
      return engineOutBufferSize(inLen, false);
   }

   abstract protected int engineBlockSize();
   abstract protected int engineOutBufferSize(int inLen,
      boolean last);
   abstract protected void engineInitEncrypt(Key k);
   abstract protected void engineInitDecrypt(Key k);
   abstract protected int engineUpdate(byte in[], int inOff, 
      int inLen, byte out[], int outOff);
    
   private int state = UNINITIALIZED;
   private String algorithm;
}

