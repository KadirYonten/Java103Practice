/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * This is an implementation of a proposed JCE class. 
 * Only those features that are necessary for the Core Java
 * CAESAR example have been implemented.
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

package java.security;

import java.io.*;

public class CipherOutputStream extends FilterOutputStream
{  public CipherOutputStream(OutputStream out, Cipher c)
   {  super(out);
      cipher = c;
      inBuffer = new byte[cipher.blockSize()];
      outBuffer = new byte[cipher.blockSize()];
   }

   public void write(int ch) throws IOException
   {  if (inBufferPosition >= inBuffer.length) 
         flushBuffer();
      inBuffer[inBufferPosition] = (byte)ch;
      inBufferPosition++;
   }

   private void flushBuffer() throws IOException
   {  int outBufferLength = cipher.update(inBuffer, 0, 
         inBuffer.length, outBuffer, 0);
      out.write(outBuffer, 0, outBufferLength);
      inBufferPosition = 0;
   }

   public void flush() throws IOException
   {  flushBuffer();
   }

   private Cipher cipher;
   private byte[] inBuffer;
   private byte[] outBuffer;
   private int inBufferPosition = 0;
}