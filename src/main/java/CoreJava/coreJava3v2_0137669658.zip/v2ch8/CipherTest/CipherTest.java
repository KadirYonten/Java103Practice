/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

import java.security.*;
import java.io.*;
import corejava.*;

public class CipherTest
{  public static void main(String[] args) throws Exception
   {  Security.addProvider(new CoreJavaProvider());   
      KeyGenerator keyGen 
         = KeyGenerator.getInstance("CAESAR");
      SecureRandom rand = new SecureRandom();
      keyGen.initialize(rand);
      Key caesarKey = keyGen.generateKey();
      System.out.println("The key is " + caesarKey);

      Cipher cipher = Cipher.getInstance("CAESAR");
      cipher.initEncrypt(caesarKey);
      
      InputStream in = new FileInputStream("plain.txt");
      OutputStream out = new CipherOutputStream
         (new FileOutputStream("encrypted.txt"), cipher);
      int ch;
      while ((ch = in.read()) != -1)
      {  out.write((byte)ch);
      }
      in.close();
      out.close();

      System.out.println("The plaintext was:");
      cipher.initDecrypt(caesarKey);
      in = new CipherInputStream
         (new FileInputStream("encrypted.txt"), cipher);
      while ((ch = in.read()) != -1)
      {  System.out.print((char)ch);
      }
      in.close();
      System.out.println();
   }
}






