/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

import java.security.*;
import java.io.*;
import java.util.*;
import corejava.*;

public class CertificateTest
{  public static void main(String[] args) throws Exception
   {  if (args.length != 1)
      {  System.out.println
            ("USAGE: java CertificateTest certificate");
         return;
      }
      sun.security.x509.X509Cert cert 
         = new sun.security.x509.X509Cert();
      InputStream in = new FileInputStream(args[0]);
      cert.decode(in);
      in.close();
      System.out.println("Principal is " 
         + cert.getPrincipal().getName());
      Principal guarantor = cert.getGuarantor();
      System.out.println("Guarantor is " 
         + guarantor.getName());

      // now try to find the guarantor

      IdentityScope identitydb 
         = IdentityScope.getSystemScope();

      Enumeration ids = identitydb.identities();
      while (ids.hasMoreElements())
      {  Identity id = (Identity)ids.nextElement();
         Certificate[] c = id.certificates();
         for (int i = 0; i < c.length; i++)
         {  if (c[i].getPrincipal().getName()
               .equals(guarantor.getName()))
            {  PublicKey pubkey = id.getPublicKey();
               try
               {  cert.verify(pubkey);
                  System.out.println("Certificate verified");
                  return;
               }
               catch(SecurityException e)
               {  // verification failed
               }
            }
         }
      }
      System.out.println("Certificate cannot be verified");
   }
}
 
