/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Sep 1997
 * @author Cay Horstmann
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import corejava.*;

public class FileReadApplet extends Applet
   implements ActionListener
{  public void init()
   {  setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.BOTH;
      add(new Label("File name:"), gbc, 0, 0, 1, 1);
      add(fileName, gbc, 1, 0, 1, 1);
      add(openButton, gbc, 2, 0, 1, 1);
      add(fileText, gbc, 0, 1, 3, 1);
      openButton.addActionListener(this);
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  try
         {  fileText.setText("");
            BufferedReader in 
               = new BufferedReader(new 
               FileReader(fileName.getText()));
            String s;
            while ((s = in.readLine()) != null) 
            fileText.append(s + "\n");
            in.close();
         }
         catch (IOException e)
         {  fileText.append(e + "\n");
         }
         catch (SecurityException e)
         {  fileText.append
               ("I am sorry, but I cannot do that.");
         }
      }
   }   

   private Button openButton = new Button("Open");
   private TextArea fileText = new TextArea(10, 40);
   private TextField fileName = new TextField(30);
}

