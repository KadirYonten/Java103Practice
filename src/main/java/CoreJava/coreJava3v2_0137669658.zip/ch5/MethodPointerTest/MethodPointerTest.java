/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 11 Mar 1997
 * @author Cay Horstmann
 */

import java.lang.reflect.*;
import corejava.*;

public class MethodPointerTest
{  public static void main(String[] args) throws Exception
   {  printTable(1, 10, 10, 
         MethodPointerTest.class.getMethod("square", 
            new Class[] { double.class }));
      printTable(1, 10, 10, java.lang.Math.class.getMethod("sqrt",
         new Class[] { double.class }));
   }  

   public static double square(double x) { return x * x; }

   public static void printTable(double from, double to, 
      int n, Method f)
   {  System.out.println(f);
      double dx = (to - from) / (n - 1);
      for (double x = from; x <= to; x += dx)
      {  Format.print(System.out, "%12.4f |", x);
         try
         {  Object[] args = { new Double(x) };
            Double d = (Double)f.invoke(null, args);
            double y = d.doubleValue();
            Format.print(System.out, "%12.4f\n", y);
         } catch (Exception e)
         {  System.out.println("???");
         }
      }
   }
}