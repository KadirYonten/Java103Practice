/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Feb 1996 
 * @author Cay Horstmann
 */

import java.io.*;
import sun.audio.*;
import corejava.*;

public class MailboxTest
{  public static void main(String[] args)
   {  Mailbox mbox = new Mailbox();
      while (true)
      {  System.out.println(mbox.status());
         String cmd = Console.readString
               ("play, text, voice, quit> ");
         if (cmd.equals("play"))
         {  Message m = mbox.remove();
            if (m != null)
            {  System.out.println("From: " + m.getSender());
               m.play();
            }
         }
         else if (cmd.equals("text"))
         {  String from = Console.readString("Your name: ");
            boolean more = true;
            String msg = "";
            System.out.println
               ("Enter message, 'exit' when done");
             
            while (more)
            {  String line = Console.readString();
               if (line.equals("exit"))
                  more = false;
               else msg = msg + line + "\n";
            }
            mbox.insert(new TextMessage(from, msg));
         }
         else if (cmd.equals("voice"))
         {  String from = Console.readString("Your name: ");
            String msg
               = Console.readString("Audio file name: ");         
            mbox.insert(new VoiceMessage(from, msg));
         }
         else if (cmd.equals("quit"))
            System.exit(0);
      }            
   }
}
               

abstract class Message
{  public Message(String from) { sender = from; }

   public abstract void play();
   public String getSender() { return sender; }
   
   private String sender;
}

class TextMessage extends Message
{  public TextMessage(String from, String t)
   { super(from); text = t; }

   public void play() { System.out.println(text); }
   
   private String text;
}

class VoiceMessage extends Message
{  public VoiceMessage(String from, String f)
   { super(from); filename = f; }
   
   public void play()
   {  AudioPlayer ap = AudioPlayer.player;
      try
      {  AudioStream as 
            = new AudioStream(new FileInputStream(filename));
         ap.start(as);
      }
      catch(IOException e) {}
   }   

   private String filename;
}


class Mailbox
{  public Message remove()
   {  if (nmsg == 0) return null;
      Message r = messages[out];
      nmsg--;
      out = (out + 1) % MAXMSG;
      return r;
   }
   
   public void insert(Message m)
   {  if (nmsg == MAXMSG) return;
      messages[in] = m;
      nmsg++;
      in = (in + 1) % MAXMSG;
   }
   
   public String status() 
   {  if (nmsg == 0) return "Mailbox empty";
      else if (nmsg == 1) return "1 message";
      else if (nmsg < MAXMSG) return nmsg + " messages";
      else return "Mailbox full";
   }
   
   private final int MAXMSG = 10;
   private int in = 0;
   private int out = 0;
   private int nmsg = 0;
   private Message[] messages = new Message[MAXMSG];
}


