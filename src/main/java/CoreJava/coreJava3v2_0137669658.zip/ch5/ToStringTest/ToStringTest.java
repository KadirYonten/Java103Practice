/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 11 Mar 1997
 * @author Cay Horstmann
 */

import java.lang.reflect.*;
import corejava.*;

public class ToStringTest
{  public static void main(String[] args)
   {  Employee e  = new Employee("Harry Hacker", 35000,
         new Day(1996,12, 1));
      System.out.println(e);
   }
}

class Employee 
{  public Employee(String n, double s, Day d)
   {  name = n;
      salary = s;
      hireDay = d;
   }

   public void print()
   {  System.out.println(name + " " + salary + " " 
         + hireYear());
   }

   public void raiseSalary(double byPercent)
   {  salary *= 1 + byPercent / 100;
   }

   public int hireYear()
   {  return hireDay.getYear();
   }

   public String toString()
   {  Class cl = getClass();
      String r = cl.getName() + "[";
      Class sc = cl.getSuperclass();
      if (!sc.equals(Object.class)) r += sc + ",";
      Field[] fields = cl.getDeclaredFields();
      for (int i = 0; i < fields.length; i++)
      {  Field f = fields[i];
         r += f.getName() + "=";
         try
         {  r += f.get(this);
         } catch (IllegalAccessException e)
         {  r += "???";
         }
         if (i < fields.length - 1) 
            r += ","; 
         else
            r += "]";
      }
      return r;
   }

   private String name;
   private double salary;
   private Day hireDay;
}


