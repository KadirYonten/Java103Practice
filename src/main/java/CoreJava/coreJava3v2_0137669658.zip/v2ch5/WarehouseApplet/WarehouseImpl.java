/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Sep 1996 
 * @author Cay Horstmann
 */

import java.rmi.*;
import java.util.*;
import java.rmi.server.*;


public class WarehouseImpl 
   extends UnicastRemoteObject
   implements Warehouse
{  public WarehouseImpl()
      throws RemoteException
   {  products = new Vector();
   }

   public synchronized void add(ProductImpl p)
   // local method
   {  products.addElement(p);
   }

   public synchronized Vector find(Customer c)
      throws RemoteException
   {  Vector result = new Vector();
      for (int i = 0; i < products.size(); i++)
      {  ProductImpl p = (ProductImpl)products.elementAt(i);
         if (p.match(c)) result.addElement(p);
      }
      result.addElement(new ProductImpl("Core Java Book", 
         0, 200, Product.BOTH, "", "corejava.jpg"));
      c.reset();
      return result;
   }
   
   private Vector products;
}
