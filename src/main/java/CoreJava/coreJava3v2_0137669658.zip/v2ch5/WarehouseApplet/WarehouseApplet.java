/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Jun 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import corejava.*;

public class WarehouseApplet extends Applet
   implements ActionListener, ItemListener
{  public void init()
   {  setLayout(new GridBagLayout());
      
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.NONE;
      gbc.weightx = 100;
      gbc.weighty = 100;
      add(new Label("Age:"), gbc, 0, 0, 1, 1);
      add(age = new IntTextField(0, 4), gbc, 1, 0, 1, 1);
      CheckboxGroup cbg = new CheckboxGroup();
      add(male = new Checkbox("Male", cbg, true), gbc, 0, 1, 1, 1);
      add(female = new Checkbox("Female", cbg, true), gbc, 1, 1, 1, 1);
      add(new Label("Hobbies"), gbc, 0, 2, 1, 1);
      hobbies = new List(4, true);
      hobbies.addItem("Gardening");
      hobbies.addItem("Beauty");
      hobbies.addItem("Computers");
      hobbies.addItem("Household");
      hobbies.addItem("Sports");
      add(hobbies, gbc, 1, 2, 1, 1);
      Button submitButton = new Button("Submit");
      add(submitButton, gbc, 0, 3, 2, 1);
      submitButton.addActionListener(this);
      descriptions = new List(4, false);
      gbc.fill = GridBagConstraints.HORIZONTAL;
      add(descriptions, gbc, 0, 4, 2, 1);
      descriptions.addItemListener(this);
      gbc.fill = GridBagConstraints.NONE;
      canvas = new Canvas();
      canvas.setSize(150, 150);
      add(canvas, gbc, 0, 5, 2, 1);

      String url = getCodeBase().getHost();
      if (url.equals("default")) url = "";
      url = "rmi://" + url;
      try
      {  centralWarehouse = (Warehouse)Naming.lookup(url 
            + "/central_warehouse");
      }
      catch(Exception e)
      {  showStatus("Error: Can't connect to warehouse. " + e);
      }
   }

   private void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }
   
   public void actionPerformed(ActionEvent evt)
   {  if (evt.getActionCommand().equals("Submit"))
      {  if (age.isValid())
         {  Customer c = new Customer(age.getValue(),
               (male.getState() ? Product.MALE : 0)
               + (female.getState() ? Product.FEMALE : 0),
               hobbies.getSelectedItems());
            try
            {  products = centralWarehouse.find(c);
               descriptions.removeAll();
               for (int i = 0; i < products.size(); i++)
               {  Product p = (Product)products.elementAt(i);
                  descriptions.addItem(p.getDescription());
               }
            }
            catch(Exception e)
            {  System.out.println("Error: " + e);
            }
         }
      }
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
      {  int index = descriptions.getSelectedIndex();
         if (index < 0) return;
         try
         {  Product p = (Product)products.elementAt(index);
            productImage 
               = getImage(getCodeBase(), p.getImageFile());
            repaint();
         }
         catch(Exception e)
         {  System.out.println("Error: " + e);
         }
      }
   }

   public void paint(Graphics g)
   {  if (productImage == null) return;
      Graphics cg = canvas.getGraphics();
      cg.clearRect(0, 0, 
         canvas.getSize().width, canvas.getSize().height);
      cg.drawImage(productImage, 0, 0, this);
      cg.dispose();
   }
   
   private Warehouse centralWarehouse;
   private IntTextField age;
   private Checkbox male;
   private Checkbox female;
   private List hobbies;
   private List descriptions;
   private Vector products;
   private Canvas canvas;
   private Image productImage;
}

