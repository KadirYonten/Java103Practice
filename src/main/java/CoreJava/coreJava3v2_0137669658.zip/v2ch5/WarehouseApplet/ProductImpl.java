/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Sep 1996 
 * @author Cay Horstmann
 */

import java.rmi.*;
import java.rmi.server.*;
import java.awt.*;

public class ProductImpl
   extends UnicastRemoteObject
   implements Product
{  public ProductImpl(String n, int s, int age1, int age2,
      String h, String i)
      throws RemoteException
   {  name = n;
      ageLow = age1;
      ageHigh = age2;
      sex = s;
      hobby = h;
      imageFile = i;
   }
   
   public boolean match(Customer c) // local method
   {  if (c.getAge() < ageLow || c.getAge() > ageHigh)
      return false;
      if (!c.hasHobby(hobby)) return false;
      if ((sex & c.getSex()) == 0) return false;
      return true;
   }

   public String getDescription() throws RemoteException
   {  return "I am a " + name + ". Buy me!";
   }
   
   public String getImageFile() throws RemoteException
   {  return imageFile;
   }
   
   private String name;
   private int ageLow;
   private int ageHigh;
   private int sex;
   private String hobby;
   private String imageFile;
}
