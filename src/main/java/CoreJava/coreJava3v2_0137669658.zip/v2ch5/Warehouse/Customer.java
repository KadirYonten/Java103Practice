/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Sep 1996 
 * @author Cay Horstmann
 */

import java.io.*;

public class Customer implements Serializable
{  public Customer(int theAge, int theSex, String[] theHobbies)
   {  age = theAge;
      sex = theSex;
      hobbies = theHobbies;
   }

   public int getAge() { return age; }

   public int getSex() { return sex; }

   public boolean hasHobby(String aHobby)
   {  if (aHobby == "") return true;
      for (int i = 0; i < hobbies.length; i++)
         if (hobbies[i].equals(aHobby)) return true;
      
      return false;
   }
   
   public void reset()
   {  age = 0;
      sex = 0;
      hobbies = null;
   }
   
   public String toString()
   {  String result = "Age: " + age + " Sex: ";
      if (sex == Product.MALE) result += "Male";
      if (sex == Product.FEMALE) result += "Female";
      result += " Hobbies: ";
      for (int i = 0; i < hobbies.length; i++)
         result += hobbies[i] + " ";
      return result;      
   }

   private int age;
   private int sex;
   private String[] hobbies;
}
