/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Jun 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import corejava.*;

public class WarehouseClient extends CloseableFrame
   implements ActionListener
{  public WarehouseClient()
   {  setLayout(new GridBagLayout());
      
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.NONE;
      gbc.weightx = 100;
      gbc.weighty = 100;
      add(new Label("Age:"), gbc, 0, 0, 1, 1);
      add(age = new IntTextField(0, 4), gbc, 1, 0, 1, 1);
      CheckboxGroup cbg = new CheckboxGroup();
      add(male = new Checkbox("Male", cbg, true), gbc, 0, 1, 1, 1);
      add(female = new Checkbox("Female", cbg, true), gbc, 1, 1, 1, 1);
      add(new Label("Hobbies"), gbc, 0, 2, 1, 1);
      hobbies = new List(4, true);
      hobbies.addItem("Gardening");
      hobbies.addItem("Beauty");
      hobbies.addItem("Computers");
      hobbies.addItem("Household");
      hobbies.addItem("Sports");
      add(hobbies, gbc, 1, 2, 1, 1);
      Button submitButton = new Button("Submit");
      add(submitButton, gbc, 0, 3, 2, 1);
      submitButton.addActionListener(this);
      result = new TextArea(4, 40);
      result.setEditable(false);
      add(result, gbc, 0, 4, 2, 1);

      System.setSecurityManager(new RMISecurityManager());
      String url = "rmi:///";
         // change to "rmi://www.yourserver.com/"
         // when server runs on remote machine www.yourserver.com
      try
      {  centralWarehouse = (Warehouse)Naming.lookup("central_warehouse");
      }
      catch(Exception e)
      {  System.out.println("Error: Can't connect to warehouse. " + e);
      }
   }

   private void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Submit"))
      {  if (age.isValid())
         {  Customer c = new Customer(age.getValue(),
               (male.getState() ? Product.MALE : 0)
               + (female.getState() ? Product.FEMALE : 0),
               hobbies.getSelectedItems());
            String t = c + "\n";
            try
            {  Vector result = centralWarehouse.find(c);
               for (int i = 0; i < result.size(); i++)
               {  Product p = (Product)result.elementAt(i);
                  t += p.getDescription() + "\n";
               }
            }
            catch(Exception e)
            {  t = "Error: " + e;
            }
            result.setText(t);
         }
      }
   }

   public static void main(String[] args)
   {  Frame f = new WarehouseClient();
      f.setSize(300, 300);
      f.show();
   }

   private Warehouse centralWarehouse;
   private IntTextField age;
   private Checkbox male;
   private Checkbox female;
   private List hobbies;
   private TextArea result;
}

