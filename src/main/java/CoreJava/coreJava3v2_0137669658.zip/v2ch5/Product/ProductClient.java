/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Sep 1996 
 * @author Cay Horstmann
 */

import java.rmi.*;
import java.rmi.server.*;

public class ProductClient
{  public static void main(String[] args)
   {  System.setSecurityManager(new RMISecurityManager()); 
      String url = "rmi:///"; 
         // change to "rmi://www.yourserver.com/"
         // when server runs on remote machine 
         // www.yourserver.com
      try
      {  Product c1 = (Product)Naming.lookup(url + "toaster");
         Product c2 = (Product)Naming.lookup(url 
            + "microwave");
         System.out.println(c1.getDescription());
         System.out.println(c2.getDescription());
      }
      catch(Exception e)
      {  System.out.println("Error " + e);
      }
      System.exit(0);
   }
}
