/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class CanvasTest extends CloseableFrame
   implements ActionListener
{  public CanvasTest()
   {  Panel p = new Panel();
      Button tickButton = new Button("Tick");
      p.add(tickButton);
      tickButton.addActionListener(this);
      Button resetButton = new Button("Reset");
      p.add(resetButton);
      resetButton.addActionListener(this);
      Button closeButton = new Button("Close");
      p.add(closeButton);
      closeButton.addActionListener(this);
      add(p, "South");
      clock = new ClockCanvas();
      add(clock, "Center");
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Tick")) clock.tick();
      else if (arg.equals("Reset")) clock.reset();
      else if (arg.equals("Close")) System.exit(0);
   }
   
   public static void main(String[] args)
   {  Frame f = new CanvasTest();
      f.show();  
   }
   
   private ClockCanvas clock;
}

class ClockCanvas extends Canvas
{  public void paint(Graphics g)
   {  g.drawOval(0, 0, 100, 100);
      double hourAngle = 2 * Math.PI * (minutes - 3 * 60)
          / (12 * 60);
      double minuteAngle = 2 * Math.PI * (minutes - 15) 
         / 60;
      g.drawLine(50, 50, 
         50 + (int)(30 * Math.cos(hourAngle)), 
         50 + (int)(30 * Math.sin(hourAngle)));
      g.drawLine(50, 50, 
         50 + (int)(45 * Math.cos(minuteAngle)), 
         50 + (int)(45 * Math.sin(minuteAngle)));
   }
   
   public void reset()
   {  minutes = 0;
      repaint();
   }
   
   public void tick()
   {  minutes++;  
      repaint();
   }
   
   private int minutes = 0;
}
