/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class ListTest extends CloseableFrame
   implements ItemListener
{  public ListTest()
   {  words = new List(4, true);
      words.add("quick");
      words.add("brown");
      words.add("hungry");
      words.add("wild");
      words.add("silent");
      words.add("huge");
      words.add("private");
      words.add("abstract");
      words.add("static");
      words.add("final");
      
      Panel p = new Panel();
      p.add(words);
      words.addItemListener(this);

      add(p, "South");
      fox = new FoxCanvas();
      add(fox, "Center");
   }

   public void itemStateChanged(ItemEvent evt)
   {  fox.setAttributes(words.getSelectedItems());
   }
      
   public static void main(String[] args)
   {  Frame f = new ListTest();
      f.show();  
   }
   
   private FoxCanvas fox;
   private List words;
}

class FoxCanvas extends Canvas
{  public FoxCanvas() 
   {  setAttributes(new String[0]); 
   }
   
   public void setAttributes(String[] w)
   {  text = "The ";
      for (int i = 0; i < w.length; i++)
         text += w[i] + " ";
      text += "fox jumps over the lazy dog.";
      repaint();
   }
   
   public void paint(Graphics g)
   {  g.drawString(text, 0, 50);
   }
   
   private String text;
}
