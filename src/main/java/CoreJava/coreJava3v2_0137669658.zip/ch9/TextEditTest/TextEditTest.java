/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class TextEditTest extends CloseableFrame
{  public TextEditTest()
   {  Panel p = new Panel();
      
      Button replaceButton = new Button("Replace");
      p.add(replaceButton);
      replaceButton.addActionListener(new ActionListener()
         {  public void actionPerformed(ActionEvent evt)
            {  String f = from.getText();
               int n = ta.getText().indexOf(f);
               if (n >= 0 && f.length() > 0)
                  ta.replaceRange(to.getText(), n, 
                     n + f.length());
            }
         });

      from = new TextField(8);
      p.add(from);

      p.add(new Label("with"));

      to = new TextField(8);
      p.add(to);
    
      add(p, "South");
      ta = new TextArea(8, 40);
      add(ta, "Center");
   }
   
   public static void main(String[] args)
   {  Frame f = new TextEditTest();
      f.show();  
   }
   
   private TextArea ta;
   private TextField from, to;
}


