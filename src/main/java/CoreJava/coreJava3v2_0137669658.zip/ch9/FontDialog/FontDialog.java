/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class FontDialog extends CloseableFrame
{  public FontDialog()
   {  setTitle("FontDialog");
      GridBagLayout gbl = new GridBagLayout();
      setLayout(gbl);
      
      style = new List(4, false);
      style.add("Serif");
      style.add("Sans Serif");
      style.add("Monospaced");
      style.add("Dialog");
      style.add("DialogInput");
      style.select(0);
                  
      bold = new Checkbox("Bold");
      italic = new Checkbox("Italic");
      Label label = new Label("Size: ");
      size = new IntTextField(10,1);
      sample = new TextField();

      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.BOTH;
      gbc.weightx = 20;
      gbc.weighty = 100;
      add(style, gbc, 0, 0, 1, 3);
      gbc.weightx = 100;
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.CENTER;
      add(bold, gbc, 1, 0, 2, 1);
      add(italic, gbc, 1, 1, 2, 1);
      add(label, gbc, 1, 2, 1, 1);
      gbc.fill = GridBagConstraints.HORIZONTAL;
      add(size, gbc, 2, 2, 1, 1);
      gbc.anchor = GridBagConstraints.SOUTH;
      gbc.weighty = 0;
      add(sample, gbc, 0, 3, 4, 1);
      sample.setText("The quick brown fox");

      ItemListener fontChanged = new ItemListener()
         {  public void itemStateChanged(ItemEvent evt)
            { updateFont(); }
         };
      bold.addItemListener(fontChanged);
      italic.addItemListener(fontChanged);
      style.addItemListener(fontChanged);
      size.addActionListener(new ActionListener()
         {  public void actionPerformed(ActionEvent evt)
            { updateFont(); }
         });
   }
   
   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }
   
   public void updateFont()
   {  sample.setFont(new Font(style.getSelectedItem(), 
         (bold.getState() ? Font.BOLD : 0)
            + (italic.getState() ? Font.ITALIC : 0),
         size.getValue()));
      repaint();
   }
 
   public static void main(String[] args)
   {  Frame f = new FontDialog();
      f.show();  
   }
   
   private List style;
   private Checkbox bold;
   private Checkbox italic;
   private IntTextField size;
   private TextField sample;
}