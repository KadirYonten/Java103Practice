/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 07 Feb 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class DataExchangeTest extends CloseableFrame 
   implements ActionListener
{  public DataExchangeTest()
   {  Panel p = new Panel();
      p.setLayout(new FlowLayout(FlowLayout.LEFT));
      addButton(p, "Connect");
      addButton(p, "Close");            
      add("North", p);
   }

   void addButton(Container p, String name)
   {  Button b = new Button(name);
      b.addActionListener(this);
      p.add(b);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Connect"))
      {  ConnectInfo transfer = new ConnectInfo("yourname", "");
         if (pd == null) pd = new ConnectDialog(this);
         if (pd.showDialog(transfer))
            System.out.println(transfer.username + " " 
               + transfer.password);  
      }
      else if(arg.equals("Close"))
         System.exit(0);
   }

   public static void main(String args[])
   {  Frame f = new DataExchangeTest();
      f.show();
   }

   private ConnectDialog pd = null; 
}

class ConnectInfo
{  public String username;
   public String password;
   public ConnectInfo(String u, String p) 
      { username = u; password = p; }
}   
                        
class ConnectDialog extends Dialog implements ActionListener
{  public ConnectDialog(Frame parent)
   {  super(parent, "Connect", true);         
      Panel p1 = new Panel();
      p1.setLayout(new GridLayout(2, 2));
      p1.add(new Label("User name:"));
      p1.add(username = new TextField("", 8));
      p1.add(new Label("Password:"));
      p1.add(password = new TextField("", 8));
      add("Center", p1);
      
      Panel p2 = new Panel();
      addButton(p2, "Ok");
      addButton(p2, "Cancel");
      add("South", p2);
      setSize(240, 120);

      addWindowListener(new WindowAdapter() { public void
            windowClosing(WindowEvent e) { setVisible(false); } } );
   }

   void addButton(Container p, String name)
   {  Button b = new Button(name);
      b.addActionListener(this);
      p.add(b);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if(arg.equals("Ok"))
      {  ok = true;
         setVisible(false);
      }
      else if (arg.equals("Cancel"))
         setVisible(false);
   }

   public boolean showDialog(ConnectInfo transfer)
   {  username.setText(transfer.username);
      password.setText(transfer.password);
      ok = false;
      show();
      if (ok)
      {  transfer.username = username.getText();
         transfer.password = password.getText();
      }
      return ok;
   }

   private TextField username;
   private TextField password;
   private boolean ok;
}

                         
