/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class DialogTest extends CloseableFrame 
   implements ActionListener
{  public DialogTest()
   {  Panel p = new Panel();
      p.setLayout(new FlowLayout(FlowLayout.LEFT));
      addButton(p, "About");
      addButton(p, "Close");            
      add(p, "North");

   }

   public void addButton(Container p, String name)
   {  Button b = new Button(name);
      b.addActionListener(this);
      p.add(b);
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if(arg.equals("About"))
      {  if (ab == null) // first time
            ab = new AboutDialog(this);   
          ab.show();
      }
      else if(arg.equals("Close"))
      {  System.exit(0);
      }
   }

   public static void main(String args[])
   {  Frame f = new DialogTest();
      f.show();
   }

   private AboutDialog ab;
}

class AboutDialog extends Dialog
{  public AboutDialog(Frame parent)
   {  super(parent, "About DialogTest", true);         

      Panel p1 = new Panel();
      p1.add(new Label("Core Java 1.1: Fundamentals"));
      p1.add(new Label("By Cay Horstmann and Gary Cornell"));
      add(p1, "Center");
                
      Panel p2 = new Panel();
      Button ok = new Button("Ok");
      p2.add(ok);
      add(p2, "South");

      ok.addActionListener(new ActionListener() { public void
         actionPerformed(ActionEvent evt) { setVisible(false); } } );

      addWindowListener(new WindowAdapter() { public void
            windowClosing(WindowEvent e) { setVisible(false); } } );

      setSize(220, 150);
   }
}



