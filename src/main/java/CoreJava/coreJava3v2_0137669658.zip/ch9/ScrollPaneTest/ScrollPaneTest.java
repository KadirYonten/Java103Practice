/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class ScrollPaneTest extends CloseableFrame 
{  public ScrollPaneTest()
   {  ScrollPane sp = new ScrollPane();
      sp.add(new SquareCanvas());
      sp.setSize(SquareCanvas.MAX_XWIDTH, 
         SquareCanvas.MAX_YHEIGHT);
      add(sp, "Center");
      pack();
   }

   public static void main(String args[])
   {  Frame f = new ScrollPaneTest();
      f.setSize(200, 200);
      f.show();
   }

   private Scrollbar horiz;
   private Scrollbar vert;
   private SquareCanvas canvas;   
}


class SquareCanvas extends Canvas
{  public SquareCanvas()
   {  addMouseListener(new MouseAdapter()
         {  public void mouseClicked(MouseEvent evt)
            {  int x = evt.getX();
               int y = evt.getY();
               current = find(x, y);
               if (current < 0) // not inside a square
               {  if (x < MAX_XWIDTH && y < MAX_YHEIGHT)
                     add(x, y);
               }
               else if (evt.getClickCount() >= 2)
               {  remove(current);
               }
            }
         });
   }

   public void paint(Graphics g)
   {  g.setColor(Color.red);
      g.drawRect(0, 0, MAX_XWIDTH - 1, MAX_YHEIGHT - 1);
      g.setColor(Color.black);
      for (int i = 0; i < nsquares; i++)
         draw(g, i);
   }
   
   public int find(int x, int y)
   {  for (int i = 0; i < nsquares; i++)
         if (squares[i].x <= x 
               && x <= squares[i].x + SQUARELENGTH
               && squares[i].y <= y 
               && y <= squares[i].y + SQUARELENGTH)
            return i;
      return -1;
   }

   public void draw(Graphics g, int i)
   {  g.drawRect(squares[i].x, squares[i].y, SQUARELENGTH,
      SQUARELENGTH);
   }

   public void add(int x, int y)
   {  if (nsquares < MAXNSQUARES)
      {  squares[nsquares] = new Point(x, y);
         nsquares++;
         repaint();
      }
   }

   public void remove(int n)
   {  nsquares--;
      squares[n] = squares[nsquares];
      if (current == n) current = -1;
      repaint();
   }

   public static final int MAX_XWIDTH = 600;
   public static final int MAX_YHEIGHT = 400;

   private static final int SQUARELENGTH = 10;

   private static final int MAXNSQUARES = 100;
   private Point[] squares = new Point[MAXNSQUARES];
   private int nsquares = 0;
   private int current = -1;
}



                        
