/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class CheckboxGroupTest extends CloseableFrame 
   implements ItemListener
{  public CheckboxGroupTest()
   {  Panel p = new Panel();
      p.setLayout(new FlowLayout());
      CheckboxGroup g = new CheckboxGroup();
      addCheckbox(p, "Small", g, false);
      addCheckbox(p, "Medium", g, true);    
      addCheckbox(p, "Large", g, false);    
      addCheckbox(p, "Extra large", g, false);
      add(p, "South");
      fox = new FoxCanvas();
      add(fox, "Center");
   }

   public void addCheckbox(Panel p, String name, 
      CheckboxGroup g, boolean v)
   {  Checkbox c = new Checkbox(name, g, v);
      c.addItemListener(this);
      p.add(c);
   }
   
   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.DESELECTED) 
         return;
      if (evt.getItem().equals("Small"))
         fox.setSize(8);
      else if (evt.getItem().equals("Medium"))
         fox.setSize(12);
      else if (evt.getItem().equals("Large"))
         fox.setSize(14);
      else if (evt.getItem().equals("Extra large"))
         fox.setSize(18);
   }

   public static void main(String[] args)
   {  Frame f = new CheckboxGroupTest();
      f.setSize(400, 200);
      f.show();  
   }
   
   private FoxCanvas fox;
}

class FoxCanvas extends Canvas
{  public FoxCanvas() 
   {  setSize(12); 
   }
   
   public void setSize(int p)
   {  setFont(new Font("SansSerif", Font.PLAIN, p));
      repaint();
   }
   
   public void paint(Graphics g)
   {  g.drawString
         ("The quick brown fox jumps over the lazy dog.", 0, 50);
   }
}
