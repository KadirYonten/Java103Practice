/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class ImageButtonTest extends CloseableFrame  
   implements ActionListener
{  public ImageButtonTest()
   {  setLayout(new FlowLayout());

      yellowButton = new ImageButton("yellow-ball.gif");
      add(yellowButton);
      yellowButton.addActionListener(this); 
      
      blueButton = new ImageButton("blue-ball.gif");
      add(blueButton);
      blueButton.addActionListener(this); 

      redButton = new ImageButton("red-ball.gif");
      add(redButton);
      redButton.addActionListener(this); 
   }
   
   public void actionPerformed(ActionEvent evt)
   {  Object src = evt.getSource();
      Color color = Color.black;
      if (src == yellowButton) color = Color.yellow;
      else if (src == blueButton) color = Color.blue;
      else if (src == redButton) color = Color.red;
      setBackground(color);
      repaint();
   }
   
   public static void main(String[] args)
   {  Frame f = new ImageButtonTest();
      f.show();
   }

   private ImageButton yellowButton;
   private ImageButton blueButton;
   private ImageButton redButton;
}

class ImageButton extends Component 
{  public ImageButton(String imgSrc) 
   {  image = Toolkit.getDefaultToolkit().getImage(imgSrc);
      MediaTracker tracker = new MediaTracker(this);
      tracker.addImage(image, 0);
      try { tracker.waitForID(0); } 
      catch (InterruptedException e) {}
      width = image.getWidth(this) + 2 * BORDER_XWIDTH;
      height = image.getHeight(this) + 2 * BORDER_YHEIGHT;

      enableEvents(AWTEvent.MOUSE_EVENT_MASK);
  }

   public void paint(Graphics g) 
   {  g.drawImage(image, BORDER_XWIDTH, BORDER_YHEIGHT, this);
      g.setColor(Color.gray);
      for (int i = 0; i <= (BORDER_XWIDTH+BORDER_YHEIGHT)/4; i++)
         g.draw3DRect(i, i, width - 2 * i - 1, 
            height - 2 * i - 1, !pressed);
   }
  
   public Dimension getPreferredSize() 
   {  return getMinimumSize();
   }
  
   public Dimension getMinimumSize() 
   {  return new Dimension(width, height);
   }

   public void addActionListener(ActionListener listener) 
   {  actionListener = 
         AWTEventMulticaster.add(actionListener, listener);
      enableEvents(AWTEvent.MOUSE_EVENT_MASK);
   }
 
   public void removeActionListener(ActionListener listener) 
   {  actionListener = 
         AWTEventMulticaster.remove(actionListener, listener);
   }

   public void processMouseEvent(MouseEvent e) 
   {  if (e.getID() == MouseEvent.MOUSE_PRESSED)
      {  pressed = true;
         repaint();
      }
      else if (e.getID() == MouseEvent.MOUSE_RELEASED)
      {  if(actionListener != null) 
            actionListener.actionPerformed(new ActionEvent(
               this, ActionEvent.ACTION_PERFORMED, "" + this));
         if (pressed)
         {  pressed = false;
            repaint();
         }
      }
      else if (e.getID() == MouseEvent.MOUSE_EXITED)
      {  if (pressed)
         {  pressed = false;
            repaint();
         }
      }
      super.processMouseEvent(e);
   }

   public static final int BORDER_XWIDTH = 5;
   public static final int BORDER_YHEIGHT = 5;
   private int width;
   private int height;
   private Image image; 
   private boolean pressed = false; 
   private ActionListener actionListener;     
}

