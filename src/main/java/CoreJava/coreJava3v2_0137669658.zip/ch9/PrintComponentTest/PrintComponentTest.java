/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class PrintComponentTest extends CloseableFrame
   implements ActionListener
{  public PrintComponentTest() 
   {  setLayout(new GridBagLayout());
      
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.weightx = 100;
      gbc.weighty = 0;
      add(new Label("Investment"), gbc, 0, 0, 1, 1);
      add(initialField, gbc, 1, 0, 1, 1);
      add(new Label("Years"), gbc, 2, 0, 1, 1);
      add(yearsField, gbc, 3, 0, 1, 1);
      add(new Label("% Interest"), gbc, 0, 1, 1, 1);
      add(interestField, gbc, 1, 1, 1, 1);
      gbc.fill = GridBagConstraints.NONE;
      Button computeButton = new Button("Compute");
      computeButton.addActionListener(this);
      add(computeButton, gbc, 2, 1, 1, 1);
      Button printButton = new Button("Print");
      printButton.addActionListener(this);
      add(printButton, gbc, 3, 1, 1, 1);

      gbc.weighty = 100;
      gbc.fill = GridBagConstraints.BOTH;
      add(savingsCanvas, gbc, 0, 2, 4, 1);
   }
      
   public void add(Component c, GridBagConstraints gbc, 
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }
   
   public void actionPerformed(ActionEvent evt)
   {  if (evt.getActionCommand().equals("Compute"))
      {  savingsCanvas.setSavings(initialField.getValue(),
            yearsField.getValue(),
            interestField.getValue());
      }
      else if (evt.getActionCommand().equals("Print"))
      {  PrintJob pjob = getToolkit().getPrintJob(this, 
            getTitle(), null);

         if (pjob != null) 
         {  Graphics pg = pjob.getGraphics();
            if (pg != null) 
            {  printAll(pg);
               pg.dispose(); // flush page
             }
             pjob.end();
         }
      }
   }

   public static void main(String[] args)
   {  Frame f = new PrintComponentTest();
      f.setSize(300,400);
      f.show();
   }

   private IntTextField initialField 
      = new IntTextField(10000, 10);      
   private IntTextField yearsField 
      = new IntTextField(15, 10);      
   private IntTextField interestField 
      = new IntTextField(10, 10);      
   private SavingsCanvas savingsCanvas = new SavingsCanvas();  
}

class SavingsCanvas extends Canvas
{  public void paint(Graphics g)
   {  double maxValue = 0;
      int i;
      for (i = 0; i <= years; i++)
      {  double v = getBalance(i);
         if (maxValue < v) maxValue = v;
      }
      if (maxValue == 0) return;
            
      Dimension d = getSize();
      int barHeight = (int)(d.height / (years + 1));
      double scale = d.height / maxValue;

      Font f = g.getFont();
      FontMetrics fm = g.getFontMetrics();
      g.setFont(new Font(f.getName(), f.getStyle(),
         f.getSize() * barHeight / fm.getHeight()));
      fm = g.getFontMetrics();
      
      for (i = 0; i <= years; i++)
      {  double v = getBalance(i);
         int x2 = (int)(d.width * v / maxValue);
         int y1 = i * barHeight;
         g.setColor(Color.yellow);
         g.fillRect(0, y1, x2, barHeight);         
         g.setColor(Color.black);
         g.drawRect(0, y1, x2, barHeight);         
         g.drawString(new Format("%.2f").form(v), 
            0, y1 + fm.getAscent());
      }
   }

   public void setSavings(double init, double y, double p)
   {  initial = init;
      years = y;
      interest = p;
      repaint();
   }
   
  public double getBalance(int year)
   {  if (year < 0) return 0;
      return initial * Math.pow(1 + interest / 1200,
         12 * year);
   }

   private double interest;
   private double years;
   private double initial;
}
