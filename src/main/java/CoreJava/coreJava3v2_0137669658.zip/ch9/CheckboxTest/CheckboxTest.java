/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class CheckboxTest extends CloseableFrame 
   implements ItemListener
{  public CheckboxTest()
   {  Panel p = new Panel();
      bold = addCheckbox(p, "Bold");    
      italic = addCheckbox(p, "Italic");    
      add(p, "South");
      fox = new FoxCanvas();
      add(fox, "Center");
   }
   
   public Checkbox addCheckbox(Panel p, String name)
   {  Checkbox c = new Checkbox(name);
      c.addItemListener(this);
      p.add(c);
      return c;
   }
   
   public void itemStateChanged(ItemEvent evt)
   {  int m = (bold.getState() ? Font.BOLD : 0) 
         + (italic.getState() ? Font.ITALIC : 0);
      fox.setFont(m);
   }

   public static void main(String[] args)
   {  Frame f = new CheckboxTest();
      f.show();  
   }

   private FoxCanvas fox;
   private Checkbox bold;
   private Checkbox italic;        
}

class FoxCanvas extends Canvas
{  public FoxCanvas() 
   { setFont(Font.PLAIN); 
   }

   public void setFont(int m)
   {  setFont(new Font("SansSerif", m, 12));
      repaint();
   }

   public void paint(Graphics g)
   {  g.drawString
         ("The quick brown fox jumps over the lazy dog.", 0, 50);
   }
}
