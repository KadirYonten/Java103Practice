/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class TextAreaTest extends CloseableFrame
   implements ActionListener
{  public TextAreaTest()
   {  Panel p = new Panel();

      printButton = new Button("Print");
      p.add(printButton);
      printButton.addActionListener(this);

      add(p, "South");
      ta = new TextArea(8, 40);
      add(ta, "Center");
   }

   public void actionPerformed(ActionEvent evt)
   {  PrintJob pjob = getToolkit().getPrintJob(this, 
         getTitle(), null);

      if (pjob != null) 
      {  Graphics pg = pjob.getGraphics();
         if (pg != null) 
         {  printAll(pg);
            pg.dispose(); // flush page
          }
          pjob.end();
      }
   }

   public static void main(String[] args)
   {  Frame f = new TextAreaTest();
      f.show();  
   }
   
   private TextArea ta;
   private Button printButton;
}


