/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class ValidationTest extends CloseableFrame
   implements TextListener
{  public ValidationTest()
   {  Panel p = new Panel();
      hourField = new IntTextField(12, 3);
      p.add(hourField);
      hourField.addTextListener(this);
      
      minuteField = new IntTextField(0, 3);
      p.add(minuteField);
      minuteField.addTextListener(this);
      
      add(p, "South");
      clock = new ClockCanvas();
      add(clock, "Center");
   }
   
   public void textValueChanged(TextEvent evt)
   {  clock.setTime(hourField.getValue(), minuteField.getValue());
   }
   
   public static void main(String[] args)
   {  Frame f = new ValidationTest();
      f.show();  
   }

   private IntTextField hourField;
   private IntTextField minuteField;
   private ClockCanvas clock;
}

class ClockCanvas extends Canvas
{  public void paint(Graphics g)
   {  g.drawOval(0, 0, 100, 100);
      double hourAngle 
         = 2 * Math.PI * (minutes - 3 * 60) / (12 * 60);
      double minuteAngle = 2 * Math.PI * (minutes - 15) / 60;
      g.drawLine(50, 50, 
         50 + (int)(30 * Math.cos(hourAngle)), 
         50 + (int)(30 * Math.sin(hourAngle)));
      g.drawLine(50, 50, 
         50 + (int)(45 * Math.cos(minuteAngle)), 
         50 + (int)(45 * Math.sin(minuteAngle)));
   }
   
   public void setTime(int h, int m)
   {  minutes = h * 60 + m;
      repaint();
   }
   
   public void tick()
   {  minutes++;  
      repaint();
   }
   
   private int minutes = 0;
}


