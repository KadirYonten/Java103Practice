/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class ColorSelect extends CloseableFrame 
   implements AdjustmentListener
{  public ColorSelect()
   {  Panel p = new Panel();
      p.setLayout(new GridLayout(3, 2));

      p.add(redLabel = new Label("Red 0"));
      p.add(red = new Scrollbar(Scrollbar.HORIZONTAL, 0, 0, 
         0, 255));
      red.setBlockIncrement(16);
      red.addAdjustmentListener(this);

      p.add(greenLabel = new Label("Green 0"));
      p.add(green = new Scrollbar(Scrollbar.HORIZONTAL, 0,
         0, 0, 255));
      green.setBlockIncrement(16);
      green.addAdjustmentListener(this);

      p.add(blueLabel = new Label("Blue 0"));
      p.add(blue = new Scrollbar(Scrollbar.HORIZONTAL, 0, 0,
         0, 255));
      blue.setBlockIncrement(16);
      blue.addAdjustmentListener(this);


      add(p, "South");
      
      c = new Canvas();
      c.setBackground(new Color(0, 0, 0));
      add(c, "Center");
   }

   public void adjustmentValueChanged(AdjustmentEvent evt)
   {  redLabel.setText("Red " + red.getValue());
      greenLabel.setText("Green " + green.getValue());         
      blueLabel.setText("Blue " + blue.getValue());
      c.setBackground(new Color(red.getValue(), 
         green.getValue(), blue.getValue()));
      
      c.repaint();
   }
   
   public static void main(String[] args)
   {  Frame f = new ColorSelect();
      f.show();  
   }
   
   private Label redLabel;
   private Label greenLabel;
   private Label blueLabel;

   private Scrollbar red;
   private Scrollbar green;
   private Scrollbar blue;
   
   private Canvas c;
}
