/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Jul 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import corejava.*;

public class ZipTest extends CloseableFrame 
   implements ActionListener
{  public ZipTest()
   {  MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      setMenuBar(mbar);
      fileList.addActionListener(this);
      
      add(fileList, "North");
      add(fileText, "Center");
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (evt.getSource() == fileList)
      {  loadZipFile(arg);
      }
      else if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open zip file", FileDialog.LOAD);
         d.setFile("*.zip");
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  zipname = lastDir + f;
            scanZipFile();            
         }
      }
      else if(arg.equals("Exit")) System.exit(0);
   }   

   public void scanZipFile()
   {  fileList.removeAll();
      try
      {  ZipInputStream zin = new ZipInputStream(new 
            FileInputStream(zipname));
         ZipEntry entry;
         while ((entry = zin.getNextEntry()) != null)
         {  fileList.add(entry.getName());
            zin.closeEntry();
         }
         zin.close();
      }
      catch(IOException e) {}
   }

   public void loadZipFile(String name)
   {  try
      {  ZipInputStream zin = new ZipInputStream(new 
            FileInputStream(zipname));
         ZipEntry entry;
         fileText.setText("");
         while ((entry = zin.getNextEntry()) != null)
         {  if (entry.getName().equals(name))
            {  BufferedReader in = new BufferedReader(new 
                  InputStreamReader(zin));
               String s;
               while ((s = in.readLine()) != null) 
                  fileText.append(s + "\n");
            }
            zin.closeEntry();
         }
         zin.close();
      }
      catch(IOException e) {}
   }

   public static void main(String args[])
   {  Frame f = new ZipTest();
      f.show();
   }

   private List fileList = new List();
   private TextArea fileText = new TextArea();
   private String lastDir = "";
   private String zipname;
}