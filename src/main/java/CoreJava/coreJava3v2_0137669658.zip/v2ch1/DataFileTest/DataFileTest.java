/*
 * Gary Cornell and Cay S. Horstmann, Core Java (Book/CD-ROM)
 * Published By SunSoft Press/Prentice-Hall
 * Copyright (C) 1996 Sun Microsystems Inc.
 * All Rights Reserved. ISBN 0-13-596891-7
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.01 07 Sep 1996 
 * @author Cay Horstmann
 */

import java.io.*;
import java.util.*;
import corejava.*;

public class DataFileTest
{  static void writeData(Employee[] e, PrintWriter os) 
      throws IOException
   {  Format.print(os, "%d\n", e.length);
      int i;
      for (i = 0; i < e.length; i++)
         e[i].writeData(os);
   }
   
   static Employee[] readData(BufferedReader is) 
      throws IOException
   {  int n = Format.atoi(is.readLine());
      Employee[] e = new Employee[n];
      int i;
      for (i = 0; i < n; i++)
      {  e[i] = new Employee();
         e[i].readData(is);
      }
      return e;
   }
         

   public static void main(String[] args)
   {  Employee[] staff = new Employee[3];

      staff[0] = new Employee("Harry Hacker", 35500, 
         new Day(1989,10,1));
      staff[1] = new Employee("Carl Cracker", 75000, 
         new Day(1987,12,15));
      staff[2] = new Employee("Tony Tester", 38000, 
         new Day(1990,3,15));
      int i;
      for (i = 0; i < staff.length; i++)
         staff[i].raiseSalary(5.25);
      
      try
      {  PrintWriter os = new PrintWriter(new 
            FileWriter("employee.dat"));
         writeData(staff, os);
         os.close();
      }
      catch(IOException e)
      {  System.out.print("Error: " + e);
         System.exit(1);
      }
      
      try
      {  BufferedReader is = new BufferedReader(new 
            FileReader("employee.dat"));   
         Employee[] in = readData(is);
         for (i = 0; i < in.length; i++) in[i].print();
         is.close();
      }
      catch(IOException e)
      {  System.out.print("Error: " + e);
         System.exit(1);
      }
   }
}


class Employee
{  public Employee(String n, double s, Day d)
   {  name = n;
      salary = s;
      hireDay = d;
   }
   public Employee() {}
   public void print()
   {  System.out.println(name + " " + salary 
         + " " + hireYear());
   }
   public void raiseSalary(double byPercent)
   {  salary *= 1 + byPercent / 100;
   }
   public int hireYear()
   {  return hireDay.getYear();
   }
   public void writeData(PrintWriter os) throws IOException
   {  Format.print(os, "%s|", name);
      Format.print(os, "%.14g|", salary);
      Format.print(os, "%d|", hireDay.getYear());
      Format.print(os, "%d|", hireDay.getMonth());
      Format.print(os, "%d\n", hireDay.getDay());
   }

   public void readData(BufferedReader is) throws IOException
   {  String s = is.readLine();
      StringTokenizer t = new StringTokenizer(s, "|");
      name = t.nextToken();
      salary = Format.atof(t.nextToken());
      int y = Format.atoi(t.nextToken());
      int m = Format.atoi(t.nextToken());
      int d = Format.atoi(t.nextToken());
      hireDay = new Day(y, m, d);
   }

   private String name;
   private double salary;
   private Day hireDay;
}

