/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */

/**
 * @version 1.00 11 Mar 1997
 * @author Cay Horstmann
 */
 
import java.io.*;
import java.text.*;

public class ReadDoubleTest 
   // shows how to read a double the hard way
{  public static void main(String[] args) 
   {  System.out.println
         ("Enter a number, I'll add two to it.");
      double x; // the number we wish to read
      try
      {  InputStreamReader isr 
            = new InputStreamReader(System.in);
         BufferedReader br 
            = new BufferedReader(isr);
         String s = br.readLine(); 
         DecimalFormat df = new DecimalFormat();
         Number n = df.parse(s);
         x = n.doubleValue();
      }
      catch(IOException e)
      {  x = 0;
      }
      catch(ParseException e)
      {  x = 0;
      }
      System.out.println(x + 2); 
   }
}   




