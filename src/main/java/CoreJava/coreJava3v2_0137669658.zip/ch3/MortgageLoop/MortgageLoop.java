/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Feb 1996 
 * @author Gary Cornell
 */

import corejava.*;

public class MortgageLoop
{  public static void main(String[] args)
   {  double principal;
      double yearlyInterest;
      int years;
 
      principal = Console.readDouble
         ("Loan amount (no commas):");
      yearlyInterest = Console.readDouble
         ("Interest rate in % (ex: use 7.5 for 7.5%):") / 100; 
      years = Console.readInt
         ("The number of years:");

      double y;
      for (y = yearlyInterest - 0.01; 
         y <= yearlyInterest + 0.01; y += 0.00125)         
      {  double monthlyInterest = y / 12;
         double payment = principal * monthlyInterest 
            / (1 - (Math.pow(1/(1 + monthlyInterest), 
               years * 12)));
         Format.print(System.out,
             "With rate %6.3f", 100 * y);
         Format.print(System.out, 
            "%%, your monthly payment is $%10.2f\n", payment);
      }
   }
}    

