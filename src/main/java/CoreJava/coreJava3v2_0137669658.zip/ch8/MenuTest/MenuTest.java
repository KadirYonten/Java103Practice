/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class MenuTest extends CloseableFrame 
   implements ActionListener, ItemListener
{  public MenuTest()
   {  MenuBar mbar = new MenuBar();

      mbar.add(makeMenu("File",
         new Object[] 
         {  "New", 
            "Open", 
            null, 
            "Save", 
            "Save As", 
            null, 
            "Print", 
            "Quit" 
         },
         this));

      mbar.add(makeMenu("Edit",
         new Object[] 
         {  "Undo", 
            "Redo", 
            null, 
            new MenuItem("Cut", 
               new MenuShortcut(KeyEvent.VK_LEFT)),
            new MenuItem("Copy", 
               new MenuShortcut(KeyEvent.VK_C)),
            new MenuItem("Paste", 
               new MenuShortcut(KeyEvent.VK_V)),
            makeMenu("Options",
               new Object[]
               {  new CheckboxMenuItem("Insert mode"),
                  new CheckboxMenuItem("Auto indent"),
               },
               this)
         },
         this));
        
      mbar.add(makeMenu("Help", 
         new Object[] 
         {  "Index", 
            "About",
         },
         this));

      setMenuBar(mbar);
   
      popup = new PopupMenu();
      makeMenu(popup, 
         new Object[] 
         {  "Cut", 
            "Copy", 
            "Paste" 
         },
         this);

      /* popup menus and keyboard shortcuts don't work in
         an empty frame, so we add some components
      */
      Panel p = new Panel();
      p.add(popup); // add popup menu to frame
      p.addMouseListener(new MouseAdapter() 
         {  public void mouseClicked(MouseEvent evt) 
            {  popup.show(evt.getComponent(), 
                  evt.getX(), evt.getY());
            } 
         });
      add(p, "Center");
      add(new TextField("Click below for popup menu"), 
         "North");
   }
      
   private static Menu makeMenu(Object parent, 
      Object[] items, Object target)
   {  Menu m = null;
      if (parent instanceof Menu)
         m = (Menu)parent;
      else if (parent instanceof String)
         m = new Menu((String)parent);
      else
         return null;

      for (int i = 0; i < items.length; i++)
      {  if (items[i] instanceof String)
         {  MenuItem mi = new MenuItem((String)items[i]);
            if (target instanceof ActionListener)
               mi.addActionListener((ActionListener)target);
            m.add(mi);
         }
         else if (items[i] instanceof CheckboxMenuItem
            && target instanceof ItemListener)
         {  CheckboxMenuItem cmi 
               = (CheckboxMenuItem)items[i];
            cmi.addItemListener((ItemListener)target);
            m.add(cmi);
         }
         else if (items[i] instanceof MenuItem)
         {  MenuItem mi = (MenuItem)items[i];
            if (target instanceof ActionListener)
               mi.addActionListener((ActionListener)target);
            m.add(mi);
         }
         else if (items[i] == null) 
            m.addSeparator();
      }

      return m;
   }
   
   public void actionPerformed(ActionEvent evt)
   {  MenuItem c = (MenuItem)evt.getSource();  
      String arg = c.getLabel();
      if(arg.equals("Quit"))
         System.exit(0);
      else if (arg.equals("About"))
         popup.show(this, 100, 100);
      else System.out.println(arg);
   }

   public void itemStateChanged(ItemEvent evt)
   {  CheckboxMenuItem c 
         = (CheckboxMenuItem)evt.getSource();
      System.out.print(c.getLabel() + " ");
      if (!c.getState()) System.out.print("de");
      System.out.println("selected");
   }

   public static void main(String args[])
   {  Frame f = new MenuTest();
      f.show();
   }

   private PopupMenu popup;
}

