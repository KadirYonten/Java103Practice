/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class Sketch extends CloseableFrame
   implements KeyListener
{  Sketch()
   {  addKeyListener(this);
   }

   public void keyPressed(KeyEvent evt)
   {  int keyCode = evt.getKeyCode();
      int modifiers = evt.getModifiers();
      int d;
      if ((modifiers & InputEvent.SHIFT_MASK) != 0) 
         d = 5; 
      else 
         d = 1;
      if (keyCode == KeyEvent.VK_LEFT) add(-d, 0);
      else if (keyCode == KeyEvent.VK_RIGHT) add(d, 0);
      else if (keyCode == KeyEvent.VK_UP) add(0, -d);
      else if (keyCode == KeyEvent.VK_DOWN) add(0, d);
   }
   
   public void keyReleased(KeyEvent evt)
   {}

   public void keyTyped(KeyEvent evt)
   {  char keyChar = evt.getKeyChar();
      int d;
      if (Character.isUpperCase(keyChar))
      {  d = 5; 
         keyChar = Character.toLowerCase(keyChar);
      }
      else 
         d = 1;
      if (keyChar == 'j') add(-d, 0);
      else if (keyChar == 'k') add(d, 0);
      else if (keyChar == 'i') add(0, -d);
      else if (keyChar == 'm') add(0, d);
   }
   
   public void update(Graphics g) 
   {  paint(g); 
      requestFocus();
   } 

   public void paint(Graphics g) 
   {  g.translate(getInsets().left, getInsets().top);
      g.drawLine(start.x, start.y, end.x, end.y);
      start.x = end.x;
      start.y = end.y;
   }

   public void add(int dx, int dy)
   {  end.x += dx;
      end.y += dy;
      repaint(); 
   }  
           
   public static void main(String[] args)
   {  Frame f = new Sketch();
      f.show();  
   }
   
   private Point start = new Point(0, 0);
   private Point end = new Point(0, 0); 
}

