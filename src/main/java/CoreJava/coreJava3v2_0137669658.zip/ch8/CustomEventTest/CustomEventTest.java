/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class CustomEventTest extends CloseableFrame
   implements TimerListener
{  public CustomEventTest()
   {  Timer t = new Timer(1000);
      t.addTimerListener(this);
   }

   public void timeElapsed(TimerEvent evt)
   {  Graphics g = getGraphics();
      g.translate(getInsets().left, getInsets().top);
      g.drawRect(0, 0, ticks, 10);
      ticks++;
   }

   public static void main(String[] args)
   {  CustomEventTest f = new CustomEventTest();
      f.show();
   }

   private int ticks = 0;
}

interface TimerListener
{  public void timeElapsed(TimerEvent evt);
}

class Timer extends Component implements Runnable
{  public Timer(int i) 
   {  interval = i;
      Thread t = new Thread(this);
      t.start();
      evtq = Toolkit.getDefaultToolkit()
         .getSystemEventQueue();
      enableEvents(0);
   }

   public void addTimerListener(TimerListener l)
   {  listener = l;
   }

   public void run()
   {  while (true)
      {  try { Thread.sleep(interval); } 
         catch(InterruptedException e) {}
         TimerEvent te = new TimerEvent(this); 
         evtq.postEvent(te);   
      }
   }

   public void processEvent(AWTEvent evt)
   {  if (evt instanceof TimerEvent)
      {  if (listener != null)
            listener.timeElapsed((TimerEvent)evt);
      }
      else super.processEvent(evt);
   }

   private int interval;
   private TimerListener listener;
   private static EventQueue evtq;
}

class TimerEvent extends AWTEvent
{  public TimerEvent(Timer t) { super(t, TIMER_EVENT); }
   public static final int TIMER_EVENT 
      = AWTEvent.RESERVED_ID_MAX  + 5555;
}