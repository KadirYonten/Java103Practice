/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class SeparateGUITest extends CloseableFrame 
   implements KeyListener
{  SeparateGUITest()
   {  blueCommand = new ColorCommand(Color.blue, this);
      yellowCommand = new ColorCommand(Color.yellow, this);
      redCommand = new ColorCommand(Color.red, this);
   
      MenuBar mbar = new MenuBar();
      Menu m = new Menu("Color");
      MenuItem mi;
      mi = new MenuItem("Yellow");
      mi.addActionListener(yellowCommand);
      m.add(mi);
      mi = new MenuItem("Blue");
      mi.addActionListener(blueCommand);
      m.add(mi);
      mi = new MenuItem("Red");
      mi.addActionListener(redCommand);
      m.add(mi);
      mbar.add(m);
      setMenuBar(mbar);

      setLayout(new FlowLayout());
      Button b;
      b = new Button("Yellow");
      b.addActionListener(yellowCommand);
      add(b);
      b = new Button("Blue");
      b.addActionListener(blueCommand);
      add(b);
      b = new Button("Red");
      b.addActionListener(redCommand);
      add(b);

      addKeyListener(this);
   }

   public void keyPressed(KeyEvent evt)
   {}
   
   public void keyReleased(KeyEvent evt)
   {}

   public void keyTyped(KeyEvent evt)
   {  char keyChar 
         = Character.toLowerCase(evt.getKeyChar());
      if (keyChar == 'b') blueCommand.execute();
      else if (keyChar == 'y') yellowCommand.execute();
      else if (keyChar == 'r') redCommand.execute();
   }

   public static void main(String args[])
   {  Frame f = new SeparateGUITest();
      f.show();
   }

   private ColorCommand blueCommand;
   private ColorCommand yellowCommand;
   private ColorCommand redCommand;
}

class ColorCommand implements ActionListener
{  public ColorCommand(Color c, Component comp)
   {  color = c;
      target = comp;
   }

   public void actionPerformed(ActionEvent evt)
   {  execute();
   }

   public void execute()
   {  target.setBackground(color);
   }

   private Color color;
   private Component target;
}

