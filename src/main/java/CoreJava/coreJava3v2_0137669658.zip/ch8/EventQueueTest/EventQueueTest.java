/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class EventQueueTest extends CloseableFrame
{  public void run()
   {  displayPrompt("Please click on a point");
      Point p = getClick();
      displayPrompt("Please click on another point");
      Point q = getClick();
      Graphics g = getGraphics();
      g.translate(getInsets().left, getInsets().top);
      g.drawLine(p.x, p.y, q.x, q.y);
      displayPrompt("Done!");
   }

   public void displayPrompt(String s)
   {  Graphics g = getGraphics();
      g.translate(getInsets().left, getInsets().top);
      g.clearRect(0, 0, getSize().width, 50);
      g.drawString(s, 0, 30);
   }

   public Point getClick()
   {  EventQueue eq 
         = Toolkit.getDefaultToolkit()
            .getSystemEventQueue();
      while (true)
      {  try
         {  AWTEvent evt = eq.getNextEvent();
            if (evt.getID() == MouseEvent.MOUSE_CLICKED)
            {  MouseEvent mevt = (MouseEvent)evt;
               Point p = mevt.getPoint();
               Graphics g = getGraphics();
               g.translate(getInsets().left, 
                  getInsets().top);
               g.drawOval(p.x - 2, p.y - 2, 4, 4);
               return p;         
            }
         }
         catch(InterruptedException e)
         {}
      }
   }

   public static void main(String[] args)
   {  EventQueueTest f = new EventQueueTest();
      f.show();
      f.run();
   }
}