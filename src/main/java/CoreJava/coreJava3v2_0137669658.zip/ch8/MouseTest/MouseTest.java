/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class MouseTest extends CloseableFrame 
   implements MouseMotionListener
{  public MouseTest()
   {  addMouseListener(new MouseAdapter() 
         {  public void mouseClicked(MouseEvent evt) 
            {  MouseTest.this.mouseClicked(evt); 
            } 
         });
      addMouseMotionListener(this);
   }

   public void paint(Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      for (int i = 0; i < nsquares; i++)
         draw(g, i);
   }
   
   public int find(int x, int y)
   {  for (int i = 0; i < nsquares; i++)
         if (squares[i].x - SQUARELENGTH / 2 <= x && 
               x <= squares[i].x + SQUARELENGTH / 2 
               && squares[i].y - SQUARELENGTH / 2 <= y 
               && y <= squares[i].y + SQUARELENGTH / 2)
            return i;
      return -1;
   }

   public void draw(Graphics g, int i)
   {  g.drawRect(squares[i].x - SQUARELENGTH / 2, 
         squares[i].y - SQUARELENGTH / 2, 
         SQUARELENGTH, 
         SQUARELENGTH);
   }

   public void add(int x, int y)
   {  if (nsquares < MAXNSQUARES)
      {  squares[nsquares] = new Point(x, y);
         nsquares++;
         repaint();
      }
   }

   public void remove(int n)
   {  nsquares--;
      squares[n] = squares[nsquares];
      if (current == n) current = -1;
      repaint();
   }

   public void mouseClicked(MouseEvent evt) 
   {  int x = evt.getX();
      int y = evt.getY();

      int modifiers = evt.getModifiers();
      int clickCount = evt.getClickCount();
      if ((modifiers & InputEvent.CTRL_MASK) != 0
         && (modifiers & InputEvent.SHIFT_MASK) != 0
         && clickCount >= 3)
      {  Graphics g = getGraphics();
         g.translate(getInsets().left, getInsets().top);
         g.drawString("Yikes", x, y);
         return;
      }
      
      current = find(x, y);
      if (current < 0) // not inside a square
      {  add(x, y);
      }
      else if (evt.getClickCount() >= 2)
      {  remove(current);
      }
   }

   public void mouseMoved(MouseEvent evt) 
   {  int x = evt.getX();
      int y = evt.getY();

      if (find(x, y) >= 0) 
         setCursor(Cursor.getPredefinedCursor(CROSSHAIR_CURSOR)); 
      else 
         setCursor(Cursor.getDefaultCursor());
   }

   public void mouseDragged(MouseEvent evt) 
   {  int x = evt.getX();
      int y = evt.getY();
      current = find(x, y);
      if (current >= 0)
      {  Graphics g = getGraphics();
         g.translate(getInsets().left, getInsets().top);
         g.setXORMode(getBackground());
         draw(g, current);      
         squares[current].x = x;
         squares[current].y = y;
         draw(g, current);      
         g.dispose();
      }
   }

   public static void main(String args[])
   {  Frame f = new MouseTest();
      f.show();
   }
   
   private static final int SQUARELENGTH = 10;

   private static final int MAXNSQUARES = 100;
   private Point[] squares = new Point[MAXNSQUARES];
   private int nsquares = 0;
   private int current = -1;
}



                        
