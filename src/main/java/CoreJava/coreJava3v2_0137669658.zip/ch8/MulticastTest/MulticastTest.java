/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class MulticastTest extends CloseableFrame
   implements ActionListener
{  public MulticastTest()
   {  MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      newItem = new MenuItem("New");
      newItem.addActionListener(this);
      m.add(newItem);
      closeAllItem = new MenuItem("Close all");
      m.add(closeAllItem);
      mbar.add(m);
      setMenuBar(mbar);
   }

   public void actionPerformed(ActionEvent evt)
   {  if (evt.getSource() == newItem)
      {  SimpleFrame f = new SimpleFrame();
         counter++;
         f.setTitle("Window " + counter);
         f.setSize(200, 150);
         f.setLocation(30 * counter, 30 * counter);
         f.show();
         closeAllItem.addActionListener(f);
      }
   }

   public static void main(String args[])
   {  new MulticastTest();
   }

   private int counter = 0;
   private MenuItem newItem;
   private MenuItem closeAllItem;
}

class SimpleFrame extends Frame 
   implements ActionListener
{  public void actionPerformed(ActionEvent evt)
   {  if (evt.getSource() instanceof MenuItem)
      {  MenuItem mi = (MenuItem)evt.getSource();
         if (mi.getLabel().equals("Close all"))
            dispose();
      }
   }
}