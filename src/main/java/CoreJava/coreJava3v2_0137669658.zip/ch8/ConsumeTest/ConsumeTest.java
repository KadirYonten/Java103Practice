/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import corejava.*;
import java.awt.*;
import java.awt.event.*;

public class ConsumeTest extends CloseableFrame
   implements ActionListener
{  public ConsumeTest()
   {  setLayout(new FlowLayout());

      yellowButton = new Button("Yellow");
      add(yellowButton);
      yellowButton.addActionListener(this); 
         // who is gonna listen? this frame

      blueButton = new Button("Blue");
      add(blueButton);
      blueButton.addActionListener(this); 

      redButton = new Button("Red");
      add(redButton);
      redButton.addActionListener(this); 

      redButton.addMouseListener(new MouseAdapter() 
         {  public void mousePressed(MouseEvent evt) 
            {  redButton.setLocation(rand.draw(), 
                  rand.draw());         
               evt.consume();
            } 
         });
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      Color color = Color.black;
      if (arg.equals("Yellow")) color = Color.yellow;
      else if (arg.equals("Blue")) color = Color.blue;
      else if (arg.equals("Red")) color = Color.red;
      setBackground(color);
      repaint();
   }
   
   public static void main(String[] args)
   {  Frame f = new ConsumeTest();
      f.show();
   }

   private Button yellowButton;
   private Button blueButton;
   private Button redButton;
   private RandomIntGenerator rand 
      = new RandomIntGenerator(50, 200);
}
