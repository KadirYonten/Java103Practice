/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Oct 1997
 * @author Gary Cornell
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import corejava.*;

public class TransparentImageFilterTest extends CloseableFrame
   implements ActionListener, AdjustmentListener
{  public TransparentImageFilterTest()
   {  MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      setMenuBar(mbar);

      scroller = new Scrollbar(Scrollbar.HORIZONTAL, 0, 0, 
         0, 100);
      scroller.setValue(50);
      scroller.setBlockIncrement(10);
      scroller.addAdjustmentListener(this);
      add(scroller, "South");

      setBackground(Color.yellow);
   }

   public double getScrollValue()
   {  return (double)scroller.getValue()
         / scroller.getMaximum();
   }

   public void adjustmentValueChanged(AdjustmentEvent evt)
   {  getFilteredImage(getScrollValue(), fileName);            
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open file", FileDialog.LOAD);
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  fileName = lastDir + f;
            getFilteredImage(getScrollValue(), fileName);            
         }
      }
      else if(arg.equals("Exit")) System.exit(0);
   }   

   public void getFilteredImage(double d, String file)
   {  Toolkit tk = Toolkit.getDefaultToolkit();
      orig = tk.getImage(file);
      ImageProducer prod = orig.getSource();
      ImageFilter filter = new TransparentImageFilter(d);
      ImageProducer filteredProd 
         = new FilteredImageSource(prod, filter);
      filtered = tk.createImage(filteredProd);
      repaint();
   }

   public void paint(Graphics g) 
   {  g.translate(getInsets().left, getInsets().top);
      if (filtered != null)
         g.drawImage(filtered, 0, 0, this);             
   }

   public static void main(String[] args)
   {  Frame f = new TransparentImageFilterTest();
      f.show();
   }

   private Image orig;
   private Image filtered;
   private String fileName = "";
   private String lastDir = "";
   private Scrollbar scroller;
} 

class TransparentImageFilter extends RGBImageFilter 
{  public TransparentImageFilter(double d)
      throws IllegalArgumentException 
   {  if ((d < 0.0) || (d > 1.0))
         throw new IllegalArgumentException();
      level = d;
      canFilterIndexColorModel = true;
   }

   public int filterRGB(int x, int y, int argb)   
   {  int alpha = (argb >> 24) & 0xFF;
      alpha = (int)(alpha * level);
      return ((argb & 0x00FFFFFF) | (alpha << 24));
   }

   private double level;
}
