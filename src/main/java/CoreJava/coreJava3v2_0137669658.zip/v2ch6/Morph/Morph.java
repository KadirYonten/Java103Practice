/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.0 07 Oct 1997
 * @author Cay Horstmann
 */

import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.net.*;
import corejava.*;

public class Morph extends CloseableFrame implements Runnable
{  public Morph()
   {  originalPixels = new int[SIZE * SIZE];
      for (int x = 0; x < SIZE; x++)
         for (int y = 0; y < SIZE; y++)
            if (inSquare(x, y))
               originalPixels[y * SIZE + x] = 0xFFFF00FF;
            else
               originalPixels[y * SIZE + x] = 0xFFFFFFFF;

      finalPixels = new int[SIZE * SIZE];
      for (int x = 0; x < SIZE; x++)
         for (int y = 0; y < SIZE; y++)
            if (inCircle(x, y))
               finalPixels[y * SIZE + x] = 0xFF007F7F;
            else
               finalPixels[y * SIZE + x] = 0xFFFFFFFF;
      
      anim = new Thread(this);
      anim.start();
   }

   private boolean inSquare(int x, int y)
   {  return SIZE / 10 <= x && x <= SIZE * 9 / 10
         && SIZE / 10 <= y && y <= SIZE * 9 / 10;
   }

   private boolean inCircle(int x, int y)
   {  double dx = x - SIZE / 2;
      double dy = y - SIZE / 2;
      return (dx * dx) / (SIZE * SIZE / 4) +
         (dy * dy) / (SIZE * SIZE / 4) <= 1;
   }

   public static void main(String[] args)
   {  Frame f = new Morph();
      f.show();
   }

   public void run()
   {  intermediatePixels = new int[SIZE * SIZE];
      System.arraycopy(originalPixels, 0,
         intermediatePixels, 0, SIZE * SIZE);
      MemoryImageSource mis 
         = new MemoryImageSource(SIZE, SIZE,
            intermediatePixels, 0, SIZE);       
      mis.setAnimated(true);
      theImage = createImage(mis);
      repaint();
      try
      {  double t = 0;
         int direction = 1;
         while (true)
         {  t = t + direction * 0.05;
            if (t <= 0 || t >= 1) direction *= -1;
            interpolatePixels(t);
            mis.newPixels();
            repaint();
            anim.sleep(100);
         } 
      }
      catch(InterruptedException e){}
   }

   public void paint(Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      g.drawImage(theImage, 0, 0, SIZE, SIZE, null);   
   }

   public void update(Graphics g)
   {  paint(g);
   }

   private void interpolatePixels(double t) 
   {  for(int i = 0; i < SIZE * SIZE; i++)
      {  int p = originalPixels[i];
         int q = finalPixels[i];

         int r = (int)((1 - t) * (p & 0xFF0000) 
            + t * (q  & 0xFF0000)) & 0xFF0000;
         int g = (int)((1 - t) * (p & 0xFF00) 
            + t * (q & 0xFF00)) & 0xFF00;
         int b = (int)((1 - t) * (p & 0xFF) 
            + t * (q & 0xFF));

         intermediatePixels[i] = 0xFF000000 | r | g | b;
      }
   }
    
   private Image theImage;
   private int[] originalPixels;
   private int[] finalPixels;
   private int[] intermediatePixels;
   private Thread anim;
   private static final int SIZE = 100;
}

