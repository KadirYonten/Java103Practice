/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Oct 1997
 * @author Gary Cornell
 */

import java.awt.*;
import java.awt.image.*;
import corejava.*;

public class MemoryImageTest extends CloseableFrame
{  public void paint (Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      if (memImage == null)
         memImage=createImage(new MemoryImageSource(9, 6, 
            pixArray, 0, 9));
      g.drawImage(memImage, 0, 0, 90, 60, this);
      // scale 9 x 6 image to 90 x 60
   }   
     
   public static void main (String[] args)
   {  Frame f = new MemoryImageTest();
      f.show();
   }

   private int[] pixArray = 
   {  0, 0xFFFF00FF, 0xFFFF00FF, 0, 0, 
      0xFF007F7F, 0xFF007F7F, 0xFF007F7F, 0xFF007F7F,
      0xFFFF00FF, 0, 0, 0xFFFF00FF, 0,
      0, 0, 0xFF007F7F, 0,
      0xFFFF00FF, 0, 0, 0, 0, 
      0, 0, 0xFF007F7F, 0,
      0xFFFF00FF, 0, 0, 0, 0,
      0, 0, 0xFF007F7F, 0,
      0xFFFF00FF, 0, 0, 0xFFFF00FF, 0,
      0xFF007F7F, 0, 0xFF007F7F, 0, 
      0, 0xFFFF00FF, 0xFFFF00FF, 0, 0, 
      0, 0xFF007F7F, 0, 0
   };


   private Image memImage;
}
