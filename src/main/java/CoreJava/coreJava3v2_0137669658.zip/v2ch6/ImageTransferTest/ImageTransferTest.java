/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Oct 1997
 * @author Gary Cornell
 */

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import corejava.*;

public class ImageTransferTest extends CloseableFrame 
   implements ActionListener
{  public ImageTransferTest()
   {  MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      m = new Menu("Edit");
      MenuItem m3 = new MenuItem("Copy");
      m3.addActionListener(this);
      m.add(m3);            
      MenuItem m4 = new MenuItem("Paste");
      m4.addActionListener(this);
      m.add(m4);            
      mbar.add(m);
      setMenuBar(mbar);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open file", FileDialog.LOAD);
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  theImage = Toolkit.getDefaultToolkit().getImage
               (lastDir + f);
            repaint();
         }
      }
      else if(arg.equals("Exit")) System.exit(0);
      else if (arg.equals("Copy")) copyIt();
      else if (arg.equals("Paste")) pasteIt();
   }   

   public void paint(Graphics g) 
   {  g.translate(getInsets().left, getInsets().top);
      if(theImage != null)
         g.drawImage(theImage, 0, 0, this);             
   }
   
   private void copyIt()
   {  ImageSelection selection = new ImageSelection(theImage);
      localClipboard.setContents(selection, null);
   }
   
   private void pasteIt()
   {  Transferable selection 
         = localClipboard.getContents(this);
      try
      {  theImage = (Image)selection.getTransferData
            (ImageSelection.imageFlavor);
         repaint();
      }
      catch(Exception e) {}
   }
   
   public static void main(String [] args)
   {  Frame f1 = new ImageTransferTest();
      Frame f2 = new ImageTransferTest();
      f1.setTitle("Frame 1");
      f2.setTitle("Frame 2");
      f2.setLocation(300, 100);
      f1.show();
      f2.show();
   }

   private static Clipboard localClipboard 
      = new Clipboard("local");
   private Image theImage;
   private String lastDir = "";
}

class ImageSelection implements Transferable
{  public ImageSelection(Image image) 
   {  theImage = image;
   }
   
   public DataFlavor[] getTransferDataFlavors() 
   {  return flavors;
   }

   public boolean isDataFlavorSupported(DataFlavor flavor) 
   {  return flavor.equals(imageFlavor);
   }
   
   public synchronized Object getTransferData
      (DataFlavor flavor) 
      throws UnsupportedFlavorException
   {  if(flavor.equals(imageFlavor)) 
      {  return theImage;
      }
      else 
      {  throw new UnsupportedFlavorException(flavor);
      }
   }

   public static final DataFlavor imageFlavor
      = new DataFlavor(java.awt.Image.class, "AWT Image");

   private static DataFlavor[] flavors = { imageFlavor }; 
   private Image theImage;
}
