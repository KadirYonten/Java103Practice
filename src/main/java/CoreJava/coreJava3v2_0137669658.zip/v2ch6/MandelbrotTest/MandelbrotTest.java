/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Oct 1997
 * @author Gary Cornell
 */

import java.awt.*;
import java.awt.image.*;
import corejava.*;

public class MandelbrotTest extends CloseableFrame
{  public static void main (String[] args)
   {  Frame f = new MandelbrotTest(300, 300, 2.0, 2.0);
      f.setSize(400,400);
      f.show();
   }

   public MandelbrotTest(int h, int w, double x, double y)
   {  width = w;
      height = h;
      xSize = x;
      ySize = y;
      xOffset = (2.0 * xSize) / width;
      yOffset = (2.0 * ySize) / height; 
      memImage = createImage(new MemoryImageSource(width, 
         height, pixArray(), 0, width));
   }    
     
   public void update(Graphics g)
   // to avoid flicker--see vol. 1 ch. 7
   {  paint(g);
   }

   public void paint(Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      g.drawImage(memImage, 0, 0, null);
   }   
     
   public int[] pixArray()
   {  int[] pixels = new int[height * width];
      for (int i = 0; i < height; i++)
         for (int j = 0; j < width; j++)
            if (escapesToInfinity(i, j))
               pixels[i * width + j] = 0xFF000000;
            else
               pixels[i * width + j] = 0xFFFFFFFF;
      return pixels;     
   }
      
   private boolean escapesToInfinity(int row, int col)
   {  double xCoord = - xSize + col * xOffset;
      double yCoord = - ySize + row * yOffset; 
      double xValue = 0.0;
      double yValue = 0.0;
      int iterations = 0;
      while (iterations < MAX_ITERATIONS)
      {  xValue = (xValue * xValue) 
            - (yValue * yValue) + xCoord;
         yValue = (2 * xValue * yValue) + yCoord;
         if (xValue > 2 || yValue > 2) break;
         iterations++;
      }   
      return iterations == MAX_ITERATIONS;
   }
        
   private Image memImage;
   private int width;
   private int height;
   private double xSize;
   private double ySize;
   private double xOffset;
   private double yOffset;
   private int MAX_ITERATIONS = 16;
}
