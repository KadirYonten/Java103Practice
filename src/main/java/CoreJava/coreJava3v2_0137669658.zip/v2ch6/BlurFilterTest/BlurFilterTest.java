/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import corejava.*;

public class BlurFilterTest extends CloseableFrame
   implements ActionListener, AdjustmentListener
{  public BlurFilterTest()
   {  MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      setMenuBar(mbar);

      scroller = new Scrollbar(Scrollbar.HORIZONTAL, 0, 0, 
         0, 100);
      scroller.setValue(50);
      scroller.setBlockIncrement(10);
      scroller.addAdjustmentListener(this);
      add(scroller, "South");
   }

   public double getScrollValue()
   {  return (double)scroller.getValue() 
         / scroller.getMaximum();
   }

   public void adjustmentValueChanged(AdjustmentEvent evt)
   {  getFilteredImage(getScrollValue(), fileName);            
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open file", FileDialog.LOAD);
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  fileName = lastDir + f;
            getFilteredImage(getScrollValue(), fileName);            
         }
      }
      else if(arg.equals("Exit")) System.exit(0);
   }   

   public void getFilteredImage(double d, String file)
   {  Toolkit tk = Toolkit.getDefaultToolkit();
      orig = tk.getImage(file);
      ImageProducer prod = orig.getSource();
      ImageFilter filter = new BlurFilter(d);
      ImageProducer filteredProd 
         = new FilteredImageSource(prod, filter);
      filtered = tk.createImage(filteredProd);
      repaint();
   }

   public void paint(Graphics g) 
   {  g.translate(getInsets().left, getInsets().top);
      if (filtered != null)
         g.drawImage(filtered, 0, 0, this);             
   }

   public static void main(String[] args)
   {  Frame f = new BlurFilterTest();
      f.show();
   }

   private Image orig;
   private Image filtered;
   private String fileName = "";
   private String lastDir = "";
   private Scrollbar scroller;
} 

class BlurFilter extends ImageFilter 
{  public BlurFilter(double d)
      throws IllegalArgumentException 
   {  if ((d < 0.0) || (d > 1.0))
         throw new IllegalArgumentException();
      level = d;
   }

   public void setPixels(int x, int y, int w, int h,
      ColorModel model, byte pixels[],
      int off, int scansize)
   {  
      if (incremental)
      {  for (int i = 0; i < h; i++)
         {  emitFilteredScanLine();
            for (int j = 0; j < w; j++)
            {
               inPixels[2][j] 
                  = model.getRGB(0xFF & pixels[i * scansize 
                     + j + off]); 
            }
         }
      }
      else
      {  if (bufferPixels == null) 
            bufferPixels = new int[width * height];
         for (int i = 0; i < h; i++)
            for (int j = 0; j < w; j++)
               bufferPixels[(i + y) * width + j + x] 
                  = model.getRGB(pixels[i * scansize 
                     + j + off]); 
      }
   }

   public void setPixels(int x, int y, int w, int h,
      ColorModel model, int pixels[],
      int off, int scansize)
   {  if (incremental)
      {  for (int i = 0; i < h; i++)
         {   emitFilteredScanLine();
             for (int j = 0; j < w; j++)
                 inPixels[2][j] 
                    = model.getRGB(pixels[i * scansize 
                       + j + off]); 
         }
      }
      else
      {  if (bufferPixels == null) 
            bufferPixels = new int[width * height];
         for (int i = 0; i < h; i++)
            for (int j = 0; j < w; j++)
               bufferPixels[(i + y) * width + j + x] 
                  = model.getRGB(pixels[i * scansize 
                     + j + off]); 
      }
   }

   public void imageComplete(int status)
   {  if (status == ImageConsumer.STATICIMAGEDONE  
         || status == ImageConsumer.SINGLEFRAMEDONE)
      {  if (!incremental)
         {  for (int i = 0; i < height; i++)
            {  emitFilteredScanLine();
               for (int j = 0; j < width; j++)
               {  inPixels[2][j] 
                     = bufferPixels[i * width + j]; 
               }
            }
         }
         emitFilteredScanLine();
         emitFilteredScanLine();
      }
      super.imageComplete(status);
   }

   public void emitFilteredScanLine()
   {  if (inPixels == null)
      {  inPixels = new int[3][width];
         outPixels = new int[width];
         yout = -2;
      }
      if (yout >= 0)
      {  for (int i = 0; i < width; i++)
         {  int count = 0;
            int asum = 0;
            int rsum = 0;
            int gsum = 0;
            int bsum = 0;
            for (int y = -1; y <= 1; y++)
               for (int x = -1; x <= 1; x++)
                  if (0 <= yout + y && yout + y < height
                     && 0 <= i + x && i + x < width)
                  {  count++;
                     int p = inPixels[1 + y][i + x];
                     asum += (p >> 24) & 0xFF;
                     rsum += (p >> 16) & 0xFF;
                     gsum += (p >> 8)  & 0xFF;
                     bsum += p         & 0xFF;
                  }

            int p = inPixels[1][i];
            int a = (int)((level * asum) / count 
               + (1 - level) * ((p >> 24) & 0xFF));
            int r = (int)((level * rsum) / count 
               + (1 - level) * ((p >> 16) & 0xFF));
            int g = (int)((level * gsum) / count 
               + (1 - level) * ((p >> 8) & 0xFF));
            int b = (int)((level * bsum) / count 
               + (1 - level) * (p & 0xFF));

            outPixels[i] = (a << 24) | (r << 16) 
               | (g << 8) | b;
         }
         super.setPixels(0, yout, width, 1,
            ColorModel.getRGBdefault(), outPixels, 0, width);
      }
      int[] temp = inPixels[0];
      inPixels[0] = inPixels[1];
      inPixels[1] = inPixels[2];
      inPixels[2] = temp;
      yout++;
   }

   public void setColorModel(ColorModel model)
   {  super.setColorModel(ColorModel.getRGBdefault());
   }

   public void setDimensions(int w, int h) 
   {  width = w; height = h; 
      super.setDimensions(w, h);
   }

   public void setHints(int h)
   {  incremental = (h & ImageConsumer.TOPDOWNLEFTRIGHT) != 0
         && (h & ImageConsumer.COMPLETESCANLINES) != 0
         && (h & ImageConsumer.SINGLEPASS) != 0;
      super.setHints(ImageConsumer.TOPDOWNLEFTRIGHT |
         ImageConsumer.COMPLETESCANLINES);
   }

   private boolean incremental = false;
   private int width;
   private int height;
   private double level;
   private int yout;
   private int[] bufferPixels;
   private int[][] inPixels;
   private int[] outPixels;
}
