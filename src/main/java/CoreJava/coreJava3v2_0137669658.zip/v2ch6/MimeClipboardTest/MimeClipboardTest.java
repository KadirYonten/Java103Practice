/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 10 Oct 1997
 * @author Cay Horstmann
 */

import java.io.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import corejava.*;

public class MimeClipboardTest extends CloseableFrame 
   implements ActionListener
{  public MimeClipboardTest()
   {  MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      m = new Menu("Edit");
      MenuItem m3 = new MenuItem("Copy");
      m3.addActionListener(this);
      m.add(m3);            
      MenuItem m4 = new MenuItem("Paste");
      m4.addActionListener(this);
      m.add(m4);            
      mbar.add(m);
      setMenuBar(mbar);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open file", FileDialog.LOAD);
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  theImage = Toolkit.getDefaultToolkit().getImage
               (lastDir + f);
            theBitmap = new Bitmap(theImage);
            repaint();
         }
      }
      else if(arg.equals("Exit")) System.exit(0);
      else if (arg.equals("Copy")) copyIt();
      else if (arg.equals("Paste")) pasteIt();
   }   

   public void paint(Graphics g) 
   {  g.translate(getInsets().left, getInsets().top);
      if(theImage != null)
         g.drawImage(theImage, 0, 0, this);             
   }
   
   private void copyIt()
   {  SerializableSelection selection 
         = new SerializableSelection(theBitmap);
      mimeClipboard.setContents(selection, null);
   }
   
   private void pasteIt()
   {  Transferable selection 
         = mimeClipboard.getContents(this);
      try
      {  theBitmap = (Bitmap)selection.getTransferData
            (SerializableSelection.serializableFlavor);
         theImage = theBitmap.getImage();
         repaint();
      }
      catch(Exception e) {}
   }
   
   public static void main(String [] args)
   {  Frame f = new MimeClipboardTest();
      f.show();
   }

   private static Clipboard mimeClipboard
      = new MimeClipboard
         (Toolkit.getDefaultToolkit().getSystemClipboard());
   private Bitmap theBitmap;
   private Image theImage;
   private String lastDir = "";
}

class Bitmap implements Serializable
{  public Bitmap(Image img)
   {  try
      {  PixelGrabber pg 
            = new PixelGrabber(img, 0, 0, -1, -1, true);
         if (pg.grabPixels())
         {  width = pg.getWidth();
            height = pg.getHeight();
            pixels = (int [])pg.getPixels();
         }           
      } 
      catch(InterruptedException e) {}
   }
   
   public Image getImage()
   {  return Toolkit.getDefaultToolkit().createImage(new
         MemoryImageSource(width, height, pixels, 0, width));
   }

   private int width;
   private int height;
   private int[] pixels;
}

class SerializableSelection implements Transferable
{  public SerializableSelection(Serializable object) 
   {  theObject = object;
   }
   
   public boolean isDataFlavorSupported(DataFlavor flavor) 
   {  return flavor.equals(serializableFlavor);
   }
   
   public synchronized Object getTransferData
      (DataFlavor flavor) 
      throws UnsupportedFlavorException
   {  if(flavor.equals(serializableFlavor)) 
      {  return theObject;
      }
      else 
      {  throw new UnsupportedFlavorException(flavor);
      }
   }

   public DataFlavor[] getTransferDataFlavors() 
   {  return flavors;
   }

   public static final DataFlavor serializableFlavor
      = new DataFlavor(java.io.Serializable.class, 
      "Serializable Object");

   private static DataFlavor[] flavors 
      = { serializableFlavor }; 

   private Serializable theObject;
}

class MimeClipboard extends Clipboard
{  public MimeClipboard(Clipboard cb) 
   {  super("MIME/" + cb.getName());
      clip = cb;
   }

   public synchronized void setContents(Transferable contents, 
      ClipboardOwner owner) 
   {  if (contents instanceof SerializableSelection) 
      {  try
         {  DataFlavor flavor 
               = SerializableSelection.serializableFlavor;
            Serializable obj = (Serializable)
               contents.getTransferData(flavor);
            String enc = encode(obj);
            String header = "Content-type: " 
               + flavor.getMimeType()
               + "\nContent-length: " 
               + enc.length() + "\n\n";
            StringSelection selection 
               = new StringSelection(header + enc);
            clip.setContents(selection, owner);
         }
         catch(UnsupportedFlavorException e)
         {}
         catch(IOException e)
         {}
      }
      else clip.setContents(contents, owner);
   }

   public synchronized Transferable getContents
      (Object requestor) 
   {  Transferable contents = clip.getContents(requestor);

      if (contents instanceof StringSelection)
      {  String data = null;
         try  
         {  data = (String)contents.getTransferData
               (DataFlavor.stringFlavor);
         }
         catch(UnsupportedFlavorException e)
         { return contents; }
         catch(IOException e)
         { return contents; }

         if (!data.startsWith("Content-type: "))
            return contents;
         int start = -1;
         // skip three newlines
         for (int i = 0; i < 3; i++)
         {  start = data.indexOf('\n', start + 1);
            if (start < 0) return contents;
          }
         Serializable obj = decode(data, start);
         SerializableSelection selection
            = new SerializableSelection(obj);
         return selection;
      }
      else return contents;
   }

   private static String encode(Serializable obj)
   {  try
      {  StringBuffer sbuf = new StringBuffer();
         Base64OutputStream bout
            = new Base64OutputStream(sbuf);
         ObjectOutputStream out
            = new ObjectOutputStream(bout);
         out.writeObject(obj);
         out.flush();
         return sbuf.toString();
      }  
      catch(Exception e)
      {  return "";
      } 
   }

   private static Serializable decode(String s, int start)
   {  try
      {  Base64InputStream bin
            = new Base64InputStream(s, start);
         ObjectInputStream in
            = new ObjectInputStream(bin);
         Object obj = in.readObject();
         return (Serializable)obj;
      }  
      catch(Exception e)
      {  return null;
      } 
   }

   private Clipboard clip;
}

/* BASE64 encoding encodes 3 bytes into 4 characters.
   |11111122|22223333|33444444|
   Each set of 6 bits is encoded according to the 
   toBase64 map. If the number of input bytes is not
   a multiple of 3, then the last group of 4 characters
   is padded with one or two = signs. Each output line
   is at most 76 characters.
*/

class Base64OutputStream extends OutputStream
{  public Base64OutputStream(StringBuffer sb)
   {  sbuf = sb;
   }

   public void write(int c) throws IOException
   {  inbuf[i] = c;
      i++;
      if (i == 3)
      {  sbuf.append(toBase64[(inbuf[0] & 0xFC) >> 2]);
         sbuf.append(toBase64[((inbuf[0] & 0x03) << 4) |
            ((inbuf[1] & 0xF0) >> 4)]);
         sbuf.append(toBase64[((inbuf[1] & 0x0F) << 2) |
            ((inbuf[2] & 0xC0) >> 6)]);
         sbuf.append(toBase64[inbuf[2] & 0x3F]);   
         col += 4;
         i = 0;
         if (col >= 76)
         {  sbuf.append('\n');
            col = 0;
         }
      }
   }

   public void flush()
   {  if (i == 1)
      {  sbuf.append(toBase64[(inbuf[0] & 0xFC) >> 2]);
         sbuf.append(toBase64[(inbuf[0] & 0x03) << 4]);
         sbuf.append('=');
         sbuf.append('=');
      }
      else if (i == 2)
      {  sbuf.append(toBase64[(inbuf[0] & 0xFC) >> 2]);
         sbuf.append(toBase64[((inbuf[0] & 0x03) << 4) |
            ((inbuf[1] & 0xF0) >> 4)]);
         sbuf.append(toBase64[(inbuf[1] & 0x0F) << 2]);
         sbuf.append('=');
      }
      sbuf.append('\n');
   }

   private static char[] toBase64 =
   {  'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
      'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
      'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
      'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
      'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
      'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
      'w', 'x', 'y', 'z', '0', '1', '2', '3',
      '4', '5', '6', '7', '8', '9', '+', '/'
   };
   
   StringBuffer sbuf;
   int col = 0;
   int i = 0;
   int[] inbuf = new int[3];
}

class Base64InputStream extends InputStream
{  public Base64InputStream(String s, int start)
   {  str = s;
      pos = start;
      i = 0;
   }

   public int read() 
   {  while (pos < str.length() && 
         Character.isWhitespace(str.charAt(pos)))
      {  pos++;
      }
      if (pos >= str.length()) return -1;
      if (i == 0)
      {  int ch1 = str.charAt(pos) & 0x7F;
         int ch2 = str.charAt(pos + 1) & 0x7F;
         i++;
         return (fromBase64[ch1] << 2)
            | (fromBase64[ch2] >> 4);
      }
      else if (i == 1)
      {  int ch1 = str.charAt(pos + 1) & 0x7F;
         int ch2 = str.charAt(pos + 2) & 0x7F;
         if (ch2 == '=') return -1;
         i++;
         return ((fromBase64[ch1] & 0x0F) << 4)
            | (fromBase64[ch2] >> 2);
      }
      else
      {  int ch1 = str.charAt(pos + 2) & 0x7F;
         int ch2 = str.charAt(pos + 3) & 0x7F;
         if (ch2 == '=') return -1;
         i = 0;
         pos += 4;
         return ((fromBase64[ch1] & 0x03) << 6)
            | fromBase64[ch2];
      }
   }

   private static int[] fromBase64 =
   {  -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, 62, -1, -1, -1, 63,
      52, 53, 54, 55, 56, 57, 58, 59,
      60, 61, -1, -1, -1, -1, -1, -1,
      -1,  0,  1,  2,  3,  4,  5,  6,
       7,  8,  9, 10, 11, 12, 13, 14,
      15, 16, 17, 18, 19, 20, 21, 22,
      23, 24, 25, -1, -1, -1, -1, -1,
      -1, 26, 27, 28, 29, 30, 31, 32,
      33, 34, 35, 36, 37, 38, 39, 40,
      41, 42, 43, 44, 45, 46, 47, 48,
      49, 50, 51, -1, -1, -1, -1, -1
   };

   String str;
   int pos;
   int i;
}
