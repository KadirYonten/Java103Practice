/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Oct 1997
 * @author Gary Cornell
 */

import java.io.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import corejava.*;


public class TextTransferTest 
   extends CloseableFrame implements ActionListener
{  public TextTransferTest()
   {  add (textArea, "Center");
      Panel p = new Panel();
      Button copy = new Button ("Copy");
      p.add(copy);
      copy.addActionListener(this);
      Button paste = new Button ("Paste");
      p.add (paste);
      paste.addActionListener(this);
      add (p, "South");
      sysClipboard 
         = Toolkit.getDefaultToolkit().getSystemClipboard();
   }
    
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Copy")) copyIt();
      else if (arg.equals("Paste")) pasteIt();
   }
     
   private void copyIt()
   {  String text = textArea.getSelectedText();
      if (text.equals("")) text = textArea.getText();
      StringSelection selection = new StringSelection(text);
      sysClipboard.setContents(selection, null);
   }
   
   private void pasteIt()
   {  String text;
      Transferable selection = sysClipboard.getContents(this);
      {  try
         {  text = (String)(selection.getTransferData
               (DataFlavor.stringFlavor));
            int start = textArea.getSelectionStart();
            int end = textArea.getSelectionEnd();
            textArea.replaceRange(text, start, end);
         }
         catch(Exception e)
         {}
      }
   }
   
   public static void main(String[] args)
   {  Frame f = new TextTransferTest();
      f.show();
   }
   
   private TextArea textArea = new TextArea();
   private Clipboard sysClipboard;
}
