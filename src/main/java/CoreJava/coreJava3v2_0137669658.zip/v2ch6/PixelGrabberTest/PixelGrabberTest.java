/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.0 07 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import corejava.*;

public class PixelGrabberTest extends CloseableFrame
   implements ActionListener
{  public PixelGrabberTest()
   {  MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      setMenuBar(mbar);
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open file", FileDialog.LOAD);
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
         {  fileName = lastDir + f;
            transposeImage(fileName);            
         }
      }
      else if(arg.equals("Exit")) System.exit(0);
   }   

   public void transposeImage(String f)
   {  Image image = Toolkit.getDefaultToolkit().getImage(f);
      PixelGrabber grabber 
         = new PixelGrabber(image, 0, 0, -1, -1, true);
      try
      {  if (grabber.grabPixels())
         {  width = grabber.getWidth();
            height = grabber.getHeight();
            int[] pixels = (int[])grabber.getPixels();
            int[] transposedPixels = new int[height * width];
            for (int x = 0; x < width; x++)
               for (int y = 0; y < height; y++)
                  transposedPixels[x * height + y] 
                     = pixels[y * width + x];
            transposedImage = createImage(new 
               MemoryImageSource(height, width, 
                  transposedPixels, 0, height));
            repaint();
         }
      }
      catch(InterruptedException e) {}
   }

   public void paint (Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      if (transposedImage != null)
         g.drawImage(transposedImage, 0, 0, 
            height, width, this);
   }   
     
   public static void main (String[] args)
   {  Frame f = new PixelGrabberTest();
      f.show();
   }

   private Image transposedImage;
   private int width;
   private int height;
   private String fileName = "";
   private String lastDir = "";
}
