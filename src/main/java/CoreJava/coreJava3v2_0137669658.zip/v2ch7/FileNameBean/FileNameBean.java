/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.beans.*;

public class FileNameBean extends Panel 
   implements ActionListener
{  public FileNameBean()
   {  setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.weightx = 100;
      gbc.weighty = 100;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      add(nameField, gbc, 0, 0, 1, 1);
      dialogButton.addActionListener(this);
      nameField.setEditable(false);      
      gbc.weightx = 0;
      gbc.anchor = GridBagConstraints.EAST;
      gbc.fill = GridBagConstraints.NONE;
      add(dialogButton, gbc, 1, 0, 1, 1);
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void actionPerformed(ActionEvent evt)
   {  if (evt.getSource() == dialogButton)
         showFileDialog();
   }

   public void showFileDialog()
   {  if (fileDialog == null)
      {  Container c = getParent();
         while (c != null && !(c instanceof Frame))
         {  c = c.getParent();
         }

         if (c != null)
            fileDialog = new FileDialog((Frame)c, title);
      }
      if (fileDialog == null) return; 
  
      fileDialog.setFile(defaultExtension);
      fileDialog.setDirectory(lastDir);
      fileDialog.show();
      String f = fileDialog.getFile();
      lastDir = fileDialog.getDirectory();
      if (f != null)
      {  setFileName(lastDir + f);
      }
   }

   public void setFileName(String newValue) 
   {  String oldValue = nameField.getText();  
      pcs.firePropertyChange("fileName", 
         oldValue, newValue);
      nameField.setText(newValue); 
   }

   public String getFileName() { return nameField.getText(); }

   public Dimension getMinimumSize()
   {  return new Dimension(XMINSIZE, YMINSIZE);  
   }

   public void addPropertyChangeListener
      (PropertyChangeListener l) 
   {  pcs.addPropertyChangeListener(l);
   }

   public void removePropertyChangeListener
      (PropertyChangeListener l) 
   {  pcs.removePropertyChangeListener(l);
   }

   public String getDefaultExtension() 
   {  return defaultExtension; 
   }
   
   public void setDefaultExtension(String s) 
   {  defaultExtension = s; 
   }
   
   public String getTitle() { return title; }
   public void setTitle(String s) { title = s; }

   private static final int XMINSIZE = 100;
   private static final int YMINSIZE = 20;
   private Button dialogButton = new Button("...");
   private TextField nameField = new TextField("");
   private FileDialog fileDialog;
   private int mode = FileDialog.LOAD;
   private String defaultExtension = "*.*";
   private String title = "";
   private String lastDir = "";
   private PropertyChangeSupport pcs 
      = new PropertyChangeSupport(this);
}




