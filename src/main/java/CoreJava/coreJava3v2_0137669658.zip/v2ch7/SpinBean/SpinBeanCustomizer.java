/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Oct 1997 
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class SpinBeanCustomizer extends Panel
   implements Customizer, ItemListener, TextListener
{  public SpinBeanCustomizer()
   {  setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.weightx = 0;
      gbc.weighty = 100;
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(new Label("Buddy"), gbc, 0, 0, 1, 1);
      add(new Label("Property"), gbc, 0, 1, 1, 1);
      gbc.weightx = 100;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      add(buddyTextField, gbc, 1, 0, 1, 1);
      add(propChoice, gbc, 1, 1, 1, 1);

      buddyTextField.addTextListener(this);
      propChoice.addItemListener(this);
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void textValueChanged(TextEvent evt)
   {  findBuddyMethods();
   }

   public void findBuddyMethods()
   {  propChoice.removeAll();

      Container parent = bean.getParent();
      while (parent.getParent() != null)
         parent = parent.getParent();

      buddy = findBuddy(parent, buddyTextField.getText());
      if (buddy == null)
      {  return;
      }

      try
      {  BeanInfo info 
            = Introspector.getBeanInfo(buddy.getClass());
         props = info.getPropertyDescriptors();
         int j = 0;
         for (int i = 0; i < props.length; i++)
         {  if (props[i].getPropertyType().equals(int.class))
            {  propChoice.add(props[i].getName());
               props[j++] = props[i];
            }
         }
      } 
      catch(IntrospectionException e){}
   }

   public static Component findBuddy(Container parent, 
      String name)
   {  Component[] children = parent.getComponents();
      for (int i = 0; i < children.length; i++)
      {  if (children[i].getName().equals(name))
            return children[i];
         if (children[i] instanceof Container)
         {  Component ret 
               = findBuddy((Container)children[i], name);
            if (ret != null) return ret;
         }
      }
      return null;
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
      {  bean.setBuddy(buddy, 
            props[propChoice.getSelectedIndex()]);
      }
   }

   public Dimension getPreferredSize()
   {  return new Dimension(200, 100);
   }

   public void setObject(Object obj)
   {  bean = (SpinBean)obj;
   }

   public void addPropertyChangeListener
      (PropertyChangeListener l)
   {  support.addPropertyChangeListener(l);
   }

   public void removePropertyChangeListener
      (PropertyChangeListener l)
   {  support.removePropertyChangeListener(l);
   }

   SpinBean bean;
   PropertyChangeSupport support 
      = new PropertyChangeSupport(this);
   TextField buddyTextField = new TextField();
   Choice propChoice = new Choice();
   Component buddy;
   PropertyDescriptor[] props; 
}

