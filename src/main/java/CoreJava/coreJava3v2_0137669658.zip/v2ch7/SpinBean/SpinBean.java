/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 10 Mar 1997 
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.lang.reflect.*;
import java.io.*;

public class SpinBean extends Panel 
   implements ActionListener, Serializable
{  public SpinBean()
   {  setLayout(new GridLayout(1, 2));
      Button plusButton = new Button("+");
      Button minusButton = new Button("-");
      add(plusButton);
      add(minusButton);
      plusButton.addActionListener(this);
      minusButton.addActionListener(this);
   }

   public void setBuddy(Component b, PropertyDescriptor p)
   {  buddy = b;
      prop = p;
   }

   public void actionPerformed(ActionEvent evt)
   {  if (buddy == null) return;
      if (prop == null) return;
      String arg = evt.getActionCommand();
      int increment = 0;
      if (arg.equals("+")) increment = 1;
      else if (arg.equals("-")) increment = -1;
      else return;
      Method readMethod = prop.getReadMethod();
      Method writeMethod = prop.getWriteMethod();
      try
      {  int value = ((Integer)readMethod.invoke(buddy, 
            null)).intValue();
         value += increment;
         writeMethod.invoke(buddy, 
            new Object[] { new Integer(value) });
      }
      catch(Exception e) {}
   }

   public Dimension getPreferredSize()
   {  return new Dimension(MINSIZE, MINSIZE);  
   }
   
   String buddyName = "";

   private static final int MINSIZE = 20;
   private Component buddy = null;      
   private PropertyDescriptor prop = null;
}
