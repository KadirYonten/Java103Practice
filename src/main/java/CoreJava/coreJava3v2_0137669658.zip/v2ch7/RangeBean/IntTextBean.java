/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.1 27 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;

public class IntTextBean extends TextField
   implements Serializable
{  public IntTextBean()
   {  setText("0");

      addKeyListener(new KeyAdapter() 
      {  public void keyTyped(KeyEvent evt)
         {  char ch = evt.getKeyChar();
            if (!('0' <= ch && ch <= '9' 
                  || ch == '-'
                  || Character.isISOControl(ch)))
               evt.consume();
            else
               lastCaretPosition = getCaretPosition();
         }
         public void keyPressed(KeyEvent evt)
         {  if (evt.getKeyCode() == KeyEvent.VK_ENTER)
            {  editComplete();
            }
         }
      });

      addFocusListener(new FocusAdapter() 
      {  public void focusLost(FocusEvent evt)
         {  if (!evt.isTemporary())
            {  editComplete();
            }
         }
      });

      addTextListener(new TextListener()
      {  public void textValueChanged(TextEvent evt)
         {  checkFieldValue();  
         }
      });
   }

   public void editComplete()
   {  Integer oldValue = new Integer(value);
      Integer newValue = new Integer(getFieldValue());
      try
      {  vcs.fireVetoableChange("value", oldValue, newValue);
         // survived, therefore no veto
         value = getFieldValue();
         pcs.firePropertyChange("value", oldValue, newValue);
      }
      catch(PropertyVetoException e)
      {  // someone didn't like it
         // back to the drawing board...
         requestFocus();
      }
   }

   public boolean checkFieldValue()
   {  String lastValue = getText();
      try
      {  Integer.parseInt(getText().trim() + "0");
         return true;
      }
      catch(NumberFormatException e)
      {  setText(lastValue);
         setCaretPosition(lastCaretPosition);
         return false;
      }
   }

   public int getFieldValue()
   {  if (checkFieldValue())
         return Integer.parseInt(getText().trim());
      else
         return 0; 
   }

   public int getValue()
   {  return value;
   }


   public void setValue(int v) throws PropertyVetoException
   {  Integer oldValue = new Integer(getValue());
      Integer newValue = new Integer(v);
      vcs.fireVetoableChange("value", oldValue, newValue);
      // survived, therefore no veto
      value = v;
      setText("" + v);
      pcs.firePropertyChange("value", oldValue, newValue);
   }

   public void addPropertyChangeListener
      (PropertyChangeListener l) 
   {  pcs.addPropertyChangeListener(l);
   }

   public void removePropertyChangeListener
      (PropertyChangeListener l) 
   {  pcs.removePropertyChangeListener(l);
   }

   public void addVetoableChangeListener
      (VetoableChangeListener l) 
   {  vcs.addVetoableChangeListener(l);
   }

   public void removeVetoableChangeListener
      (VetoableChangeListener l) 
   {  vcs.removeVetoableChangeListener(l);
   }

   public Dimension getMinimumSize()
   {  return new Dimension(XMINSIZE, YMINSIZE);  
   }

   private static final int XMINSIZE = 50;
   private static final int YMINSIZE = 20;
   private PropertyChangeSupport pcs 
      = new PropertyChangeSupport(this);

   private VetoableChangeSupport vcs 
      = new VetoableChangeSupport(this);

   private int value = 0;

   int lastCaretPosition;
}
