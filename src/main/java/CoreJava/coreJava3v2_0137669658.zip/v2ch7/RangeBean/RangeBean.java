/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.beans.*;
import java.io.*;

public class RangeBean extends Panel
   implements VetoableChangeListener, Serializable
{  public RangeBean()
   {  add(new Label("From"));
      add(from);
      add(new Label("To"));
      add(to);

      from.addVetoableChangeListener(this);
      to.addVetoableChangeListener(this);
   }

   public void vetoableChange(PropertyChangeEvent evt)
      throws PropertyVetoException
   {  int v = ((Integer)evt.getNewValue()).intValue();
      if (evt.getSource() == from && v > to.getValue())
         throw new PropertyVetoException("from > to", evt);
      if (evt.getSource() == to && v < from.getValue())
         throw new PropertyVetoException("to < from", evt);
   }

   public int getFrom() { return from.getValue(); }
   public int getTo() { return to.getValue(); }

   public void setFrom(int v) throws PropertyVetoException
   {  from.setValue(v);
   }

   public void setTo(int v) throws PropertyVetoException
   {  to.setValue(v);
   }

   private IntTextBean from = new IntTextBean();
   private IntTextBean to = new IntTextBean();
}
