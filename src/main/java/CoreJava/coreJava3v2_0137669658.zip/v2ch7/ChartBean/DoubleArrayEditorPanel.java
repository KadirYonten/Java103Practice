/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.lang.reflect.*;
import java.beans.*;

public class DoubleArrayEditorPanel extends Panel
   implements ItemListener
{  public DoubleArrayEditorPanel(PropertyEditorSupport ed)
   {  editor = ed;
      setArray((double[])ed.getValue());
      setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.weightx = 0;
      gbc.weighty = 0;
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(new Label("Size"), gbc, 0, 0, 1, 1);
      add(new Label("Elements"), gbc, 0, 1, 1, 1);
      gbc.weightx = 100;
      gbc.anchor = GridBagConstraints.WEST;
      add(sizeField, gbc, 1, 0, 1, 1);
      gbc.fill = GridBagConstraints.HORIZONTAL;
      add(valueField, gbc, 1, 1, 1, 1);
      gbc.weighty = 100;
      gbc.fill = GridBagConstraints.BOTH;
      add(elementList, gbc, 1, 2, 1, 1);
      gbc.fill = GridBagConstraints.NONE;

      elementList.addItemListener(this);
      sizeField.addKeyListener(new KeyAdapter() 
         {  public void keyPressed(KeyEvent evt)
            {  if (evt.getKeyCode() == KeyEvent.VK_ENTER)
               {  resizeArray();
               }
            }
         });
      sizeField.addFocusListener(new FocusAdapter() 
         {  public void focusLost(FocusEvent evt)
            {  if (!evt.isTemporary())
               {  resizeArray();
               }
            }
         });
      valueField.addKeyListener(new KeyAdapter() 
         {  public void keyPressed(KeyEvent evt)
            {  if (evt.getKeyCode() == KeyEvent.VK_ENTER)
               {  changeValue();
               }
            }
         });
      valueField.addFocusListener(new FocusAdapter() 
         {  public void focusLost(FocusEvent evt)
            {  if (!evt.isTemporary())
               {  changeValue();
               }
            }
         });
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void resizeArray()
   {  fmt.setParseIntegerOnly(true);
      int s = 0;
      try
      {  s = fmt.parse(sizeField.getText()).intValue();
         if (s < 0)
            throw new ParseException("Out of bounds", 0);
      }
      catch(ParseException e)
      {  sizeField.requestFocus();
         return;
      }
      if (s == theArray.length) return;
      setArray((double[])arrayGrow(theArray, s));
      editor.setValue(theArray);
      editor.firePropertyChange();
   }

   public void changeValue()
   {  double v = 0;
      fmt.setParseIntegerOnly(false);
      try
      {  v = fmt.parse(valueField.getText()).doubleValue();
      }
      catch(ParseException e)
      {  valueField.requestFocus();
         return;
      }
      setArray(currentIndex, v);
      editor.firePropertyChange();
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
      {  int i = elementList.getSelectedIndex();
         valueField.setText("" + theArray[i]);
         currentIndex = i;
      }
   }

   static Object arrayGrow(Object a, int newLength)
   {  Class cl = a.getClass();
      if (!cl.isArray()) return null;
      Class componentType = a.getClass().getComponentType();
      int length = Array.getLength(a);
      
      Object newArray = Array.newInstance(componentType, 
         newLength);
      System.arraycopy(a, 0, newArray, 0, 
         Math.min(length, newLength));
      return newArray;
   }

   public double[] getArray() 
   {  return (double[])theArray.clone(); 
   }

   public void setArray(double[] v) 
   {  if (v == null) theArray = new double[0];
      else theArray = v; 
      sizeField.setText("" + theArray.length);
      elementList.removeAll();
      for (int i = 0; i < theArray.length; i++)
         elementList.add("[" + i + "] " + theArray[i]);
      if (theArray.length > 0)
      {  valueField.setText("" + theArray[0]);
         elementList.select(0);
         currentIndex = 0;
      }
      else
         valueField.setText("");
   }
   
   public double getArray(int i) 
   {  if (0 <= i && i < theArray.length) return theArray[i];
      return 0;
   }

   public void setArray(int i, double value)
   {  if (0 <= i && i < theArray.length) 
      {  theArray[i] = value;
         elementList.replaceItem("[" + i + "] " + value, i);
         int previous = elementList.getSelectedIndex();
         elementList.select(i);
         valueField.setText("" + value);
         elementList.select(previous);
      }
   }

   private PropertyEditorSupport editor;
   private double[] theArray;
   private int currentIndex = 0;
   private NumberFormat fmt = NumberFormat.getNumberInstance();
   private TextField sizeField = new TextField(4);
   private TextField valueField = new TextField(12);
   private List elementList = new List();
}
