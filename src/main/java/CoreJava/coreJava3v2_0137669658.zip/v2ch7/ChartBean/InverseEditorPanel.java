/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.lang.reflect.*;
import java.beans.*;

public class InverseEditorPanel extends Panel
   implements ItemListener
{  public InverseEditorPanel(PropertyEditorSupport ed)
   {  editor = ed;
      CheckboxGroup g = new CheckboxGroup();
      boolean isInverse 
         = ((Boolean)editor.getValue()).booleanValue();
      normal = new Checkbox("Normal", g, !isInverse);
      inverse = new Checkbox("Inverse", g, isInverse);

      normal.addItemListener(this);
      inverse.addItemListener(this);
      add(normal);
      add(inverse);
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
      {  editor.setValue(new Boolean(inverse.getState()));
      editor.firePropertyChange();
      }
   }

   private Checkbox normal;
   private Checkbox inverse;
   PropertyEditorSupport editor;
}
