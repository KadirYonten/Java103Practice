/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.beans.*;

public class DoubleArrayEditor extends PropertyEditorSupport
{  public Component getCustomEditor()
   {  return new DoubleArrayEditorPanel(this);
   }

   public boolean supportsCustomEditor()
   {  return true;
   }

   public boolean isPaintable()
   {  return true;
   }

   public void paintValue(Graphics g, Rectangle box)
   {  double[] values = (double[]) getValue();
      String s = "";
      for (int i = 0; i < 3; i++)
      {  if (values.length > i) s = s + values[i];
         if (values.length > i + 1) s = s + ", ";
      }
      if (values.length > 3) s += "...";
   
      g.setColor(Color.white);
      g.fillRect(box.x, box.y, box.width, box.height);
      g.setColor(Color.black);
      FontMetrics fm = g.getFontMetrics();
      int w = fm.stringWidth(s);
      int x = box.x;
      if (w < box.width) x += (box.width - w) / 2;
      int y = box.y + (box.height - fm.getHeight()) / 2
         + fm.getAscent();
      g.drawString(s, x, y);
   }

   public String getAsText()
   {  return null;
   }
}


