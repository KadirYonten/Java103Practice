/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Oct 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.beans.*;

public class ChartBeanBeanInfo extends SimpleBeanInfo
{  public BeanDescriptor getBeanDescriptor()
   {  return new BeanDescriptor(ChartBean.class, 
         ChartBeanCustomizer.class);
   }

   public Image getIcon(int iconType)
   {  String name = "";
      if (iconType == BeanInfo.ICON_COLOR_16x16)
         name = "COLOR_16x16";
      else if (iconType == BeanInfo.ICON_COLOR_32x32)
         name = "COLOR_32x32";
      else if (iconType == BeanInfo.ICON_MONO_16x16)
         name = "MONO_16x16";
      else if (iconType == BeanInfo.ICON_MONO_32x32)
         name = "MONO_32x32";
      else return null;
      return loadImage("ChartBean_" + name + ".gif");
   }
}
