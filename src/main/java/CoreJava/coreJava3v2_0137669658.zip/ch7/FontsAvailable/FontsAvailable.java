/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Gary Cornell
 */

import java.awt.*;
import corejava.*;

public class FontsAvailable extends CloseableFrame
{  public void paint(Graphics g) 
   {  String [] fontList = getToolkit().getFontList();
      Font defaultFont = g.getFont();
      for (int i = 0; i < fontList.length; i++)
      {  g.setFont(defaultFont);
         g.drawString(fontList[i], 20, i * 20 + 40);
         Font f = new Font(fontList[i], Font.PLAIN, 14);
         g.setFont(f);
         g.drawString("ABCabc123\u00C6\u00C7\u2297", 
            120, i * 20 + 40);        
      }
   } 

   public static void main(String[] args)
   {  Frame f = new FontsAvailable();
      f.show();
   }
}
