/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import corejava.*;

public class FillRect extends CloseableFrame
{  public void paint(Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      g.drawRect(0, 0, 80, 30);
      g.drawRoundRect(100, 0, 80, 30, 15, 15);
      g.drawOval(0, 100, 80, 30);
      g.setColor(Color.red);
      g.fillRect(0, 0, 80, 30);
      g.fillRoundRect(100, 0, 80, 30, 15, 15);
      g.fill3DRect(200, 0, 80, 30, true);
      g.fill3DRect(200, 50, 80, 30, false);
      g.fillOval(0, 100, 80, 30);
   }

   public static void main(String args[])
   {  Frame f = new FillRect();
      f.show();
   }
}



                        
