/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.image.*;
import java.net.*;
import java.io.*;
import corejava.*;

public class Image2 extends CloseableFrame
{  public Image2()
   {  image = Toolkit.getDefaultToolkit().getImage
         ("blue-ball.gif");
      MediaTracker tracker = new MediaTracker(this);
      tracker.addImage(image, 0);
      try { tracker.waitForID(0); } 
      catch (InterruptedException e) {}
      imageWidth = image.getWidth(null);
      imageHeight = image.getHeight(null);
   }

   public void update(Graphics g)
   {  paint(g);
   }
      
   public void paint(Graphics g)
   {  Insets in = getInsets();
      g.translate(in.left, in.top);
      Dimension d = getSize();
      int clientWidth = d.width - in.right - in.left;
      int clientHeight = d.height - in.bottom - in.top;
      
      if (clientWidth > bufferWidth 
         || clientHeight > bufferHeight)
      // size has increased
      {  bufferWidth = clientWidth;
         bufferHeight = clientHeight;
              
         bufferedImage = createImage(bufferWidth, 
            bufferHeight);
         Graphics bg = bufferedImage.getGraphics();
         bg.drawImage(image, 0, 0, null);
         for (int i = 0; i <= bufferWidth / imageWidth;
             i++)
            for (int j = 0; 
               j <= bufferHeight / imageHeight; j++)
               if (i + j > 0) bg.copyArea(0, 0, imageWidth, 
                  imageHeight, i * imageWidth,
                      j * imageHeight);    
         bg.dispose();      
      }
      g.drawImage(bufferedImage, 0, 0, null);
   }

   public static void main(String args[])
   {  Frame f = new Image2();
      f.show();
   }
   
   private int bufferWidth = 0;
   private int bufferHeight = 0;  
   private int imageWidth = 0;
   private int imageHeight = 0;
   private Image image;
   private Image bufferedImage;
}





