/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import corejava.*;

public class PrintingTest extends CloseableFrame 
{  public PrintingTest() 
   {  MenuBar mb = new MenuBar();
      Menu m = new Menu("File");
      MenuItem mi = new MenuItem("Print");
      mi.addActionListener(new ActionListener()
         {  public void actionPerformed(ActionEvent evt) 
            { print(); }
         });
      m.add(mi);
      mb.add(m);
      setMenuBar(mb);

      setForeground(Color.pink);
   }

   public void print()
   {  PrintJob pjob = getToolkit().getPrintJob(this, 
         "Printing Test", null);

      if (pjob != null) 
      {  Graphics pg = pjob.getGraphics();
         if (pg != null) 
         {  paint(pg);
            pg.dispose(); // flush page
          }
          pjob.end();
      }
   }

   public void paint(Graphics g) 
   {  g.setFont(new Font("Serif", Font.BOLD, 18));
      int xleft = 96;
      int ybase = 96;
      String message = "Not a Hello, World program";
      g.drawString(message, xleft, ybase);
      int yheight = 96;
      int xwidth = g.getFontMetrics().stringWidth(message);
      g.setColor(Color.yellow);
      g.fillOval(xleft, ybase + 12, xwidth, yheight);
   }

   public static void main(String args[]) 
   {  Frame f = new PrintingTest();
      f.setSize(400, 400);
      f.show();
   }
}