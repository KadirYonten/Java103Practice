/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import corejava.*;

public class PrintGrid extends CloseableFrame 
{  public PrintGrid() 
   {  MenuBar mb = new MenuBar();
      Menu m = new Menu("File");
      MenuItem mi = new MenuItem("Print");
      mi.addActionListener(new ActionListener()
         {  public void actionPerformed(ActionEvent evt) 
            { print(); }
         });
      m.add(mi);
      mb.add(m);
      setMenuBar(mb);
   }

   public void print()
   {  PrintJob pjob = getToolkit().getPrintJob(this, 
         "Printing Test", null);

      if (pjob != null) 
      {  Graphics pg = pjob.getGraphics();
         if (pg != null) 
         {  paint(pg);
            pg.dispose(); // flush page
          }
          pjob.end();
      }
   }

   public void paint(Graphics g) 
   {  g.translate(getInsets().left, getInsets().top);
      int resolution = getToolkit().getScreenResolution();
      int width = 4 * resolution; // 4 inches
      int distance = resolution / 16; // 1/16 inch
 
      for (int i = 0; i <= width; i += distance)
      {  g.drawLine(i, 0, i, width);
         g.drawLine(0, i, width, i);
      }
   }

   public static void main(String args[]) 
   {  Frame f = new PrintGrid();
      f.setSize(400, 400);
      f.show();
   }
}