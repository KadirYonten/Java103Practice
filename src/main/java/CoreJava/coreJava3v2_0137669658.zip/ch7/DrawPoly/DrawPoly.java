/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import corejava.*;

public class DrawPoly extends CloseableFrame
{  public void paint(Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      int r = 40; // radius of circle bounding PacMan(R)
      int cx = 50; // center of that circle
      int cy = 100;
      int angle = 30; // opening angle of mouth
      
      int dx = (int)(r * Math.cos(angle * Math.PI / 180));
      int dy = (int)(r * Math.sin(angle * Math.PI / 180));
      
      g.drawLine(cx, cy, cx + dx, cy + dy); // lower jaw
      g.drawLine(cx, cy, cx + dx, cy - dy); // upper jaw
      g.drawArc(cx - r, cy - r, 2 * r, 2 * r, angle, 
         360 - 2 * angle); 
 
      Polygon p = new Polygon();
      cx = 150;
      int i;
      for (i = 0; i < 5; i++)
         p.addPoint(
            (int)(cx + r * Math.cos(i * 2 * Math.PI / 5)),
            (int)(cy + r * Math.sin(i * 2 * Math.PI / 5)));
            
      g.drawPolygon(p);
      
      Polygon s = new Polygon(); 
      cx = 250;
      for (i = 0; i < 360; i++)
      {  double t = i / 360.0;
         s.addPoint(
            (int)(cx + r * t * Math.cos(8 * t * Math.PI)), 
            (int)(cy + r * t * Math.sin(8 * t * Math.PI)));
      }
      g.drawPolygon(s);       
   }

   public static void main(String args[])
   {  Frame f = new DrawPoly();
      f.show();
   }
}



                        
