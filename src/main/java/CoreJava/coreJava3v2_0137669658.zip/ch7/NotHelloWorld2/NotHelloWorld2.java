/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 25 Mar 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import corejava.*;

public class NotHelloWorld2 extends CloseableFrame
{  public void setFonts(Graphics g)
   {  if (fontsSet) return;
      f = new Font("SansSerif", Font.BOLD, 14);
      fi = new Font("SansSerif", 
         Font.BOLD + Font.ITALIC, 14);
      fm = g.getFontMetrics(f);
      fim = g.getFontMetrics(fi);
      fontsSet = true;
   }

   public void paint(Graphics g)
   {  setFonts(g);
      String s1 = "Not a ";
      String s2 = "Hello, World";
      String s3 = " Program";
      int w1 = fm.stringWidth(s1);
      int w2 = fim.stringWidth(s2);
      int w3 = fm.stringWidth(s3);

      Dimension d = getSize();
      Insets in = getInsets();
      int clientWidth = d.width - in.right - in.left;
      int clientHeight = d.height - in.bottom - in.top;
      int cx = (clientWidth - w1 - w2 - w3) / 2 + in.left;
      int cy = clientHeight / 2 + in.top;
      g.drawRect(in.left, in.top, 
         clientWidth - 1, clientHeight - 1);
      
      g.setFont(f);
      g.drawString(s1, cx, cy);
      cx += w1;
      g.setFont(fi);
      g.drawString(s2, cx, cy);
      cx += w2;
      g.setFont(f);
      g.drawString(s3, cx, cy);
   }

   public static void main(String args[])
   {  Frame f = new NotHelloWorld2();
      f.show();
   }
   
   private Font f;
   private Font fi;
   private FontMetrics fm;
   private FontMetrics fim;
   private boolean fontsSet = false;
}




