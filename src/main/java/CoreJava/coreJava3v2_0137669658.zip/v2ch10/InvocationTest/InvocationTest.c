/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 01 Jul 1997
 * @author Cay Horstmann
 */

#include <jni.h>
#include <stdlib.h>
    
int main()
{  JavaVM *jvm;       
   JNIEnv *env;       
   JDK1_1InitArgs vm_args;
   jclass cls;
   jmethodID id;
   
   vm_args.version = 0x00010001; 
   JNI_GetDefaultJavaVMInitArgs(&vm_args);
   vm_args.classpath = getenv("CLASSPATH");

   JNI_CreateJavaVM(&jvm, &env, &vm_args);
    
   cls = (*env)->FindClass(env, "Welcome");
   id = (*env)->GetStaticMethodID(env, cls, "main", 
      "([Ljava/lang/String;)V");
   (*env)->CallStaticVoidMethod(env, cls, id, 100);
    
   (*jvm)->DestroyJavaVM(jvm);

   return 0;
}
