/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 01 Jul 1997
 * @author Cay Horstmann
 */

#include "Employee.h"

#include <stdio.h>

JNIEXPORT void JNICALL Java_Employee_raiseSalary
  (JNIEnv* env, jobject obj_this, jdouble byPercent)
{  /* get the class */
   jclass class_Employee = (*env)->GetObjectClass(env, 
      obj_this);

   /* get the field ID */
   jfieldID id_salary = (*env)->GetFieldID(env, 
      class_Employee, "salary", "D");

   /* get the field value */
   jdouble salary = (*env)->GetDoubleField(env, obj_this,
      id_salary);

   salary *= 1 + byPercent / 100;

   /* set the field value */
   (*env)->SetDoubleField(env, obj_this, id_salary, salary);
}

JNIEXPORT jint JNICALL Java_Employee_hireYear
  (JNIEnv* env, jobject obj_this)
{  /* get the class */
   jclass class_Employee = (*env)->GetObjectClass(env, 
      obj_this);

   /* get the field ID */
   jfieldID id_hireDay = (*env)->GetFieldID(env, 
      class_Employee, "hireDay", "Lcorejava/Day;");

   /* get the field value */
   jobject obj_hireDay = (*env)->GetObjectField(env, obj_this,
      id_hireDay);

   /* get the class */
    jclass class_Day = (*env)->FindClass(env, "corejava/Day");
      /* NOT Lcorejava/Day; */

   /* get the method ID */
   jmethodID id_getYear = (*env)->GetMethodID(env, class_Day, "getYear", "()I");

   /* call the method */
   jint ret = (*env)->CallIntMethod(env, obj_hireDay, 
      id_getYear);
   return ret;
}

