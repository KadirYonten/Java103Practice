/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 01 Jul 1997
 * @author Cay Horstmann
 */

import java.util.*;

public class Win32RegKeyTest
{  public static void main(String[] args)
   {  Win32RegKey key = new Win32RegKey(
         Win32RegKey.HKEY_CURRENT_USER,
         "Software\\Microsoft\\MS Setup (ACME)\\User Info");

      key.setValue("Default user", "Bozo the clown");
      key.setValue("Lucky number", new Integer(13));
      key.setValue("Small primes", new byte[] 
         { 2, 3, 5, 7, 11 });
      
      Enumeration enum = key.names();

      while (enum.hasMoreElements()) 
      {  String name = (String)enum.nextElement();
         System.out.print(name + " = ");

         Object value = key.getValue(name);

         if (value instanceof byte[])
         {  byte[] bvalue = (byte[])value;
            for (int i = 0; i < bvalue.length; i++)
               System.out.print((bvalue[i] & 0xFF) + " ");
         }
         else System.out.print(value);
         
         System.out.println();
      }
   }
}
