*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class Pascal extends CloseableFrame
   implements ActionListener
{  public Pascal()
   {  Panel p = new Panel();
      p.setLayout(new FlowLayout());
      addButton(p, "-");
      addButton(p, "+");
      label = new Label("2   ");
      p.add(label);
      add(p, "South");
      canvas = new PascalCanvas();
      add(canvas, "Center");
   }
   
   public void addButton(Container c, String name)
   {  Button b = new Button(name);
      b.addActionListener(this);
      c.add(b);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("-"))
      {  if (m > 2) m--;
         label.setText(m + "   ");                  
         canvas.redraw(m);
      }
      if (arg.equals("+"))
      {  m++;
         label.setText(m + "   ");                  
         canvas.redraw(m);
      }
   }
   
   public static void main(String args[])
   {  Frame f = new Pascal();
      f.setSize(400, 400);
      f.show();
   }
   
   private Label label;
   private PascalCanvas canvas;   
   private int m = 2;
}

class PascalCanvas extends Canvas
{  public int[][] pascal(int n, int m)
   {  int[][] binom = new int[n + 1][];
      int i;
      int j;
      for (i = 0; i <= n; i++)
         binom[i] = new int[i / 2 + 1];
      for (i = 0; i <= n; i++)
         for (j = 0; j <= i / 2; j++)
            if (j == 0) 
               binom[i][j] = 1;
            else if (2 * j < i)
               binom[i][j] = (binom[i - 1][j - 1] 
                  + binom[i - 1][j]) % m;
            else
               binom[i][j] = (2 * binom[i - 1][j - 1]) % m;
      return binom;
   }
   
   public void redraw(int new_m)
   {  m = new_m;
      repaint();
   }
   
   public void paint(Graphics g)
   {  int i;
      int j;
      
      int nmax = 1 + getSize().height / 10;
      if (nmax > MAX) nmax = MAX;
      int[][] binom = pascal(nmax, m);

      for (i = 0; i <= nmax; i++)
      {  for (j = 0; j <= i; j++)
         {  int k = 2 * j <= i ? j : i - j;
            int b = binom[i][k] % m;
            g.setColor(new Color((255 * b) / (m - 1), 0, 0));
            g.fillRect(5 * (nmax + 1 - i + 2 * j), 10 * i, 
               10, 10);
         }   
      }
   }
   
   private int m = 7;
   private final int MAX = 100;
}


