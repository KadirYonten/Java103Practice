/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import corejava.*;

public class HashSetTest extends CloseableFrame
   implements ActionListener
{  public HashSetTest()
   {  Panel p = new Panel();
      p.setLayout(new FlowLayout());
      name = new Choice();
      String[] f = Toolkit.getDefaultToolkit().getFontList();
      int i;
      for (i = 0; i < f.length; i++)
         name.add(f[i]);
      ptsize = new IntTextField(12, 4);
      p.add(name);
      p.add(ptsize);
      addButton(p, "Add");
      addButton(p, "Remove");
      add(p, "South");
      add(canvas = new FontCanvas(), "Center");
      canvas.redraw(fonts);
   }

   public void addButton(Container c, String name)
   {  Button b = new Button(name);
      b.addActionListener(this);
      c.add(b);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Add"))
      {  if (ptsize.isValid())
         {  String n = name.getSelectedItem();
            fonts.put(new Font(n, Font.PLAIN, 
               ptsize.getValue()));
         }
      }
      else if (arg.equals("Remove"))
      {  if (ptsize.isValid())
         {  String n = name.getSelectedItem();
            fonts.remove(new Font(n, Font.PLAIN, 
               ptsize.getValue()));
         }
      }   
      canvas.redraw(fonts);
   }

   public static void main(String args[])
   {  Frame f = new HashSetTest();
      f.show();
   }
   
   private Choice name;
   private IntTextField ptsize;
   private FontCanvas canvas;   
   private HashSet fonts = new HashSet();
   
}

class HashSet extends Hashtable
{  public void put(Object o) { super.put(o, o); }
   public boolean contains(Object o)
   {  return super.containsKey(o);
   }
   public Enumeration elements() 
   {  return super.keys();
   }
}

class FontCanvas extends Canvas
{  public void redraw(HashSet new_a)
   {  a = new_a;
      repaint();
   }

   public void paint(Graphics g)
   {  Enumeration e = a.elements();
      int x = 0;
      int y = 0; 
      while (e.hasMoreElements())
      {  Font f = (Font)e.nextElement();
         g.setFont(f);
         FontMetrics fm = g.getFontMetrics(f);
         y += fm.getHeight();
         g.drawString(
        "The quick brown fox jumps over the lazy dog", x, y);
      }
   }
   
   private HashSet a;
}


