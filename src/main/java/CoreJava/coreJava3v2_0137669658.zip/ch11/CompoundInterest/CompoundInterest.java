/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Feb 1996 
 * @author Cay Horstmann
 */

import corejava.*;

public class CompoundInterest
{  public static double futureValue(double initialBalance, 
   double p, double nyear)
   {  return initialBalance * Math.pow(1 + p / 12 / 100,
      12 * nyear);
   }
   
   public static void main(String[] args)
   {  double[][] balance;
      balance = new double[5][6];
      int i;
      int j;
      for (i = 0; i < 5; i++)
         for (j = 0; j < 6; j++)
            balance[i][j] = futureValue(10000, 10 + 10 * i,
               5 + 0.5 * j);
      System.out.print("   ");
      for (j = 0; j < 6; j++)
         Format.print(System.out, "%9.2f%", 5 + 0.5 * j);
      System.out.println("");
      for (i = 0; i < 5; i++)
      {  Format.print(System.out, "%3d", 10 + 10 * i);
         for (j = 0; j < 6; j++)
            Format.print(System.out, "%10.2f", 
               balance[i][j]);
         System.out.println("");
      }         
 
   }
}
