/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.util.*;
import java.io.*;
import corejava.*;

public class CustomWorld extends CloseableFrame
{  public CustomWorld()
   {  Properties defaultSettings = new Properties();
      defaultSettings.put("FONT", "Monospaced");
      defaultSettings.put("SIZE", "300 200");
      defaultSettings.put("MESSAGE", "Hello, World");
      defaultSettings.put("COLOR", "0 50 50");
      defaultSettings.put("PTSIZE", "12");
   
      Properties settings = new Properties(defaultSettings);
      try
      {  FileInputStream sf = new FileInputStream
         ("CustomWorld.ini");
         settings.load(sf);
      } 
      catch (FileNotFoundException e) {}
      catch (IOException e) {}
   
      StringTokenizer st = new StringTokenizer
         (settings.getProperty("COLOR"));
      int red = Format.atoi(st.nextToken());
      int green = Format.atoi(st.nextToken());
      int blue = Format.atoi(st.nextToken());
      
      setBackground(new Color(red, green, blue));
      foreground = new Color(255 - red, 255 - green, 
         255 - blue);
      
      String name = settings.getProperty("FONT");
      int size = Format.atoi(settings.getProperty("PTSIZE"));
      f = new Font(name, Font.BOLD, size);
      
      st = new StringTokenizer
         (settings.getProperty("SIZE"));
      int hsize = Format.atoi(st.nextToken());
      int vsize = Format.atoi(st.nextToken());
      setSize(hsize, vsize);
      setTitle(settings.getProperty("MESSAGE"));
   }

   public void paint(Graphics g)
   {  g.setColor(foreground);
      g.setFont(f);

      String s = getTitle();
      FontMetrics fm = g.getFontMetrics(f);
      int w = fm.stringWidth(s);

      Dimension d = getSize();
      Insets in = getInsets();
      int clientWidth = d.width - in.right - in.left;
      int clientHeight = d.height - in.bottom - in.top;
      int cx = in.left + (clientWidth - w) / 2;
      int cy = in.top + (clientHeight + fm.getHeight()) / 2;
      
      g.drawString(s, cx, cy);
   }

   public static void main(String args[])
   {  Frame f = new CustomWorld();
      f.show();
   }

   private Color foreground;
   private Font f;
}




