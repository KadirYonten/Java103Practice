/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * version 1.10 07 Feb 1997
 * author Cay Horstmann
 */

#include <iostream>

class BitSet
{
public:
   BitSet(int n) : bits(new char[(n - 1) / 8 + 1]), size(n) {}
   bool get(int n)
   {  if (0 <= n && n < size)
         return (bits[n >> 3] & (1 << (n & 7))) != 0;
      else return false;
   }
   void set(int n)
   {  if (0 <= n && n < size)
         bits[n >> 3] |= 1 << (n & 7);
   }
   void clear(int n)
   {  if (0 <= n && n < size)
         bits[n >> 3] &= ~(1 << (n & 7));
   }

private:
   char* bits;
   int size; 
};

int main()
{  int n = 1000000;
   BitSet b(n);
   int count = 0;
   int i;
   for (i = 2; i <= n; i++)
      b.set(i);
   i = 2;
   while (i * i <= n)
   {  if (b.get(i))
      {  count++;
         int k = 2 * i;
         while (k <= n)
         {  b.clear(k);
            k += i;
         }
      }
      i++;
   }      
   while (i <= n)
   {  if (b.get(i))
         count++;
      i++;
   }
   cout << count << " primes\n";

   return 0;
}

   
