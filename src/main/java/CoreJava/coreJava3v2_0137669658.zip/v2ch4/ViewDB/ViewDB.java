/*
 * Gary Cornell and Cay S. Horstmann, Core Java (Book/CD-ROM)
 * Published By SunSoft Press/Prentice-Hall
 * Copyright (C) 1996 Sun Microsystems Inc.
 * All Rights Reserved. ISBN 0-13-596891-7
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Jun 1997
 * @author Cay Horstmann
 */

import java.net.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import corejava.*;

public class ViewDB extends CloseableFrame
   implements ActionListener, ItemListener
{  public ViewDB()
   {  tableNames = new Choice();
      tableNames.addItemListener(this);
      dataPanel = new Panel();
      add(dataPanel, "Center");
      Panel p = new Panel();
      Button nextButton = new Button("Next");
      p.add(nextButton);
      nextButton.addActionListener(this);      
      add(p, "South");
      fields = new Vector();   
   
      try 
      {  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 
            // force loading of driver
         String url = "jdbc:odbc:corejava";
         String user = "Cay";
         String password = "password";
         con = DriverManager.getConnection(url, user, 
            password);
         stmt = con.createStatement();         
         md = con.getMetaData();
         ResultSet mrs = md.getTables(null, null, null,
            new String[] { "TABLE" });
         while (mrs.next()) 
            tableNames.addItem(mrs.getString(3));
          mrs.close();
      }
      catch(Exception e)
      {  System.out.println("Error " + e);  
      }

      add(tableNames, "North");
   }

   private void add(Container p, Component c, 
      GridBagConstraints gbc, int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      p.add(c, gbc);
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
      {  remove(dataPanel);
         dataPanel = new Panel();
         fields.removeAllElements();
         dataPanel.setLayout(new GridBagLayout());
         GridBagConstraints gbc = new GridBagConstraints();
         gbc.fill = GridBagConstraints.NONE;
         gbc.anchor = GridBagConstraints.WEST;
         gbc.weightx = 100;
         gbc.weighty = 100;
         
         try
         {  String tableName = (String)evt.getItem();
            if (rs != null) rs.close();            
            rs = stmt.executeQuery("SELECT * FROM " 
               + tableName);
            ResultSetMetaData rsmd = rs.getMetaData();
            for (int i = 1; i <= rsmd.getColumnCount(); i++)
            {  String columnName = rsmd.getColumnLabel(i);
               int columnWidth = rsmd.getColumnDisplaySize(i);
               TextField tb = new TextField(columnWidth);
               fields.addElement(tb);
               add(dataPanel, new Label(columnName),  
                  gbc, 0, i - 1, 1, 1);
               add(dataPanel, tb, gbc, 1, i - 1, 1, 1);
            }
         }
         catch(Exception e)
         {  System.out.println("Error " + e);  
         }
         add(dataPanel, "Center");
         doLayout();
         pack();

         showNextRow();
      }
   }
   
   public void actionPerformed(ActionEvent evt)
   {  if (evt.getActionCommand().equals("Next"))
      {  showNextRow();  
      }
   }
   
   public void showNextRow()
   {  if (rs == null) return;
      {  try
         {  if (rs.next())
            {  for (int i = 1; i <= fields.size(); i++)
               {  String field = rs.getString(i);
                  TextField tb 
                     = (TextField)fields.elementAt(i - 1);
                  tb.setText(field);
               }
            }
            else
            {  rs.close();
               rs = null;
            }
         }
         catch(Exception e)
         {  System.out.println("Error " + e);  
         }
      }
   }      
      
   public static void main (String args[]) 
   {  Frame f = new ViewDB();
      f.show();
   }
   
   private Panel dataPanel;
   private Choice tableNames;
   private Vector fields;
   
   private Connection con;
   private Statement stmt;
   private DatabaseMetaData md;
   private ResultSet rs;
}
