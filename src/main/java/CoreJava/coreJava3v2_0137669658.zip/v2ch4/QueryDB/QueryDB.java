/*
 * Gary Cornell and Cay S. Horstmann, Core Java (Book/CD-ROM)
 * Published By SunSoft Press/Prentice-Hall
 * Copyright (C) 1996 Sun Microsystems Inc.
 * All Rights Reserved. ISBN 0-13-596891-7
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Jun 1997
 * @author Cay Horstmann
 */

import java.net.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import corejava.*;

public class QueryDB extends CloseableFrame
   implements ActionListener
{  public QueryDB()
   {  setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      authors = new Choice();
      authors.addItem("Any");
      publishers = new Choice();
      publishers.addItem("Any");
      result = new TextArea(4, 50);
      result.setEditable(false);
      priceChange = new TextField(8);
      priceChange.setText("-5.00");
      
      try 
      {  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 
         // force loading of driver
         String url = "jdbc:odbc:corejava";
         String user = "Cay";
         String password = "password";
         con = DriverManager.getConnection(url, user, 
            password);
         stmt = con.createStatement();         
         
         String query = "SELECT Name FROM Authors"; 
         ResultSet rs = stmt.executeQuery(query);
         while (rs.next()) 
            authors.addItem(rs.getString(1));

         query = "SELECT Name FROM Publishers"; 
         rs = stmt.executeQuery(query);
         while (rs.next()) 
            publishers.addItem(rs.getString(1));
      }
      catch(Exception e)
      {  result.setText("Error " + e);  
      }

      gbc.fill = GridBagConstraints.NONE;
      gbc.weightx = 100;
      gbc.weighty = 100;
      add(authors, gbc, 0, 0, 2, 1);
      add(publishers, gbc, 2, 0, 2, 1);
      gbc.fill = GridBagConstraints.NONE;
      Button queryButton = new Button("Query");
      add(queryButton, gbc, 0, 1, 1, 1);
      queryButton.addActionListener(this);
      Button changeButton = new Button("Change prices");
      add(changeButton, gbc, 2, 1, 1, 1);
      changeButton.addActionListener(this);
      add(priceChange, gbc, 3, 1, 1, 1);
      gbc.fill = GridBagConstraints.BOTH;
      add(result, gbc, 0, 2, 4, 1);
   }

   private void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Query"))
      {  ResultSet rs = null;
         try
         {  String author = authors.getSelectedItem();
            String publisher = publishers.getSelectedItem();
            if (!author.equals("Any") 
               && !publisher.equals("Any"))
            {  if (authorPublisherQueryStmt == null)
               {  String authorPublisherQuery = 
"SELECT Books.Price, Books.Title " +
"FROM Books, BooksAuthors, Authors, Publishers " +
"WHERE Authors.Author_Id = BooksAuthors.Author_Id AND " + 
"BooksAuthors.ISBN = Books.ISBN AND " +
"Books.Publisher_Id = Publishers.Publisher_Id AND " + 
"Authors.Name = ? AND " +
"Publishers.Name = ?";
                  authorPublisherQueryStmt 
                  = con.prepareStatement(authorPublisherQuery);
               }
               authorPublisherQueryStmt.setString(1, author);
               authorPublisherQueryStmt.setString(2, 
                  publisher);
               rs = authorPublisherQueryStmt.executeQuery();
            }
            else if (!author.equals("Any") 
               && publisher.equals("Any"))
            {  if (authorQueryStmt == null)
               {  String authorQuery = 
"SELECT Books.Price, Books.Title " +
"FROM Books, BooksAuthors, Authors " +
"WHERE Authors.Author_Id = BooksAuthors.Author_Id AND " + 
"BooksAuthors.ISBN = Books.ISBN AND " +
"Authors.Name = ?";
                  authorQueryStmt 
                     = con.prepareStatement(authorQuery);
               }
               authorQueryStmt.setString(1, author);
               rs = authorQueryStmt.executeQuery();
            }
            else if (author.equals("Any") 
               && !publisher.equals("Any"))
            {  if (publisherQueryStmt == null)
               {  String publisherQuery = 
"SELECT Books.Price, Books.Title " +
"FROM Books, Publishers " +
"WHERE Books.Publisher_Id = Publishers.Publisher_Id AND " + 
"Publishers.Name = ?";
                  publisherQueryStmt 
                     = con.prepareStatement(publisherQuery);
               }
               publisherQueryStmt.setString(1, publisher);
               rs = publisherQueryStmt.executeQuery();
            }
            else 
            {  if (allQueryStmt == null)
               {  String allQuery = 
"SELECT Books.Price, Books.Title FROM Books";
                  allQueryStmt 
                     = con.prepareStatement(allQuery);
               }
               rs = allQueryStmt.executeQuery();
            }
            
            result.setText("");
            while (rs.next()) 
               result.append(rs.getString(1) 
                  + " | " + rs.getString(2) + "\n");
            rs.close();
         }
         catch(Exception e)
         {  result.setText("Error " + e);  
         }
      }
      else if (arg.equals("Change prices"))
      {  String publisher = publishers.getSelectedItem();
         if (publisher.equals("Any"))
            result.setText
               ("I am sorry, but I cannot do that.");
         else
            try
            {  String updateStatement = 
"UPDATE Books " +
"SET Price = Price + " + priceChange.getText() +
" WHERE Books.Publisher_Id = " +
"(SELECT Publisher_Id FROM Publishers WHERE Name = '" + 
   publisher + "')";
               int r = stmt.executeUpdate(updateStatement);
               result.setText(r + " records updated.");
            }
            catch(Exception e)
            {  result.setText("Error " + e);  
            }
      }
   }

   public void dispose()
   {  try
      {  stmt.close();
         con.close();
      }
      catch(SQLException e) {}
   }
 
   public static void main (String args[]) 
   {  Frame f = new QueryDB();
      f.setSize(400, 300);
      f.show();
   }
   
   private Choice authors;
   private Choice publishers;   
   private TextField priceChange;
   private TextArea result;
   private Connection con;
   private Statement stmt;
   private PreparedStatement authorQueryStmt;
   private PreparedStatement authorPublisherQueryStmt;
   private PreparedStatement publisherQueryStmt;
   private PreparedStatement allQueryStmt;
}
