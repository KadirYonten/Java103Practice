/*
 * Gary Cornell and Cay S. Horstmann, Core Java (Book/CD-ROM)
 * Published By SunSoft Press/Prentice-Hall
 * Copyright (C) 1996 Sun Microsystems Inc.
 * All Rights Reserved. ISBN 0-13-596891-7
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Jun 1997
 * @author Cay Horstmann
 */

import java.net.*;
import java.sql.*;
import java.io.*;
import java.util.*;

class MakeDB 
{  public static void main (String args[]) 
   {  try 
      {  Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 
         // force loading of driver
         String url = "jdbc:odbc:corejava";
         String user = "Cay";
         String password = "password";
         Connection con = DriverManager.getConnection(url, 
            user, password);
         Statement stmt = con.createStatement();
         
         String fileName = "";
         if (args.length > 0)
            fileName = args[0];
         else
         {  System.out.println("Enter filename: ");
            fileName = new BufferedReader
               (new InputStreamReader(System.in)).readLine();
         }
         
         int i = 0;
         while (i < fileName.length() 
            && (Character.isLowerCase(fileName.charAt(i)) 
            || Character.isUpperCase(fileName.charAt(i))))
            i++;
         String tableName = fileName.substring(0, i);
         
         BufferedReader in = new BufferedReader(new 
            FileReader(fileName));
         String[] columnNames = readLine(in);
         String[] columnTypes = readLine(in);
         createTable(stmt, tableName, columnNames, 
            columnTypes);
         boolean done = false;
         while (!done)
         {  String[] values = readLine(in);
            if (values.length == 0) done = true;
            else insertInto(stmt, tableName, 
               columnTypes, values);
         }

         showTable(stmt, tableName, columnNames.length);
         stmt.close();
         con.close();
      }
      catch (SQLException ex) 
      {  System.out.println ("SQLException:");
         while (ex != null) 
         {  System.out.println ("SQLState: " 
               + ex.getSQLState());
            System.out.println ("Message:  " 
               + ex.getMessage());
            System.out.println ("Vendor:   " 
               + ex.getErrorCode());
            ex = ex.getNextException();
            System.out.println ("");
          }
      }
      catch (java.lang.Exception ex) 
      {  System.out.println("Exception: " + ex);
         ex.printStackTrace ();
      }
   }

   private static String[] readLine(BufferedReader in) 
      throws IOException
   {  String line = in.readLine();
      Vector result = new Vector();
      if (line != null)
      {  StringTokenizer t = new StringTokenizer(line, "|");
         while (t.hasMoreTokens())
            result.addElement(t.nextToken().trim());
      }
      String[] retval = new String[result.size()];
      result.copyInto(retval);
      return retval;
   }   

   private static void createTable(Statement stmt, 
      String tableName, String[] columnNames, 
      String[] columnTypes) throws SQLException
   {  String command = "CREATE TABLE " + tableName + "(\n";
      String primary = "";
      for (int i = 0; i < columnNames.length; i++)
      {  if (i > 0) command += ",\n";
         String columnName = columnNames[i];
         if (columnName.charAt(0) == '*')
         {  if (primary.length() > 0) primary += ", ";
            columnName = columnName.substring(1, 
               columnName.length());
            primary += columnName;
         }
         command += columnName + " " + columnTypes[i];
      }
      if (primary.length() > 0) 
         command += "\nPRIMARY KEY (" + primary + ")";   
      command += ")\n";
      stmt.executeUpdate(command);
   }
                                                                                                                              
   private static void insertInto(Statement stmt, 
      String tableName, String[] columnTypes, String[] values)
      throws SQLException
   {  String command = "INSERT INTO " + tableName 
         + " VALUES (";
      for (int i = 0; i < columnTypes.length; i++)
      {  if (i > 0) command += ", ";
         String columnType = columnTypes[i].toUpperCase();
         String value = "";
         if (i < values.length) value = values[i];
         if (columnType.startsWith("CHAR") 
            || columnType.startsWith("VARCHAR"))
         {  int from = 0;
            int to = 0;
            command += "'";
            while ((to = value.indexOf('\'', from)) >= 0)
            {  command += value.substring(from, to) + "''";
               from = to + 1;
            }
            command += value.substring(from) + "'";
         }
         else command += value;
      }
      command += ")";
      stmt.executeUpdate(command);
   }

   private static void showTable(Statement stmt, 
      String tableName, int numCols) throws SQLException
   {  String query = "SELECT * FROM " + tableName; 
      ResultSet rs = stmt.executeQuery(query);
      while (rs.next()) 
      {  for (int i = 1; i <= numCols; i++) 
         {  if (i > 1) System.out.print("|");
            System.out.print(rs.getString(i));
         }
         System.out.println("");
      }
      rs.close();
   }
}
