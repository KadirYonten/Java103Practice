/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Feb 1996 
 * @author Cay Horstmann
 */

import corejava.*;

public class CardDeck
{  public CardDeck()
   {  deck = new Card[52];
      fill();
      shuffle();
   }
   
   public void fill()
   {  int i;
      int j;                                
    
      for (i = 1; i <= 13; i++)
         for (j = 1; j <= 4; j++)
            deck[4 * (i - 1) + j - 1] = new Card(i, j);
      cards = 52;
   }
   
   public void shuffle()
   {  int next;
      for (next = 0; next < cards - 1; next++)
      {  int r = new 
            RandomIntGenerator(next, cards - 1).draw();
         Card temp = deck[next];
         deck[next] = deck[r];
         deck[r] = temp;
      }
   }
   
   public final Card draw()
   {  if (cards == 0) return null;
      cards--;
      return deck[cards];
   }
   
   public static void main(String[] args)
   {  CardDeck d = new CardDeck();
      int i;
      int wins = 0;
      int rounds = 10;
      
      for (i = 1; i <= rounds; i++) 
      {  Card yours = d.draw();
         System.out.print("Your draw: " + yours + " ");
         Card mine = d.draw();
         System.out.print("My draw: " + mine + " ");
         if (yours.rank() > mine.rank()) 
         {  System.out.println("You win");
            wins++;
         }
         else 
            System.out.println("I win");
      }
      System.out.println
   ("Your wins: " + wins + " My wins: " + (rounds - wins));
      
   }

   private Card[] deck;
   private int cards;
}
