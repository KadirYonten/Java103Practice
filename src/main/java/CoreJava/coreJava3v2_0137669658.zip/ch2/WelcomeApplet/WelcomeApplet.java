/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */

/**
 * @version 1.10 10 Mar 1997 
 * @author Cay Horstmann
 */

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class WelcomeApplet extends Applet
   implements ActionListener
{  public void start()
   {  setLayout(new BorderLayout());
      Label l = new Label(getParameter("greeting"), 
         Label.CENTER);
      l.setFont(new Font("Times", Font.BOLD, 18));
      add(l, "Center");
      Panel p = new Panel();
      Button b1 = new Button("Cay Horstmann");
      b1.addActionListener(this);
      p.add(b1);
      Button b2 = new Button("Gary Cornell");
      b2.addActionListener(this);
      p.add(b2);
      add(p, "South");      
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      String uName;
      URL u;
      if (arg.equals("Cay Horstmann")) 
         uName = "http://www.horstmann.com";
      else if (arg.equals("Gary Cornell")) 
         uName = "mailto:gcornell@ix.netcom.com";
      else return;
      try
      {  u = new URL(uName);
         getAppletContext().showDocument(u);
      }
      catch(Exception e)
      {  showStatus("Error " + e);
      }
   }
}

