/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 10 Mar 1997 
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.net.*;
import java.io.*;

public class ImageViewer extends Frame
   implements ActionListener
{  public ImageViewer()
   {  setTitle("ImageViewer");

      MenuBar mbar = new MenuBar();
      Menu m = new Menu("File");
      MenuItem m1 = new MenuItem("Open");
      m1.addActionListener(this);
      m.add(m1);            
      MenuItem m2 = new MenuItem("Exit");
      m2.addActionListener(this);
      m.add(m2);            
      mbar.add(m);
      addWindowListener(new WindowAdapter() 
      {  public void windowClosing(WindowEvent e) 
         { System.exit(0); } 
      } );
      setMenuBar(mbar);
      setSize(300, 400);
      show();
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Open"))
      {  FileDialog d = new FileDialog(this,
            "Open image file", FileDialog.LOAD);
         d.setFile("*.gif");
         d.setDirectory(lastDir);
         d.show();
         String f = d.getFile();
         lastDir = d.getDirectory();
         if (f != null)
            image = Toolkit.getDefaultToolkit().getImage(lastDir + f);
         repaint();
      }
      else if(arg.equals("Exit")) System.exit(0);
   }   

   public void paint(Graphics g)
   {  g.translate(getInsets().left, getInsets().top);
      if (image != null)   
         g.drawImage(image, 0, 0, this);
   }

   public static void main(String args[])
   {  new ImageViewer();
   }

   private Image image = null;
   private String lastDir = "";
}





