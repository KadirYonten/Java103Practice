/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import corejava.*;

public class PopupCalculatorApplet extends Applet
   implements ActionListener
{  public void init()
   {  Button calcButton = new Button("Calculator");
      calcButton.addActionListener(this);
      add(calcButton);
   }

   public void actionPerformed(ActionEvent evt)
   {  if (calc.isVisible()) calc.setVisible(false);
      else calc.show();
   }

   private Frame calc = new Calculator();
}

class Calculator extends Frame 
   implements ActionListener
{  public Calculator()
   {  setTitle("Calculator");
      setSize(100, 150);

      display = new TextField("0");
      display.setEditable(false);
      add(display, "North");
      
      Panel p = new Panel();
      p.setLayout(new GridLayout(4, 4));
      for (int i = 0; i <= 9; i++) 
         addButton(p, "" + (char)('0' + i));      
      addButton(p, "+");
      addButton(p, "-");
      addButton(p, "*");
      addButton(p, "/");
      addButton(p, "%");
      addButton(p, "=");
      add(p, "Center");
   }

   public void addButton(Container c, String s)
   {  Button b = new Button(s);
      c.add(b);
      b.addActionListener(this);
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String s = evt.getActionCommand();
      if ('0' <= s.charAt(0) && s.charAt(0) <= '9')
      {  if (start) display.setText(s);
         else display.setText(display.getText() + s);
         start = false;
      }
      else
      {  if (start)
         {  if (s.equals("-")) 
            { display.setText(s); start = false; }
            else op = s;
         }
         else
         {  calculate(Integer.parseInt(display.getText()));
            op = s;
            start = true;
         }
      }
   }
   
   public void calculate(int n)
   {  if (op.equals("+")) arg += n;
      else if (op.equals("-")) arg -= n;
      else if (op.equals("*")) arg *= n;
      else if (op.equals("/")) arg /= n;
      else if (op.equals("%")) arg %= n;
      else if (op.equals("=")) arg = n;
      display.setText("" + arg);
   }
   
   private TextField display;
   private int arg = 0;
   private String op = "=";
   private boolean start = true;
}

