/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;
import java.io.*;

public class Bookmark extends Applet implements ActionListener
{  public void init()
   {  setLayout(new BorderLayout());
      add(links, "Center");
      links.addActionListener(this);
      int i = 1;
      String s;
      while ((s = getParameter("link_" + i)) != null)
      {  links.add(s);
         i++;
      }
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      try
      {  AppletContext context = getAppletContext();
         URL u = new URL((String)arg);
         context.showDocument(u, "right");
      } catch(Exception e)
      {  showStatus("Error " + e);
      }
   }
   
   private List links = new List(10, false);
}
