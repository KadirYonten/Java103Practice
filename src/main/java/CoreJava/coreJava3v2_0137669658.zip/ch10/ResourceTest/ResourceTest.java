/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import corejava.*;

public class ResourceTest extends Applet
   implements ActionListener
{  public void init()
   {  Button b = new Button("About");
      b.addActionListener(this);
      add(b);
   }
   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if(arg.equals("About"))
      {  if (ab == null) // first time
            ab = new AboutDialog();   
          ab.show();
      }
   }

   private AboutDialog ab;
}

class AboutDialog extends Frame
{  public AboutDialog()
   {  TextArea ta = new TextArea();
      add(ta, "Center");
                
      Panel p = new Panel();
      Button ok = new Button("Ok");
      p.add(ok);
      add(p, "South");

      try
      {  InputStream in = AboutDialog.class.
            getResourceAsStream("AboutDialog.txt");
         BufferedReader br = new BufferedReader(new
            InputStreamReader(in));
         String line;
         while ((line = br.readLine()) != null)
            ta.append(line + "\n");
      } catch(IOException e) {}

      ok.addActionListener(new ActionListener() { public void
         actionPerformed(ActionEvent evt) { setVisible(false); } } );

      addWindowListener(new WindowAdapter() { public void
            windowClosing(WindowEvent e) { setVisible(false); } } );

      setSize(220, 150);
   }
}

