/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Apr 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.applet.*;

public class AlignTest extends Applet
{  public void paint(Graphics g)
   {  String alignType = getParameter("alignment");
      if (alignType == null) alignType = "DEFAULT";
      Dimension d = getSize();
      int client_width = d.width;
      int client_height = d.height;

      g.drawRect(0, 0, client_width - 1, client_height - 1);
      Font f = new Font("SansSerif", Font.BOLD, 18);
      FontMetrics fm = g.getFontMetrics(f);
      g.setFont(f);
      g.setColor(Color.red);
      int cx = (client_width 
         - fm.stringWidth(alignType)) / 2;
      int cy = (client_height 
         - fm.getHeight()) / 2 + fm.getAscent();
      g.drawString(alignType, cx, cy);
   }
}      
