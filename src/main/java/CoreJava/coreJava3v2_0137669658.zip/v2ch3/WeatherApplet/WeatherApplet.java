/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * version 1.10 27 Jun 1997
 * author Cay Horstmann
 */

import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class WeatherApplet extends Applet
   implements ActionListener
{  public void init()
   {  setLayout(new BorderLayout());
   
      state = new List(4, false);
      city = new List(4, false);
      state.addItem("Alabama");
      state.addItem("Alaska");
      state.addItem("Arizona");
      state.addItem("Arkansas");
      state.addItem("California");
      state.addItem("Colorado");
      state.addItem("Connecticut");
      state.addItem("Delaware");
      state.addItem("Florida");
      state.addItem("Georgia");
      state.addItem("Hawaii");
      state.addItem("Idaho");
      state.addItem("Illinois");
      state.addItem("Indiana");
      state.addItem("Iowa");
      state.addItem("Kansas");
      state.addItem("Kentucky");
      state.addItem("Lousisiana");
      state.addItem("Maine");
      state.addItem("Maryland");
      state.addItem("Massachusetts");
      state.addItem("Michigan");
      state.addItem("Minnesota");
      state.addItem("Mississippi");
      state.addItem("Missouri");
      state.addItem("Montana");
      state.addItem("Nebraska");
      state.addItem("Nevada");
      state.addItem("New_Hampshire");
      state.addItem("New_Jersey");
      state.addItem("New_Mexico");
      state.addItem("New_York");
      state.addItem("North_Carolina");
      state.addItem("North_Dakota");
      state.addItem("Ohio");
      state.addItem("Oklahoma");
      state.addItem("Oregon");
      state.addItem("Pennsylvania");
      state.addItem("Rhode_Island");
      state.addItem("South_Carolina");
      state.addItem("South_Dakota");
      state.addItem("Tennessee");
      state.addItem("Texas");
      state.addItem("Utah");
      state.addItem("Vermont");
      state.addItem("Virginia");
      state.addItem("Washington");
      state.addItem("West_Virginia");
      state.addItem("Wisconsin");
      state.addItem("Wyoming");
      
      Panel p = new Panel();
      p.add(state);
      p.add(city);
      state.addActionListener(this);
      city.addActionListener(this);

      add(p, "North");
      weather = new TextArea();
      weather.setFont(new Font("Monospaced", Font.PLAIN, 12));
      weather.setText("Double-click on a state!");
      add(weather, "Center");
   }

   public void actionPerformed(ActionEvent evt)
   {  if (evt.getSource().equals(state))
      {  showStatus("Please wait...getting list of cities");
         weather.setText("");
         getCities(state.getSelectedItem());
         showStatus("Double-click on a city!");
      }
      else if (evt.getSource().equals(city))
      {  showStatus
            ("Please wait...getting weather information");
         weather.setText("");
         getWeather(state.getSelectedItem(), 
            city.getSelectedItem());
         showStatus("Double-click on a state or city!");
      }
   }

   public void getCities(String state)
   {  try
      {  String query = "gopher://downwind.sprl.umich.edu" 
            + "/Weather_Text/U.S._City_Forecasts/" + state;
         URL s = new URL(server + script + "?" + query);
         BufferedReader in = new BufferedReader
            (new InputStreamReader(s.openStream()));

         city.removeAll();
         int ch;
         boolean more = true;
         while (more)
         {  String str = in.readLine();
            if (str != null)
            {  int i = str.indexOf('0', 1);
               if (i >= 0)
               {  String t = str.substring(1, i).trim();
                  city.addItem(t);
               }
            }
            else more = false;
         }
      }
      catch(IOException e)
      {  showStatus("Error " + e);
      }
   }
   
   public void getWeather(String state, String city)
   {  String r = new String();
      try
      {  String query = "gopher://downwind.sprl.umich.edu" 
            + "/Weather_Text/U.S._City_Forecasts/" + state
            + "/" + replaceAll(city, " ", "%20");
         URL s = new URL(server + script + "?" + query);
         BufferedReader in = new BufferedReader
            (new InputStreamReader(s.openStream()));

         boolean more = true;
         while (more)
         {  String str = in.readLine();
            if (str != null)
               weather.append(str + "\n");
            else more = false;
         }
      }
      catch(IOException e)
      {  showStatus("Error " + e);
      }
   }

   private static String replaceAll(String s, String t, 
      String u)
   {  String r = "";
      int pos = 0;
      int nextpos;
      while ((nextpos = s.indexOf(t, pos)) >= 0) 
      {  r = r + s.substring(pos, nextpos) + u;
         pos = nextpos + t.length();
      }
      r = r + s.substring(pos);
      return r;
   }         
   
   private String server = "http://www.horstmann.com";
   private String script = "/corejava/proxysvr.cgi";
   private TextArea weather;
   private List city;
   private List state;
}