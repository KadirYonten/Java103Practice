/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 Feb 1996 
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
import java.net.*;
import java.io.*;
import corejava.*;

public class MailOrderTest extends Applet
   implements ActionListener
{  public void init()
   {  Panel p = new Panel();
      p.setLayout(new FlowLayout());
      name = new Choice();
      try      
      {  URL url = new URL(getDocumentBase(), "prices.dat");
         prices.load(url.openStream());
      } catch(Exception e) { showStatus("Error " + e); }

      Enumeration e = prices.propertyNames();
      while (e.hasMoreElements()) 
         name.addItem(((String)e.nextElement()).replace('+',
            ' '));
      quantity = new IntTextField(1, 4);
      p.add(name);
      p.add(quantity);
      addButton(p, "Add");
      addButton(p, "Done");
      addButton(p, "Send");
      Panel p2 = new Panel();
      p2.setLayout(new GridLayout(2, 1));
      p2.add(addressDialog());
      p2.add(p);
      
      add(p2, "North");
      add(canvas = new PurchaseOrderCanvas(), "Center");
      canvas.setSize(250, 150);
      canvas.redraw(a);
   }

   public void addButton(Container c, String name)
   {  Button b = new Button(name);
      b.addActionListener(this);
      c.add(b);
   }
   
   private Panel addressDialog()
   {  Panel p = new Panel();
      GridBagLayout gbl = new GridBagLayout();
      p.setLayout(gbl);
      
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.BOTH;
      gbc.weightx = 100;
      gbc.weighty = 100;
      add(p, new Label("Name"), gbc, 0, 0, 1, 1);
      add(p, nameField, gbc, 1, 0, 3, 1);
      add(p, new Label("Street"), gbc, 0, 1, 1, 1);
      add(p, streetField, gbc, 1, 1, 3, 1);
      add(p, new Label("City"), gbc, 0, 2, 1, 1);
      add(p, cityField, gbc, 1, 2, 3, 1);
      add(p, new Label("State"), gbc, 0, 3, 1, 1);
      add(p, stateField, gbc, 1, 3, 1, 1);
      add(p, new Label("Zip"), gbc, 2, 3, 1, 1);
      add(p, zipField, gbc, 3, 3, 1, 1);
      
      return p;
   }

   public void add(Container p, Component c, 
      GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      p.add(c, gbc);
   }

   
   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Add"))
      {  if (quantity.isValid())
         {  String itemName = name.getSelectedItem();
            a.addElement(new Item(itemName, 
               quantity.getValue(), 
               Format.atof((String)
                  prices.get(itemName.replace(' ', '+')))));
         }
      }   
      else if (arg.equals("Done"))
      {  a.addElement(new Item("State Tax", 1, 0.00));
         a.addElement(new Item("Shipping", 1, 5.00));
         a.trimToSize();
      }
      else if (arg.equals("Send"))
      {  int i;
         String data;
         data = nameField.getText() + "\n"
            + streetField.getText() + "\n"
            + cityField.getText() + " "
            + stateField.getText() + " "
            + zipField.getText() + "\n\n";
         for (i = 0; i < a.size(); i++)
            data += a.elementAt(i).toString() + "\n";
         mailOrder(data);
         a = new Vector();
      }
      canvas.redraw(a);
   }
   
   public void mailOrder(String sdata)
   {  String home = "www.horstmann.com";
      String script = "/cgi-bin/mailto.cgi";
      String recipient = "orders@corejava.com";
      int port = 80;
      Socket s = null;

      try
      {  s = new Socket(home, port);

         PrintWriter out
            = new PrintWriter(s.getOutputStream());
         BufferedReader in = new BufferedReader
            (new InputStreamReader(s.getInputStream()));
         /* the first line of the data is the recipient address
            and the data is terminated by a .
         */
         sdata = recipient + "\r\n" 
            + "Subject: Order\r\n"
            + sdata 
            + ".\r\n";
         out.print("POST " + script 
            + " HTTP/1.0\r\n" 
            + "Content-type: "
            + "application/x-www-form-urlencoded\r\n"
            + "Content-length: " 
          + sdata.length() + "\r\n\r\n");
         out.print(sdata);
         out.flush();

         String rdata = "";
         String line;
         while ((line = in.readLine()) != null)
            rdata += line + "|";
         showStatus(rdata);
         s.close();
      }
      catch (Exception e)
      {  showStatus("Error " + e);
         if (s != null)
         {  try
            {  s.close();
            }
            catch (IOException ex) {}
         }
      }
   }

   private Vector a = new Vector();
   private Choice name;
   private IntTextField quantity;
   private PurchaseOrderCanvas canvas;   
   private Properties prices = new Properties();
   private TextField nameField = new TextField();
   private TextField streetField = new TextField();
   private TextField cityField = new TextField();
   private TextField stateField = new TextField();
   private TextField zipField = new TextField();
}

class Item
{  Item(String n, int q, double u)
   {  name = n;
      quantity = q;
      unitPrice = u;
   }
   
   public String toString()
   {  return new Format("%-20s").form(name)
         + new Format("%6d").form(quantity)
         + new Format("%8.2f").form(unitPrice);
   }

   private String name;
   private int quantity;
   private double unitPrice;
}

class PurchaseOrderCanvas extends Canvas
{  public void redraw(Vector new_a)
   {  a = new_a;
      repaint();
   }
   
   public void paint(Graphics g)
   {  Font f = new Font("Monospaced", Font.PLAIN, 12);
      g.setFont(f);
      FontMetrics fm = g.getFontMetrics(f);
      int height = fm.getHeight();
      int x = 0;
      int y = 0; 
      int i = 0;
      y += height;
      g.drawString("Your Order: ", x, y);
      for (i = 0; i < a.size(); i++)
      {  y += height;      
         g.drawString(a.elementAt(i).toString(), x, y);
      }
   }
  
   private Vector a;
}



