/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Jun 1997
 * @author Cay Horstmann
 */

import java.io.*;
import java.net.*;

public class ThreadedEchoServer
{  public static void main(String[] args ) 
   {  int i = 1;
      try 
      {  ServerSocket s = new ServerSocket(8189);
         
         for (;;)
         {  Socket incoming = s.accept( );
            System.out.println("Spawning " + i);
            new ThreadedEchoHandler(incoming, i).start();
            i++;
         }   
      }
      catch (Exception e) 
      {  System.out.println(e);
      } 
   } 
}

class ThreadedEchoHandler extends Thread
{  public ThreadedEchoHandler(Socket i, int c) 
   { incoming = i; counter = c; }
   
   public void run()
   {  try 
      {  BufferedReader in = new BufferedReader
            (new InputStreamReader(incoming.getInputStream()));
         PrintWriter out = new PrintWriter
            (incoming.getOutputStream(), true /* autoFlush */);

         out.println( "Hello! Enter BYE to exit." );

         boolean done = false;
         while (!done)
         {  String str = in.readLine();
            if (str == null) done = true;
            else
            {  out.println("Echo (" + counter + "): " + str);

               if (str.trim().equals("BYE")) 
                  done = true;
            } 
         }
         incoming.close();         
      }
      catch (Exception e) 
      {  System.out.println(e);
      } 
   }
   
   private Socket incoming;
   private int counter;
}

