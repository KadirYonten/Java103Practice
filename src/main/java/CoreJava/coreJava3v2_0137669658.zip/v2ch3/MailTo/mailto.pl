#!/usr/bin/perl

# Cay S. Horstmann & Gary Cornell, Core Java
# Published By Sun Microsystems Press/Prentice-Hall
# Copyright (C) 1997 Sun Microsystems Inc.
# All Rights Reserved.
#
# Permission to use, copy, modify, and distribute this 
# software and its documentation for NON-COMMERCIAL purposes
# and without fee is hereby granted provided that this 
# copyright notice appears in all copies. 
# 
# THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
# WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
# PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
# AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
# BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
# THIS SOFTWARE OR ITS DERIVATIVES.

#!/usr/bin/perl

# This should match the mail program on your system.
$mailprog = '/usr/lib/sendmail';

# first line of input is recipient

print "Content-type: text/plain\n\n";

$recipient=<STDIN>;

# Now send mail to $recipient
if (open (MAIL, "|$mailprog $recipient"))
{  

while (($input = <STDIN>) && $input ne ".\n" && $input ne ".\r\n")
{  print MAIL $input;
}

close (MAIL);
print "OK\n"
}
else
{
print "ERROR\n"
}
