/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 27 Jun 1997
 * @author Cay Horstmann
 */

import java.io.*;

public class MailTo
{  public static void main(String[] args)
   {  try
      {  String line;
         BufferedReader in = new BufferedReader
            (new InputStreamReader(System.in));
         String recipient = in.readLine();
         Runtime rt = Runtime.getRuntime();
         Process p = rt.exec
            ("/usr/lib/sendmail " + recipient);
         PrintWriter out = new PrintWriter
            (p.getOutputStream(), true /* autoFlush */);
         while ((line = in.readLine()) != null 
               && !line.equals("."))
            out.println(line);
         out.close();
      }
      catch (Exception e)
      {  System.out.println("Error " + e);
      }   
   }
}
