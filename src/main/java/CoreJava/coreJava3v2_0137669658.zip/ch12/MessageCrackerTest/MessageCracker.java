/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 07 May 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;

public class MessageCracker
   implements MouseListener, ComponentListener, 
   FocusListener, KeyListener, ContainerListener,
   WindowListener, TextListener, AdjustmentListener,
   ActionListener, ItemListener
{  public void add(Component c)
   {  c.addMouseListener(this);
      c.addComponentListener(this);
      c.addFocusListener(this);
      c.addKeyListener(this);
      if (c instanceof Container)
      {  ((Container)c).addContainerListener(this);
         Component[] a = ((Container)c).getComponents();
         for (int i = 0; i < a.length; i++)
            add(a[i]);
      }
      if (c instanceof Window)
         ((Window)c).addWindowListener(this);
      if (c instanceof TextComponent)
         ((TextComponent)c).addTextListener(this);
      if (c instanceof Scrollbar)
         ((Scrollbar)c).addAdjustmentListener(this);
      if (c instanceof Button)
         ((Button)c).addActionListener(this);
      if (c instanceof Button)
         ((Button)c).addActionListener(this);
      if (c instanceof Button)
         ((Button)c).addActionListener(this);
      if (c instanceof List)
      {  ((List)c).addActionListener(this);
         ((List)c).addItemListener(this);
      }
      if (c instanceof TextField)
         ((TextField)c).addActionListener(this);
      if (c instanceof Checkbox)
         ((Checkbox)c).addItemListener(this);
      if (c instanceof Choice)
         ((Choice)c).addItemListener(this);
   }

   public void mouseClicked(MouseEvent e) 
   {  System.out.println(e);
   }
   public void mouseEntered(MouseEvent e) 
   {  System.out.println(e);
   }
   public void mouseExited(MouseEvent e) 
   {  System.out.println(e);
   }
   public void mousePressed(MouseEvent e) 
   {  System.out.println(e);
   }
   public void mouseReleased(MouseEvent e) 
   {  System.out.println(e);
   }

   public void componentHidden(ComponentEvent e) 
   {  System.out.println(e);
   }
   public void componentMoved(ComponentEvent e) 
   {  System.out.println(e);
   }
   public void componentResized(ComponentEvent e) 
   {  System.out.println(e);
   }
   public void componentShown(ComponentEvent e)
   {  System.out.println(e);
   }

   public void focusGained(FocusEvent e) 
   {  System.out.println(e);
   }
   public void focusLost(FocusEvent e) 
   {  System.out.println(e);
   }

   public void keyPressed(KeyEvent e) 
   {  System.out.println(e);
   }
   public void keyReleased(KeyEvent e) 
   {  System.out.println(e);
   }
   public void keyTyped(KeyEvent e) 
   {  System.out.println(e);
   }

   public void windowActivated(WindowEvent e) 
   {  System.out.println(e);
   }
   public void windowClosed(WindowEvent e) 
   {  System.out.println(e);
   }
   public void windowClosing(WindowEvent e) 
   {  System.out.println(e);
   }
   public void windowDeactivated(WindowEvent e) 
   {  System.out.println(e);
   }
   public void windowDeiconified(WindowEvent e) 
   {  System.out.println(e);
   }
   public void windowIconified(WindowEvent e) 
   {  System.out.println(e);
   }
   public void windowOpened(WindowEvent e)
   {  System.out.println(e);
   }

   public void componentAdded(ContainerEvent e) 
   {  System.out.println(e);
   }
   public void componentRemoved(ContainerEvent e) 
   {  System.out.println(e);
   }

   public void textValueChanged(TextEvent e) 
   {  System.out.println(e);
   }

   public void adjustmentValueChanged(AdjustmentEvent e) 
   {  System.out.println(e);
   }

   public void actionPerformed(ActionEvent e) 
   {  System.out.println(e);
   }

   public void itemStateChanged(ItemEvent e) 
   {  System.out.println(e);
   }
}

