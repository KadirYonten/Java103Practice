/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 06 May 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import corejava.*;

public class ExceptTest extends CloseableFrame
   implements ItemListener
{  public ExceptTest()
   {  setLayout(new GridLayout(8, 1));
      CheckboxGroup g = new CheckboxGroup();
      addCheckbox("Divide by zero", g);
      addCheckbox("Bad cast", g);    
      addCheckbox("Array bounds", g);    
      addCheckbox("Null pointer", g);    
      addCheckbox("sqrt(-1)", g);    
      addCheckbox("Overflow", g);    
      addCheckbox("No such file", g);    
      addCheckbox("Throw unknown", g);    
   }

   private void addCheckbox(String s, CheckboxGroup g)
   {  Checkbox cb = new Checkbox(s, g, false);
      cb.addItemListener(this);
      add(cb);
   }

   public void itemStateChanged(ItemEvent evt) 
   {  try
      {  String name = (String)evt.getItem();
         if (name.equals("Divide by zero"))
         {  a[1] = a[2] / (a[3] - a[3]);
         }
         else if (name.equals("Bad cast"))
         {  f = (Frame)evt.getItem();
         }
         else if (name.equals("Array bounds"))
         {  a[1] = a[10];
         }
         else if (name.equals("Null pointer"))
         {  f = null;
            f.setSize(200, 200);            
         }
         else if (name.equals("sqrt(-1)"))
         {  a[1] = Math.sqrt(-1);
         }
         else if (name.equals("Overflow"))
         {  a[1] = 1000 * 1000 * 1000 * 1000;
            int n = (int)a[1];
         }
         else if (name.equals("No such file"))
         {  FileInputStream is = new FileInputStream(name);
         }
         else if (name.equals("Throw unknown"))
         {  throw new UnknownError();
         }
      }
      catch(RuntimeException e)
      {  System.out.println("Caught RuntimeException: " + e);
      }
      catch(Exception e)
      {  System.out.println("Caught Exception: " + e);
      }
   }

   public static void main(String[] args)
   {  Frame f = new ExceptTest();
      f.show();  
   }
   
   private double[] a = new double[10];
   private Frame f = null;
}



