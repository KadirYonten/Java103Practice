/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 15 Sep 1997
 * @author Cay Horstmann
 */

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import corejava.*;

public class CollationTest extends CloseableFrame
   implements ActionListener, ItemListener
{  public CollationTest()
   {  setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(new Label("Locale"), gbc, 0, 0, 1, 1);
      add(new Label("Strength"), gbc, 0, 1, 1, 1);
      add(new Label("Decomposition"), gbc, 0, 2, 1, 1);
      add(addButton, gbc, 0, 3, 1, 1);
      gbc.anchor = GridBagConstraints.WEST;
      add(localeChoice, gbc, 1, 0, 1, 1);
      add(strengthChoice, gbc, 1, 1, 1, 1);
      add(decompositionChoice, gbc, 1, 2, 1, 1);
      add(newWord, gbc, 1, 3, 1, 1);
      add(sortedWords, gbc, 1, 4, 1, 1);

      locales = Collator.getAvailableLocales();
      for (int i = 0; i < locales.length; i++)
         localeChoice.add(locales[i].getDisplayName());
      localeChoice.select(
         Locale.getDefault().getDisplayName());

      strings.addElement("America");
      strings.addElement("ant");
      strings.addElement("Zulu");
      strings.addElement("zebra");
      strings.addElement("�ngstrom");
      strings.addElement("Angstrom");
      strings.addElement("Ant");
      updateDisplay();

      addButton.addActionListener(this);
      localeChoice.addItemListener(this);
      strengthChoice.addItemListener(this);
      decompositionChoice.addItemListener(this);
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void actionPerformed(ActionEvent evt)
   {  String arg = evt.getActionCommand();
      if (arg.equals("Add"))
      {  strings.addElement(newWord.getText());
         updateDisplay();
      }
   }

   public void updateDisplay()
   {  Locale currentLocale = locales[
         localeChoice.getSelectedIndex()];

      currentCollator 
         = Collator.getInstance(currentLocale);
      currentCollator.setStrength(strengthChoice.getValue());
      currentCollator.setDecomposition(
         decompositionChoice.getValue());
      sort();
      sortedWords.setText("");
      for (int i = 0; i < sortedStrings.size(); i++)
         sortedWords.append(sortedStrings.elementAt(i) + "\n");
   }

   public void sort()
   {  /* this really should be replaced with a better 
         sort algorithm 
      */
      sortedStrings = new Vector();
      for (int i = 0; i < strings.size(); i++)
      {  boolean inserted = false;
         String s = (String)strings.elementAt(i);
         for (int j = 0; j < sortedStrings.size() 
               && !inserted; j++)
         {  int d = currentCollator.compare(s,
               (String)sortedStrings.elementAt(j));
            if (d < 0)
            {  sortedStrings.insertElementAt(s, j);
               inserted = true;
            }
            else if (d == 0)
            {  sortedStrings.insertElementAt("=" + s, j + 1);
               inserted = true;
            }
         }
         if (!inserted) sortedStrings.addElement(s);
      }
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getSource() instanceof Choice)
      {  if (evt.getStateChange() == ItemEvent.SELECTED)
            updateDisplay();
      }
   }

   public static void main(String[] args)
   {  Frame f = new CollationTest();
      f.setSize(400, 400);
      f.show();
   }

   private Locale[] locales;
   private Vector strings = new Vector();
   private Vector sortedStrings = new Vector();
   private Collator currentCollator;

   private Choice localeChoice = new Choice();
   private EnumChoice strengthChoice 
      = new EnumChoice(Collator.class, 
        new String[] { "Primary", "Secondary", "Tertiary" });
   private EnumChoice decompositionChoice 
      = new EnumChoice(Collator.class, 
        new String[] { "Canonical Decomposition", 
        "Full Decomposition", "No Decomposition" });
   private TextField newWord = new TextField(20);
   private TextArea sortedWords = new TextArea(10, 20);
   private Button addButton = new Button("Add");
 }

class EnumChoice extends Choice
{  public EnumChoice(Class cl, String[] labels)
   {  for (int i = 0; i < labels.length; i++)
      {  String label = labels[i];
         String name = label.toUpperCase().replace(' ', '_');
         int value = 0;
         try
         {  java.lang.reflect.Field f = cl.getField(name);
            value = f.getInt(cl);
         }
         catch(Exception e)
         {  label = "(" + label + ")"; 
         }
         table.put(label, new Integer(value));
         add(label);
      }
      select(labels[0]);
   }

   public int getValue()
   {  return ((Integer)table.get(getSelectedItem())).intValue();
   }

   private Hashtable table = new Hashtable();
}

