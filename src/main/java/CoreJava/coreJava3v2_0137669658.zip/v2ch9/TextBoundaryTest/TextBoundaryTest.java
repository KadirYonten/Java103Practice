/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 15 Sep 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import corejava.*;

public class TextBoundaryTest extends CloseableFrame
   implements ItemListener
{  public TextBoundaryTest()
   {  Panel p = new Panel();
      addCheckbox(p, "Character", cbGroup, false);
      addCheckbox(p, "Word", cbGroup, false);
      addCheckbox(p, "Line", cbGroup, false);
      addCheckbox(p, "Sentence", cbGroup, true);
   
      setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(new Label("Locale"), gbc, 0, 0, 1, 1);
      gbc.anchor = GridBagConstraints.WEST;
      add(localeChoice, gbc, 1, 0, 1, 1);
      add(p, gbc, 0, 1, 2, 1);
      add(inputText, gbc, 0, 2, 2, 1);
      add(outputText, gbc, 0, 3, 2, 1);

      localeChoice.addItemListener(this);
      
      locales = Collator.getAvailableLocales();
      for (int i = 0; i < locales.length; i++)
         localeChoice.add(locales[i].getDisplayName());
      localeChoice.select(
         Locale.getDefault().getDisplayName());

      inputText.setText("The quick, brown fox jump-ed\n"
        + "over the lazy \"dog.\" And then...what happened?");
       updateDisplay();
   }

   public void addCheckbox(Panel p, String name, 
      CheckboxGroup g, boolean v)
   {  Checkbox c = new Checkbox(name, g, v);
      c.addItemListener(this);
      p.add(c);
   }
   
   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void updateDisplay()
   {  Locale currentLocale = locales[
         localeChoice.getSelectedIndex()];
      BreakIterator currentBreakIterator = null;
      String s = cbGroup.getSelectedCheckbox().getLabel();
      if (s.equals("Character"))
         currentBreakIterator 
            = BreakIterator.getCharacterInstance(currentLocale);
      else if (s.equals("Word"))
         currentBreakIterator 
            = BreakIterator.getWordInstance(currentLocale);
      else if (s.equals("Line"))
         currentBreakIterator 
            = BreakIterator.getLineInstance(currentLocale);
      else if (s.equals("Sentence"))
         currentBreakIterator 
            = BreakIterator.getSentenceInstance(currentLocale);

      String text = inputText.getText();
      currentBreakIterator.setText(text);
      outputText.setText("");

      int from = currentBreakIterator.first();
      int to;
      while ((to = currentBreakIterator.next()) != 
         BreakIterator.DONE)
      {  outputText.append(text.substring(from, to) + "|");
         from = to;
      }
      outputText.append(text.substring(from));
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
      {  updateDisplay();
      }
   }

   public static void main(String[] args)
   {  Frame f = new TextBoundaryTest();
      f.setSize(400, 400);
      f.show();
   }

   private Locale[] locales;
   private BreakIterator currentBreakIterator;
   
   private Choice localeChoice = new Choice();
   private TextArea inputText = new TextArea(6, 40);
   private TextArea outputText = new TextArea(6, 40);
   private CheckboxGroup cbGroup = new CheckboxGroup();
 }

