/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 17 Sep 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import corejava.*;

public class DateFormatTest extends CloseableFrame
   implements ActionListener, ItemListener
{  public DateFormatTest()
   {  setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(new Label("Locale"), gbc, 0, 0, 1, 1);
      add(new Label("Date style"), gbc, 0, 1, 1, 1);
      add(new Label("Time style"), gbc, 2, 1, 1, 1);
      add(new Label("Date"), gbc, 0, 2, 1, 1);
      add(new Label("Time"), gbc, 0, 3, 1, 1);
      gbc.anchor = GridBagConstraints.WEST;
      add(localeChoice, gbc, 1, 0, 2, 1);
      add(dateStyleChoice, gbc, 1, 1, 1, 1);
      add(timeStyleChoice, gbc, 3, 1, 1, 1);
      add(dateText, gbc, 1, 2, 2, 1);
      add(dateParseButton, gbc, 3, 2, 1, 1);
      add(timeText, gbc, 1, 3, 2, 1);
      add(timeParseButton, gbc, 3, 3, 1, 1);
      add(lenientCheckbox, gbc, 0, 4, 2, 1);

      locales = DateFormat.getAvailableLocales();
      for (int i = 0; i < locales.length; i++)
         localeChoice.add(locales[i].getDisplayName());
      localeChoice.select(
         Locale.getDefault().getDisplayName());
      currentDate = new Date();
      currentTime = new Date();
      updateDisplay();

      localeChoice.addItemListener(this);
      dateStyleChoice.addItemListener(this);
      timeStyleChoice.addItemListener(this);
      dateParseButton.addActionListener(this);
      timeParseButton.addActionListener(this);
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void actionPerformed(ActionEvent evt)
   {  if (evt.getSource() == dateParseButton)
      {  String d = dateText.getText();
         try
         {  currentDateFormat.setLenient
               (lenientCheckbox.getState());
            Date date = currentDateFormat.parse(d);
            currentDate = date;
            updateDisplay();
         }
         catch(ParseException e)
         {  dateText.setText("Parse error: " + d);
         }
         catch(IllegalArgumentException e)
         {  dateText.setText("Argument error: " + d);
         }
      }
      else if (evt.getSource() == timeParseButton)
      {  String t = timeText.getText();
         try
         {  currentDateFormat.setLenient
               (lenientCheckbox.getState());
            Date date = currentTimeFormat.parse(t);
            currentTime = date;
            updateDisplay();
         }
         catch(ParseException e)
         {  timeText.setText("Parse error: " + t);
         }
         catch(IllegalArgumentException e)
         {  timeText.setText("Argument error: " + t);
         }
      }
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getSource() instanceof Choice)
      {  if (evt.getStateChange() == ItemEvent.SELECTED)
            updateDisplay();
      }
   }

   public void updateDisplay()
   {  Locale currentLocale = locales[
         localeChoice.getSelectedIndex()];
      int dateStyle = dateStyleChoice.getValue();
      currentDateFormat 
         = DateFormat.getDateInstance(dateStyle, 
         currentLocale);
      String d = currentDateFormat.format(currentDate);
      dateText.setText(d);
      int timeStyle = timeStyleChoice.getValue();
      currentTimeFormat 
         = DateFormat.getTimeInstance(timeStyle, 
         currentLocale);
      String t = currentTimeFormat.format(currentTime);
      timeText.setText(t);
   }

   public static void main(String[] args)
   {  Frame f = new DateFormatTest();
      f.setSize(400, 200);
      f.show();
   }

   private Locale[] locales;

   private Date currentDate;
   private Date currentTime;
   private DateFormat currentDateFormat;
   private DateFormat currentTimeFormat;

   private Choice localeChoice = new Choice();
   private EnumChoice dateStyleChoice 
      = new EnumChoice(DateFormat.class, 
        new String[] { "Default", "Full", "Long",
        "Medium", "Short" });
   private EnumChoice timeStyleChoice
      = new EnumChoice(DateFormat.class, 
        new String[] { "Default", "Full", "Long",
        "Medium", "Short" });
   private Button dateParseButton = new Button("Parse date");
   private Button timeParseButton = new Button("Parse time");
   private TextField dateText = new TextField(30);
   private TextField timeText = new TextField(30);
   private TextField parseText = new TextField(30);
   private Checkbox lenientCheckbox 
      = new Checkbox("Parse lenient", true);
}

class EnumChoice extends Choice
{  public EnumChoice(Class cl, String[] labels)
   {  for (int i = 0; i < labels.length; i++)
      {  String label = labels[i];
         String name = label.toUpperCase().replace(' ', '_');
         int value = 0;
         try
         {  java.lang.reflect.Field f = cl.getField(name);
            value = f.getInt(cl);
         }
         catch(Exception e)
         {  label = "(" + label + ")"; 
         }
         table.put(label, new Integer(value));
         add(label);
      }
      select(labels[0]);
   }

   public int getValue()
   {  return ((Integer)table.get(getSelectedItem())).intValue();
   }

   private Hashtable table = new Hashtable();
}