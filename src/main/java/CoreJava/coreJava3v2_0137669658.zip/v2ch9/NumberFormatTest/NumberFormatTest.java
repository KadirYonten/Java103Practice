/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.00 17 Sep 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import corejava.*;

public class NumberFormatTest extends CloseableFrame
   implements ActionListener, ItemListener
{  public NumberFormatTest()
   {  Panel p = new Panel();
      addCheckbox(p, "Number", cbGroup, true);
      addCheckbox(p, "Currency", cbGroup, false);
      addCheckbox(p, "Percent", cbGroup, false);
   
      setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(new Label("Locale"), gbc, 0, 0, 1, 1);
      add(p, gbc, 1, 1, 1, 1);
      add(parseButton, gbc, 0, 2, 1, 1);
      gbc.anchor = GridBagConstraints.WEST;
      add(localeChoice, gbc, 1, 0, 1, 1);
      add(numberText, gbc, 1, 2, 1, 1);

      locales = NumberFormat.getAvailableLocales();
      for (int i = 0; i < locales.length; i++)
         localeChoice.add(locales[i].getDisplayName());
      localeChoice.select(
         Locale.getDefault().getDisplayName());
      currentNumber = 123456.78;
      updateDisplay();

      localeChoice.addItemListener(this);
      parseButton.addActionListener(this);
   }

   public void add(Component c, GridBagConstraints gbc,
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }

   public void addCheckbox(Panel p, String name, 
      CheckboxGroup g, boolean v)
   {  Checkbox c = new Checkbox(name, g, v);
      c.addItemListener(this);
      p.add(c);
   }

   public void actionPerformed(ActionEvent evt)
   {  if (evt.getSource() == parseButton)
      {  String s = numberText.getText();
         try
         {  Number n = currentNumberFormat.parse(s);
            if (n != null)
            {  currentNumber = n.doubleValue();
               updateDisplay();            
            }
            else
            {  numberText.setText("Parse error: " + s);
            }
         } 
         catch(ParseException e)
         {  numberText.setText("Parse error: " + s);
         }
      }
   }

   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
         updateDisplay();
   }

   public void updateDisplay()
   {  Locale currentLocale = locales[
         localeChoice.getSelectedIndex()];
      currentNumberFormat = null;
      String s = cbGroup.getSelectedCheckbox().getLabel();
      if (s.equals("Number"))
         currentNumberFormat 
            = NumberFormat.getNumberInstance(currentLocale);
      else if (s.equals("Currency"))
         currentNumberFormat
            = NumberFormat.getCurrencyInstance(currentLocale);
      else if (s.equals("Percent"))
         currentNumberFormat
            = NumberFormat.getPercentInstance(currentLocale);
      String n = currentNumberFormat.format(currentNumber);
      numberText.setText(n);
   }

   public static void main(String[] args)
   {  Frame f = new NumberFormatTest();
      f.setSize(400, 200);
      f.show();
   }

   private Locale[] locales;

   private double currentNumber;

   private Choice localeChoice = new Choice();
   private Button parseButton = new Button("Parse");
   private TextField numberText = new TextField(30);
   private CheckboxGroup cbGroup = new CheckboxGroup();
   private NumberFormat currentNumberFormat;
}