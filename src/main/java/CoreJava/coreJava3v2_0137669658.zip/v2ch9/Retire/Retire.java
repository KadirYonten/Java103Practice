/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.11 17 Sep 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
import java.text.*;
import java.io.*;
import corejava.*;

public class Retire extends Applet 
   implements ActionListener, ItemListener
{  public void init() 
   {  GridBagLayout gbl = new GridBagLayout();
      setLayout(gbl);
      
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.weightx = 100;
      gbc.weighty = 100;

      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.EAST;
      add(languageLabel, gbc, 0, 0, 1, 1);
      add(savingsLabel, gbc, 0, 1, 1, 1);
      add(contribLabel, gbc, 2, 1, 1, 1);
      add(incomeLabel, gbc, 4, 1, 1, 1);
      add(currentAgeLabel, gbc, 0, 2, 1, 1);
      add(retireAgeLabel, gbc, 2, 2, 1, 1);
      add(deathAgeLabel, gbc, 4, 2, 1, 1);
      add(inflationPercentLabel, gbc, 0, 3, 1, 1);
      add(investPercentLabel, gbc, 2, 3, 1, 1);

      gbc.fill = GridBagConstraints.HORIZONTAL;
      gbc.anchor = GridBagConstraints.WEST;
      add(localeChoice, gbc, 1, 0, 2, 1);
      add(savingsField, gbc, 1, 1, 1, 1);
      add(contribField, gbc, 3, 1, 1, 1);
      add(incomeField, gbc, 5, 1, 1, 1);
      add(currentAgeField, gbc, 1, 2, 1, 1);
      add(retireAgeField, gbc, 3, 2, 1, 1);
      add(deathAgeField, gbc, 5, 2, 1, 1);
      add(inflationPercentField, gbc, 1, 3, 1, 1);
      add(investPercentField, gbc, 3, 3, 1, 1);

      computeButton.setName("computeButton");
      computeButton.addActionListener(this);
      add(computeButton, gbc, 5, 3, 1, 1);
      add(retireCanvas, gbc, 0, 4, 4, 1);
      gbc.fill = GridBagConstraints.BOTH;
      add(retireText, gbc, 4, 4, 2, 1);
      retireText.setEditable(false);
      retireText.setFont(new Font("Monospaced", 
         Font.PLAIN, 10));

      info.savings = 0;
      info.contrib = 9000;
      info.income = 60000;
      info.currentAge = 35;
      info.retireAge = 65;
      info.deathAge = 85;
      info.investPercent = 0.1;
      info.inflationPercent = 0.05;


      localeChoice.addItemListener(this);
      locales = new Locale[] 
         { Locale.US, Locale.CHINA, Locale.GERMANY };
      for (int i = 0; i < locales.length; i++)
         localeChoice.add(locales[i].getDisplayLanguage());
      localeChoice.select(0); 
      setCurrentLocale();
   }

   void updateDisplay()
   {  languageLabel.setText(res.getString("language"));
      savingsLabel.setText(res.getString("savings"));
      contribLabel.setText(res.getString("contrib"));
      incomeLabel.setText(res.getString("income"));
      currentAgeLabel.setText(res.getString("currentAge"));
      retireAgeLabel.setText(res.getString("retireAge"));
      deathAgeLabel.setText(res.getString("deathAge"));
      inflationPercentLabel.setText
         (res.getString("inflationPercent"));
      investPercentLabel.setText
         (res.getString("investPercent"));
      computeButton.setLabel(res.getString("computeButton"));
   
      doLayout();
   }

   void setCurrentLocale()
   {  currentLocale 
         = locales[localeChoice.getSelectedIndex()];
      res = ResourceBundle.getBundle("RetireResources", 
         currentLocale);
      currencyFmt 
         = NumberFormat.getCurrencyInstance(currentLocale);
      numberFmt 
         = NumberFormat.getNumberInstance(currentLocale);
      percentFmt 
         = NumberFormat.getPercentInstance(currentLocale);

      updateDisplay();
      updateInfo();
      updateData();
      updateGraph();
   }

   void updateInfo()
   {  savingsField.setText(currencyFmt.format(info.savings));
      contribField.setText(currencyFmt.format(info.contrib));
      incomeField.setText(currencyFmt.format(info.income));
      currentAgeField.setText
         (numberFmt.format(info.currentAge));
      retireAgeField.setText(numberFmt.format(info.retireAge));
      deathAgeField.setText(numberFmt.format(info.deathAge));
      investPercentField.setText
         (percentFmt.format(info.investPercent));
      inflationPercentField.setText
         (percentFmt.format(info.inflationPercent));
   }

   void updateData()
   {  retireText.setText("");            
      MessageFormat retireMsg = new MessageFormat
         (res.getString("retire"));
      retireMsg.setLocale(getLocale());
      for (int i = info.currentAge; i <= info.deathAge; i++)
      {  Object[] args = { new Integer(i), 
            new Double(info.getBalance(i)) };
         retireText.append(retireMsg.format(args) + "\n");
      }

   }

   void updateGraph()
   {  info.colorPre = (Color)res.getObject("colorPre");
      info.colorGain = (Color)res.getObject("colorGain");
      info.colorLoss = (Color)res.getObject("colorLoss");
      retireCanvas.redraw(info);
   }

   public void add(Component c, GridBagConstraints gbc, 
      int x, int y, int w, int h)
   {  gbc.gridx = x;
      gbc.gridy = y;
      gbc.gridwidth = w;
      gbc.gridheight = h;
      add(c, gbc);
   }
   
   public void itemStateChanged(ItemEvent evt)
   {  if (evt.getStateChange() == ItemEvent.SELECTED)
      {  setCurrentLocale();
      }
   }

   void getInfo() throws ParseException
   {  info.savings = 
         currencyFmt.parse
         (savingsField.getText()).doubleValue();
      info.contrib = 
         currencyFmt.parse
         (contribField.getText()).doubleValue();
      info.income =
         currencyFmt.parse
         (incomeField.getText()).doubleValue();
      info.currentAge = 
         (int)numberFmt.parse
         (currentAgeField.getText()).longValue();
      info.retireAge = 
         (int)numberFmt.parse
         (retireAgeField.getText()).longValue();
      info.deathAge = 
         (int)numberFmt.parse
         (deathAgeField.getText()).longValue();
      info.investPercent = percentFmt.parse
         (investPercentField.getText()).doubleValue();
      info.inflationPercent = percentFmt.parse
         (inflationPercentField.getText()).doubleValue();
   }

   public void actionPerformed(ActionEvent evt)
   {  Component source = (Component)evt.getSource();
      if (source.getName().equals("computeButton"))
      {  try
         {  getInfo();
            updateData();
            updateGraph();
         } catch(ParseException e) {}
         updateInfo();
      }
   }

   private TextField savingsField = new TextField(10);      
   private TextField contribField = new TextField(10);      
   private TextField incomeField = new TextField(10);      
   private TextField currentAgeField = new TextField(4);      
   private TextField retireAgeField = new TextField(4);      
   private TextField deathAgeField = new TextField(4);      
   private TextField inflationPercentField = new TextField(6);      
   private TextField investPercentField = new TextField(6);      
   private TextArea retireText = new TextArea(10, 25);
   private RetireCanvas retireCanvas = new RetireCanvas();  
   private Button computeButton = new Button();
   private Label languageLabel = new Label();
   private Label savingsLabel = new Label();
   private Label contribLabel = new Label();
   private Label incomeLabel = new Label();
   private Label currentAgeLabel = new Label();
   private Label retireAgeLabel = new Label();
   private Label deathAgeLabel = new Label();
   private Label inflationPercentLabel = new Label();
   private Label investPercentLabel = new Label();

   private RetireInfo info = new RetireInfo();

   private Locale[] locales;
   private Locale currentLocale;
   private Choice localeChoice = new Choice();
   private ResourceBundle res;
   NumberFormat currencyFmt;
   NumberFormat numberFmt;
   NumberFormat percentFmt;
}

class RetireInfo
{  public double getBalance(int year)
   {  if (year < currentAge) return 0;
      else if (year == currentAge) 
      {  age = year;
         balance = savings;
         return balance;
      }
      else if (year == age)
         return balance;
      if (year != age + 1) 
         getBalance(year - 1);
      age = year;
      if (age < retireAge) 
         balance += contrib; 
      else
         balance -= income;
      balance = balance 
         * (1 + (investPercent - inflationPercent));
      return balance;
   }

   double savings;
   double contrib;
   double income;
   int currentAge;
   int retireAge;
   int deathAge;
   double inflationPercent;
   double investPercent;

   Color colorPre;
   Color colorGain;
   Color colorLoss;
   
   private int age;
   private double balance;
}

class RetireCanvas extends Canvas
{  public RetireCanvas() 
   {  setSize(400, 200);
   }

   public void redraw(RetireInfo newInfo)
   {  info = newInfo;
      repaint();
   }

   public void paint(Graphics g)
   {  if (info == null) return;
      
      int minValue = 0;
      int maxValue = 0;
      int i;
      for (i = info.currentAge; i <= info.deathAge; i++)
      {  int v = (int)info.getBalance(i);
         if (minValue > v) minValue = v;
         if (maxValue < v) maxValue = v;
      }
      if (maxValue == minValue) return;
            
      Dimension d = getSize();
      int barWidth = d.width / (info.deathAge 
         - info.currentAge + 1);
      double scale = (double)d.height 
         / (maxValue - minValue);
      
      for (i = info.currentAge; i <= info.deathAge; i++)
      {  int x1 = (i - info.currentAge) * barWidth + 1;
         int y1;
         int v = (int)info.getBalance(i);
         int height;
         int yOrigin = (int)(maxValue * scale);

         if (v >= 0)
         {  y1 = (int)((maxValue - v) * scale);
            height = yOrigin - y1;
         }
         else
         {  y1 = yOrigin;
            height = (int)(-v * scale);
         }
  
         if (i < info.retireAge)
            g.setColor(info.colorPre);
         else if (v >= 0)
            g.setColor(info.colorGain);
         else
            g.setColor(info.colorLoss);
         g.fillRect(x1, y1, barWidth - 2, height);         
         g.setColor(Color.black);
         g.drawRect(x1, y1, barWidth - 2, height);
      }
   }
   
   private RetireInfo info = null;
}