/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 23 Jun 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.event.*;
import corejava.*;

public class BounceExpress extends CloseableFrame
{  public BounceExpress()
   {  canvas = new Canvas();
      add(canvas, "Center");
      Panel p = new Panel();
      addButton(p, "Start", 
         new ActionListener()
         {  public void actionPerformed(ActionEvent evt)
            {  for (int i = 0; i < 5; i++)
               {  Ball b = new Ball(canvas, Color.black);
                  b.setPriority(Thread.NORM_PRIORITY);
                  b.start();
               }
            }
         });

      addButton(p, "Express",
         new ActionListener()
         {  public void actionPerformed(ActionEvent evt)
            {  for (int i = 0; i < 5; i++)
               {  Ball b = new Ball(canvas, Color.red);
                  b.setPriority(Thread.NORM_PRIORITY + 2);
                  b.start();
               }
            }
         });

      addButton(p, "Close",
         new ActionListener()
         {  public void actionPerformed(ActionEvent evt)
            {  canvas.setVisible(false);
               System.exit(0);
            }
         });
      add(p, "South");
   }

   public void addButton(Container c, String title,
      ActionListener a)
   {  Button b = new Button(title);
      c.add(b);
      b.addActionListener(a);
   }

   public static void main(String[] args)
   {  Frame f = new BounceExpress();
      f.show();  
   }
 
   private Canvas canvas;
}

class Ball extends Thread
{  public Ball(Canvas c, Color co) { box = c; color = co; }

   public void draw()
   {  Graphics g = box.getGraphics();
      g.setColor(color);
      g.fillOval(x, y, XSIZE, YSIZE);
      g.dispose();
   }
   
   public void move()
   {  if (!box.isVisible()) return;
      Graphics g = box.getGraphics();
      g.setColor(color);
      g.setXORMode(box.getBackground());
      g.fillOval(x, y, XSIZE, YSIZE);
      x += dx;
      y += dy;
      Dimension d = box.getSize();
      if (x < 0) 
      { x = 0; dx = -dx; }
      if (x + XSIZE >= d.width) 
      { x = d.width - XSIZE; dx = -dx; }
      if (y < 0) 
      { y = 0; dy = -dy; }
      if (y + YSIZE >= d.height) 
      { y = d.height - YSIZE; dy = -dy; }
      g.fillOval(x, y, XSIZE, YSIZE);
      g.dispose();
   }
   
   public void run()
   {  draw();
      for (int i = 1; i <= 1000; i++)
      {  move();
         try { Thread.sleep(5); } 
         catch(InterruptedException e) {}
      }
   }
   
   private Canvas box;
   private static final int XSIZE = 10;
   private static final int YSIZE = 10;
   private int x = 0;
   private int y = 0;
   private int dx = 2;
   private int dy = 2;   
   private Color color;
}


