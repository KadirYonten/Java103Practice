/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 23 Jun 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;

public class Animation extends Applet implements Runnable
{  public void start() 
   {  if (runner == null) 
      {  runner = new Thread(this);
         runner.start();
      }
   }

   public void stop() 
   {  if (runner != null && runner.isAlive()) 
         runner.stop();
      runner = null;
   }

   public void init() 
   {  addMouseListener(new MouseAdapter()
         {  public void mouseClicked(MouseEvent evt)
            {  toggleAnimation();
            }
         });

      try 
      {  imageName = getParameter("imagename");    
         if (imageName == null) imageName = "";
         
         imageCount = 1;
         String param = getParameter("imagecount");
         if (param != null) 
            imageCount = Integer.parseInt(param);
      }
      catch (Exception e)
      {  showStatus("Error: " + e);
      }
   }

   public synchronized void loadImage()
   {  if (loaded) return;
      try
         {  URL url = new URL(getDocumentBase(), imageName);
            showStatus("Loading " + imageName);
            image = getImage(url);
            prepareImage(image, this);
         }
         catch(Exception e)
         {  showStatus("Error: " + e);
         }

      while (!loaded)
         try { wait(); } catch (InterruptedException e) {}
      resize(imageWidth, imageHeight / imageCount);
   }
   
   public void run() 
   {  loadImage();
      while (runner != null)
      {  repaint();
         try { Thread.sleep(200); } 
         catch (InterruptedException e) {}
         current = (current + 1) % imageCount;
      }
   } 

   public void paint(Graphics g) 
   {  if (!loaded) return;
         
      g.drawImage(image, 0, - (imageHeight / imageCount) 
         * current, null);
   }

   public void update(Graphics g)
   {  paint(g);
   }

   public void toggleAnimation()
   {  if (loaded)
      {  if (runner != null && runner.isAlive()) 
         {  if (stopped)
            {  showStatus("Click to stop");
               runner.resume();
            }
            else 
            {  showStatus("Click to restart");
               runner.suspend();
            }
            stopped = !stopped;
         } 
         else 
         {  stopped = false;
            current = 0;
            runner = new Thread(this);
            runner.start();
         }
      }
   }

   public synchronized boolean imageUpdate(Image img, 
      int infoflags, int x, int y, int width, int height)
   {  if ((infoflags & ImageObserver.ALLBITS) != 0)
      {  // image is complete     
         imageWidth = image.getWidth(null);
         imageHeight = image.getHeight(null);
         showStatus("Click to stop");
         loaded = true;
         notify();
         return false;      
      }         
      return true; // want more info
   }

   private Image image;
   private int imageCount;
   private int imageWidth = 0;
   private int imageHeight = 0;
   private String imageName;
   private Thread runner = null;
   private int current = 0;
   private boolean loaded = false;
   private boolean stopped = false;
}

