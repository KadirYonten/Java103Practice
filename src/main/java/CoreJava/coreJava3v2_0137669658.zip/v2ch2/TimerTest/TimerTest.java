/*
 * Cay S. Horstmann & Gary Cornell, Core Java
 * Published By Sun Microsystems Press/Prentice-Hall
 * Copyright (C) 1997 Sun Microsystems Inc.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this 
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this 
 * copyright notice appears in all copies. 
 * 
 * THE AUTHORS AND PUBLISHER MAKE NO REPRESENTATIONS OR 
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
 * AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED 
 * BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING 
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */
 
/**
 * @version 1.10 23 Jun 1997
 * @author Cay Horstmann
 */

import java.awt.*;
import java.util.*;
import corejava.*;

public class TimerTest extends CloseableFrame 
{  public TimerTest()
   {  setTitle("TimerTest");
      setLayout(new GridLayout(2, 3));
      add(new ClockCanvas("San Jose", 16));
      add(new ClockCanvas("Taipei", 8));
      add(new ClockCanvas("Berlin", 1));
      add(new ClockCanvas("New York", 19));
      add(new ClockCanvas("Cairo", 2));
      add(new ClockCanvas("Bombay", 5));
   }

   public static void main(String[] args)
   {  Frame f = new TimerTest();
      f.setSize(450, 300);
      f.show();  
   }
}

interface Timed
{  public void tick(Timer t);
}

class Timer extends Thread
{  public Timer(Timed t, int i) 
   {  target  = t; interval = i;
      setDaemon(true);
   }

   public void run()
   {  while (true)
      {  try { sleep(interval); } 
         catch(InterruptedException e) {}
         target.tick(this);         
      }
   }
   
   private Timed target;
   private int interval;
}

class ClockCanvas extends Canvas implements Timed
{  public ClockCanvas(String c, int off) 
   {  city = c; offset = off;
      new Timer(this, 1000).start();
      setSize(125, 125);
   }

   public void paint(Graphics g)
   {  g.drawOval(0, 0, 100, 100);
      double hourAngle = 2 * Math.PI 
         * (seconds - 3 * 60 * 60) / (12 * 60 * 60);
      double minuteAngle = 2 * Math.PI 
         * (seconds - 15 * 60) / (60 * 60);
      double secondAngle = 2 * Math.PI 
         * (seconds - 15) / 60;
      g.drawLine(50, 50, 50 + (int)(30 
         * Math.cos(hourAngle)), 
         50 + (int)(30 * Math.sin(hourAngle)));
      g.drawLine(50, 50, 50 + (int)(40 
         * Math.cos(minuteAngle)), 
         50 + (int)(40 * Math.sin(minuteAngle)));
      g.drawLine(50, 50, 50 + (int)(45 
         * Math.cos(secondAngle)), 
         50 + (int)(45 * Math.sin(secondAngle)));
      g.drawString(city, 0, 115);
   }
   
   public void tick(Timer t)
   {  GregorianCalendar d = new GregorianCalendar();
      seconds = (d.get(Calendar.HOUR) - LOCAL + offset)
         * 60 * 60 + d.get(Calendar.MINUTE) * 60
         + d.get(Calendar.SECOND);
      repaint();
   }
   
   private int seconds = 0;
   private String city;
   private int offset;
   private final int LOCAL = 16;
}
